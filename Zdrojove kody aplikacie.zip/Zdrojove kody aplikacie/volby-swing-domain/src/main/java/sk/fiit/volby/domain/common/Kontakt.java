package sk.fiit.volby.domain.common;

import java.io.Serializable;

/**
 * trieda poskytujuca udaje kontaktu
 * 
 * @author nikola
 */
public class Kontakt implements Serializable {

	private static final long serialVersionUID = -8574268871126069295L;

	/**
	 * telefonicky kontakt na subjekt alebo osobu, v zavislosti, kde sa pouzije
	 */
	private String phone;

	/**
	 * emailovy kontakt na subjekt alebo osobu, v zavislosti, kde sa pouzije
	 */
	private String email;

	/**
	 * internetova stranka subjektu (napr. skoly)
	 */
	private String www;

	/**
	 * prazdny konstruktor pre vytvorenie objektu kontaktu
	 */
	public Kontakt() {
	}

	/**
	 * konstruktor pre vytvorenie objektu kontaktu s pozadovanymi parametrami
	 * 
	 * @param phone - telefonne cislo
	 * @param email - emailovy kontakt
	 * @param www   - internetova stranka
	 */
	public Kontakt(String phone, String email, String www) {
		this.phone = phone;
		this.email = email;
		this.www = www;
	}

	/**
	 * konstruktor pre vytvorenie objektu kontaktu s pozadovanymi parametrami
	 * 
	 * @param kontakt - objekt kontaktu s nastavenymi atributmi
	 */
	public Kontakt(Kontakt kontakt) {
		this.phone = kontakt.getPhone();
		this.email = kontakt.getEmail();
		this.www = kontakt.getWww();
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom phone
	 * 
	 * @return phone
	 */
	public String getPhone() {
		return phone;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom phone
	 * 
	 * @param phone - telefonne cislo
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom email
	 * 
	 * @return email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom email
	 * 
	 * @param email - emailovy kontakt
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom www
	 * 
	 * @return www
	 */
	public String getWww() {
		return www;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom www
	 * 
	 * @param www - internetova stranka
	 */
	public void setWww(String www) {
		this.www = www;
	}

}
