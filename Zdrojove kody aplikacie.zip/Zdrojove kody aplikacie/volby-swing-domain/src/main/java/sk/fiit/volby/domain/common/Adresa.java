package sk.fiit.volby.domain.common;

import java.io.Serializable;

/**
 * trieda poskytujuca udaje adresy
 * 
 * @author nikola
 */
public class Adresa implements Serializable {

	private static final long serialVersionUID = -906840985454344943L;

	/**
	 * ulica
	 */
	private String ulica;

	/**
	 * cislo domu vo formate cislo domu / cislo vchodu
	 */
	private String cisloDomu;

	/**
	 * PSC obce, mesta
	 */
	private String psc;

	/**
	 * obec, mesto
	 */
	private String obec;

	/**
	 * stat
	 */
	private String stat;

	/**
	 * prazdny konstruktor pre vytvorenie objektu adresy
	 */
	public Adresa() {
	}

	/**
	 * konstruktor pre vytvorenie objektu adresy s pozadovanymi parametrami
	 * 
	 * @param ulica     - nazov ulice
	 * @param cisloDomu - cislo domu
	 * @param psc       - PSC mesta, obce
	 * @param obec      - nazov mesto, obec
	 * @param stat      - nazov statu
	 */
	public Adresa(String ulica, String cisloDomu, String psc, String obec, String stat) {
		this.ulica = ulica;
		this.cisloDomu = cisloDomu;
		this.psc = psc;
		this.obec = obec;
		this.stat = stat;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom ulica
	 * 
	 * @return ulica
	 */
	public String getUlica() {
		return ulica;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom ulica
	 * 
	 * @param ulica - nazov ulice
	 */
	public void setUlica(String ulica) {
		this.ulica = ulica;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom cisloDomu
	 * 
	 * @return cisloDomu
	 */
	public String getCisloDomu() {
		return cisloDomu;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom cisloDomu
	 * 
	 * @param cisloDomu - cislo domu
	 */
	public void setCisloDomu(String cisloDomu) {
		this.cisloDomu = cisloDomu;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom psc
	 * 
	 * @return psc
	 */
	public String getPsc() {
		return psc;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom psc
	 * 
	 * @param psc - PSC mesta, obce
	 */
	public void setPsc(String psc) {
		this.psc = psc;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom obec
	 * 
	 * @return obec
	 */
	public String getObec() {
		return obec;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom obec
	 * 
	 * @param obec - nazov mesto, obec
	 */
	public void setObec(String obec) {
		this.obec = obec;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom stat
	 * 
	 * @return stat
	 */
	public String getStat() {
		return stat;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom stat
	 * 
	 * @param stat - nazov statu
	 */
	public void setStat(String stat) {
		this.stat = stat;
	}

}