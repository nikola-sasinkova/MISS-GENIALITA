package sk.fiit.volby.domain.volby.ucastnici.volby;

import java.util.ArrayList;
import java.util.List;

import sk.fiit.volby.domain.common.Pohlavie;
import sk.fiit.volby.domain.skola.Skola;
import sk.fiit.volby.domain.volby.Sutaz;
import sk.fiit.volby.domain.vyhodnotenie.FinalneHodnotenieUchadzaca;
import sk.fiit.volby.domain.vyhodnotenie.PriebezneHodnotenieUchadzaca;
import sk.fiit.volby.utils.generic.VolbyPair;
import sk.fiit.volby.utils.generic.VolbyPairList;

/**
 * trieda, ktora interpretuje uchadzaca, je abstraktna a obsahuje abstraktnu
 * metodu vypocetBodovehoHodnotenia a tato metoda musi byt implemetovana v
 * kazdej zdedenej triede od uchadzaca = implementacia navrhoveho vzoru null
 * object pattern
 * 
 * @author nikola
 */
public abstract class Uchadzac extends Ziak {

	private static final long serialVersionUID = -3352615025943920132L;

	/**
	 * splnil/nesplnil podmienky ucasti
	 */
	private boolean kvalifikovany;

	/**
	 * sutaz, do ktorej je uchadzac zaradeny
	 */
	private Sutaz sutaz;

	/**
	 * hodnotenie ziaka obsahujuce pocty bodov od porotcov a ziakov
	 */
	private FinalneHodnotenieUchadzaca finalneHodnotenie;

	/**
	 * priebezne hodnotenie od porotcov - vyuzivanie generickosti K,V
	 */
	private VolbyPairList<Porotca, PriebezneHodnotenieUchadzaca> priebezneHodnoteniaPorotcov = new VolbyPairList<Porotca, PriebezneHodnotenieUchadzaca>();

	/**
	 * priebezne hodnotenie od ziakov - vyuzivanie Arraylistu
	 */
	private List<PriebezneHodnotenieUchadzaca> priebezneHodnoteniaZiakov = new ArrayList<PriebezneHodnotenieUchadzaca>();

	/**
	 * vyskumna praca uchadzaca
	 */
	private VyskumnaPraca vyskumnaPraca;

	/**
	 * konstruktor pre vytvorenie objektu uchadzaca s pozadovanymi parametrami
	 * 
	 * @param skola                - skola, v ktorej uchadzac posobi
	 * @param id                   - identifikator uchadzaca
	 * @param titulPredMenom       - titul pred menom uchadzaca
	 * @param meno                 - meno uchadzaca
	 * @param stredneMeno          - stredne meno uchadzaca
	 * @param priezvisko           - priezvisko uchadzaca
	 * @param titulZaMenom         - titul za menom uchadzaca
	 * @param pohlavie             - pohlavie uchadzaca
	 * @param identifikatorZiaka   - identifikator ziaka
	 * @param kvalifikovany        - priznak, ci je uchadzac kvalifikovany
	 * @param sutaz                - sutaz, do ktorej sa uchadzac prihlasil
	 * @param stupenVzdelaniaZiaka - stupen vzdelania ziaka
	 */
	public Uchadzac(Skola skola, int id, String meno, String stredneMeno, String priezvisko, String titulPredMenom,
			String titulZaMenom, Pohlavie pohlavie, String identifikatorZiaka, boolean kvalifikovany, Sutaz sutaz,
			StupenVzdelaniaZiaka stupenVzdelaniaZiaka) {
		super(skola, id, meno, stredneMeno, priezvisko, titulPredMenom, titulZaMenom, pohlavie, identifikatorZiaka,
				stupenVzdelaniaZiaka);
		this.kvalifikovany = kvalifikovany;
		this.sutaz = sutaz;
	}

	/**
	 * abstraktna metoda, ktora zabezpeci vypocet bodoveho hodnotenie pre kazdeho
	 * zdedeneho uchadzaca
	 */
	public abstract void vypocetBodovehoHodnotenia();

	/**
	 * metoda, ktora sluzi na inicialne naplnenie hodnoteni uchadzaca porotcami, ale
	 * aj na aktualizaciu priebezneho hodnotenia hodnotou nastavenou v policku pocet
	 * bodov
	 * 
	 * @param aktualnePriebezneHodnotenieUchadzaca - aktualne priebezne hodnotenie
	 *                                             uchadzaca
	 */
	public void aktualizovatPriebezneHodnotenieUchadzacaPorotcu(
			PriebezneHodnotenieUchadzaca aktualnePriebezneHodnotenieUchadzaca) {

		for (VolbyPair<Porotca, PriebezneHodnotenieUchadzaca> priebezneHodnotenieUchadzaca : getPriebezneHodnoteniaPorotcov()
				.getZoznamParovanychDvojic()) {
			if (priebezneHodnotenieUchadzaca.ziskatKlucZaznamu().getId()
					.equals(aktualnePriebezneHodnotenieUchadzaca.getPorotca().getId())) {
				getPriebezneHodnoteniaPorotcov().odobratZoZoznamuDvojicu(priebezneHodnotenieUchadzaca);

				VolbyPair<Porotca, PriebezneHodnotenieUchadzaca> volbyPair = new VolbyPair<Porotca, PriebezneHodnotenieUchadzaca>(
						aktualnePriebezneHodnotenieUchadzaca.getPorotca(), aktualnePriebezneHodnotenieUchadzaca);
				getPriebezneHodnoteniaPorotcov().pridatDoZoznamuDvojicu(volbyPair);
				return;
			}
		}

		VolbyPair<Porotca, PriebezneHodnotenieUchadzaca> volbyPair = new VolbyPair<Porotca, PriebezneHodnotenieUchadzaca>(
				aktualnePriebezneHodnotenieUchadzaca.getPorotca(), aktualnePriebezneHodnotenieUchadzaca);
		getPriebezneHodnoteniaPorotcov().pridatDoZoznamuDvojicu(volbyPair);

	}

	/**
	 * metoda, ktora sluzi na inicialne naplnenie hodnoteni uchadzaca ziakmi, ale aj
	 * na aktualizaciu priebezneho hodnotenia hodnotou nastavenou v policku pocet
	 * bodov
	 * 
	 * @param aktualnePriebezneHodnotenieUchadzaca - aktualne priebezne hodnotenie
	 *                                             uchadzaca
	 */
	public void aktualizovatPriebezneHodnotenieUchadzacaZiaka(
			PriebezneHodnotenieUchadzaca aktualnePriebezneHodnotenieUchadzaca) {

		for (PriebezneHodnotenieUchadzaca priebezneHodnotenieUchadzaca : getPriebezneHodnoteniaZiakov()) {
			if (priebezneHodnotenieUchadzaca.getZiak().getId()
					.equals(aktualnePriebezneHodnotenieUchadzaca.getZiak().getId())) {
				getPriebezneHodnoteniaZiakov().remove(priebezneHodnotenieUchadzaca);
				getPriebezneHodnoteniaZiakov().add(aktualnePriebezneHodnotenieUchadzaca);
				return;
			}
		}

		getPriebezneHodnoteniaZiakov().add(aktualnePriebezneHodnotenieUchadzaca);

	}

	/**
	 * metoda na vratenie atributu triedy s nazvom sutaz
	 * 
	 * @return sutaz
	 */
	public Sutaz getSutaz() {
		return sutaz;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom sutaz
	 * 
	 * @param sutaz - sutaz, do ktorej sa uchadzac prihlasil
	 */
	public void setSutaz(Sutaz sutaz) {
		this.sutaz = sutaz;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom kvalifikovany
	 * 
	 * @return kvalifikovany
	 */
	public boolean isKvalifikovany() {
		return kvalifikovany;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom kvalifikovany
	 * 
	 * @param kvalifikovany - priznak, ci je uchadzac kvalifikovany
	 */
	public void setKvalifikovany(boolean kvalifikovany) {
		this.kvalifikovany = kvalifikovany;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom finalneHodnotenie
	 * 
	 * @return finalneHodnotenie
	 */
	public FinalneHodnotenieUchadzaca getFinalneHodnotenie() {
		return finalneHodnotenie;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom finalneHodnotenie
	 * 
	 * @param finalneHodnotenie - finalne hodnotenie
	 */
	public void setFinalneHodnotenie(FinalneHodnotenieUchadzaca finalneHodnotenie) {
		this.finalneHodnotenie = finalneHodnotenie;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom vyskumnaPraca
	 * 
	 * @return vyskumnaPraca
	 */
	public VyskumnaPraca getVyskumnaPraca() {
		return vyskumnaPraca;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom vyskumnaPraca
	 * 
	 * @param vyskumnaPraca - vyskumna praca
	 */
	public void setVyskumnaPraca(VyskumnaPraca vyskumnaPraca) {
		this.vyskumnaPraca = vyskumnaPraca;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom priebezneHodnoteniaPorotcov
	 * 
	 * @return priebezneHodnoteniaPorotcov
	 */
	public VolbyPairList<Porotca, PriebezneHodnotenieUchadzaca> getPriebezneHodnoteniaPorotcov() {
		return priebezneHodnoteniaPorotcov;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom priebezneHodnoteniaPorotcov
	 * 
	 * @param priebezneHodnoteniaPorotcov - priebezne hodnotenia porotcov
	 */
	public void setPriebezneHodnoteniaPorotcov(
			VolbyPairList<Porotca, PriebezneHodnotenieUchadzaca> priebezneHodnoteniaPorotcov) {
		this.priebezneHodnoteniaPorotcov = priebezneHodnoteniaPorotcov;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom priebezneHodnoteniaZiakov
	 * 
	 * @return priebezneHodnoteniaZiakov
	 */
	public List<PriebezneHodnotenieUchadzaca> getPriebezneHodnoteniaZiakov() {
		return priebezneHodnoteniaZiakov;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom priebezneHodnoteniaZiakov
	 * 
	 * @param priebezneHodnoteniaZiakov - priebezne hodnotenia ziakov
	 */
	public void setPriebezneHodnoteniaZiakov(List<PriebezneHodnotenieUchadzaca> priebezneHodnoteniaZiakov) {
		this.priebezneHodnoteniaZiakov = priebezneHodnoteniaZiakov;
	}

	/**
	 * metoda, ktora sluzi na zobrazovanie nadefinovanych atributov pri vypisovani
	 * objektov do konzoly
	 */
	@Override
	public String toString() {
		return this.getId() + " + " + this.getFormatovaneMenoOsoby();
	}

}
