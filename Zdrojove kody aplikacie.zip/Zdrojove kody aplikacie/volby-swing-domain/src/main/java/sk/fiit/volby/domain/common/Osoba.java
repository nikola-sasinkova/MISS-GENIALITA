package sk.fiit.volby.domain.common;

import sk.fiit.volby.domain.Entity;
import sk.fiit.volby.domain.skola.Skola;

/**
 * trieda poskytujuca udaje osoby
 * 
 * @author nikola
 */
public class Osoba extends Entity {

	private static final long serialVersionUID = -6913610096287720058L;

	/**
	 * skola,v ktorej dana osoba posobi
	 */
	private Skola skola;

	/**
	 * ziskane tituly pred menom osoby
	 */
	private String titulPredMenom;

	/**
	 * krstne meno osoby
	 */
	private String meno;

	/**
	 * stredne meno osoby
	 */
	private String stredneMeno;

	/**
	 * priezvisko osoby
	 */
	private String priezvisko;

	/**
	 * ziskane tituly za menom osoby
	 */
	private String titulZaMenom;

	/**
	 * pohlavie osoby
	 */
	private Pohlavie pohlavie;

	/**
	 * prazdny konstruktor pre vytvorenie objektu osoby
	 */
	public Osoba() {
		super();
	}

	/**
	 * konstruktor pre vytvorenie objektu osoby s pozadovanymi parametrami
	 * 
	 * @param skola          - skola, v ktorej osoba posobi
	 * @param id             - identifikator osoby
	 * @param titulPredMenom - titul pred menom osoby
	 * @param meno           - meno osoby
	 * @param stredneMeno    - stredne meno osoby
	 * @param priezvisko     - priezvisko osoby
	 * @param titulZaMenom   - titul za menom osoby
	 * @param pohlavie       - pohlavie osoby
	 */
	public Osoba(Skola skola, int id, String titulPredMenom, String meno, String stredneMeno, String priezvisko,
			String titulZaMenom, Pohlavie pohlavie) {
		super(id);
		this.skola = skola;
		this.titulPredMenom = titulPredMenom;
		this.meno = meno;
		this.stredneMeno = stredneMeno;
		this.priezvisko = priezvisko;
		this.titulZaMenom = titulZaMenom;
		this.pohlavie = pohlavie;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom titulPredMenom
	 * 
	 * @return titulPredMenom
	 */
	public String getTitulPredMenom() {
		return titulPredMenom;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom titulPredMenom
	 * 
	 * @param titulPredMenom - titul pred menom osoby
	 */
	public void setTitulPredMenom(String titulPredMenom) {
		this.titulPredMenom = titulPredMenom;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom meno
	 * 
	 * @return meno
	 */
	public String getMeno() {
		return meno;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom meno
	 * 
	 * @param meno - meno osoby
	 */
	public void setMeno(String meno) {
		this.meno = meno;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom stredneMeno
	 * 
	 * @return stredneMeno
	 */
	public String getStredneMeno() {
		return stredneMeno;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom stredneMeno
	 * 
	 * @param stredneMeno - stredne meno osoby
	 */
	public void setStredneMeno(String stredneMeno) {
		this.stredneMeno = stredneMeno;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom priezvisko
	 * 
	 * @return priezvisko
	 */
	public String getPriezvisko() {
		return priezvisko;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom priezvisko
	 * 
	 * @param priezvisko - priezvisko osoby
	 */
	public void setPriezvisko(String priezvisko) {
		this.priezvisko = priezvisko;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom titulZaMenom
	 * 
	 * @return titulZaMenom
	 */
	public String getTitulZaMenom() {
		return titulZaMenom;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom titulZaMenom
	 * 
	 * @param titulZaMenom - titul za menom osoby
	 */
	public void setTitulZaMenom(String titulZaMenom) {
		this.titulZaMenom = titulZaMenom;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom pohlavie
	 * 
	 * @return pohlavie
	 */
	public Pohlavie getPohlavie() {
		return pohlavie;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom pohlavie
	 * 
	 * @param pohlavie - pohlavie osoby
	 */
	public void setPohlavie(Pohlavie pohlavie) {
		this.pohlavie = pohlavie;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom skola
	 * 
	 * @return skola
	 */
	public Skola getSkola() {
		return skola;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom skola
	 * 
	 * @param skola - skola, v ktorej osoba posobi
	 */
	public void setSkola(Skola skola) {
		this.skola = skola;
	}

	/**
	 * metoda, ktora vrati formatovane meno osoby (titul, meno, priezvisko, titul)
	 * 
	 * @return formatovaneMenoOsoby
	 */
	public String getFormatovaneMenoOsoby() {

		StringBuilder sb = new StringBuilder();

		if (titulPredMenom.trim() != "") {
			sb.append(titulPredMenom);
			sb.append(" ");
		}
		if (meno.trim() != "") {
			sb.append(meno);
			sb.append(" ");
		}
		if (priezvisko.trim() != "") {
			sb.append(priezvisko);
			sb.append(" ");
		}
		if (titulZaMenom.trim() != "") {
			sb.append(titulZaMenom);
		}

		return sb.toString().trim();

	}

}
