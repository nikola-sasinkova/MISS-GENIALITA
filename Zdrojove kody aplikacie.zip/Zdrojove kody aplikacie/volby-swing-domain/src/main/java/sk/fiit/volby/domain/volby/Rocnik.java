package sk.fiit.volby.domain.volby;

import java.util.Date;

import sk.fiit.volby.domain.Entity;
import sk.fiit.volby.domain.skola.Skola;

/**
 * trieda, ktora interpretuje rocnik
 * 
 * @author nikola
 */
public class Rocnik extends Entity {

	private static final long serialVersionUID = -7677256399238596599L;

	/**
	 * nazov rocnika (napr. 2023/2024)
	 */
	private String nazov;

	/**
	 * datum, od kedy zacina semester
	 */
	private Date zaciatokSemestra;

	/**
	 * datum, kedy konci semester
	 */
	private Date koniecSemestra;

	/**
	 * skola, pre ktoru bude vytvoreny rocnik
	 */
	private Skola skola;

	/**
	 * prazdny konstruktor pre vytvorenie objektu rocnika
	 */
	public Rocnik() {
		super();
	}

	/**
	 * konstruktor pre vytvorenie objektu rocnika s pozadovanymi parametrami
	 * 
	 * @param skola            - skola, pre ktoru bude rocnik vytvoreny
	 * @param id               - identifikator rocnika
	 * @param nazov            - nazov rocnika
	 * @param zaciatokSemestra - zaciatok semestra rocnika
	 * @param koniecSemestra   - koniec semestra rocnika
	 */
	public Rocnik(Skola skola, int id, String nazov, Date zaciatokSemestra, Date koniecSemestra) {
		super(id);
		this.skola = skola;
		this.nazov = nazov;
		this.zaciatokSemestra = zaciatokSemestra;
		this.koniecSemestra = koniecSemestra;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom nazov
	 * 
	 * @return nazov
	 */
	public String getNazov() {
		return nazov;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom nazov
	 * 
	 * @param nazov - nazov rocnika
	 */
	public void setNazov(String nazov) {
		this.nazov = nazov;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom zaciatokSemestra
	 * 
	 * @return zaciatokSemestra
	 */
	public Date getZaciatokSemestra() {
		return zaciatokSemestra;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom zaciatok semestra
	 * 
	 * @param zaciatokSemestra - zaciatok semestra rocnika
	 */
	public void setZaciatokSemestra(Date zaciatokSemestra) {
		this.zaciatokSemestra = zaciatokSemestra;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom koniecSemestra
	 * 
	 * @return koniecSemestra
	 */
	public Date getKoniecSemestra() {
		return koniecSemestra;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom koniecSemestra
	 * 
	 * @param koniecSemestra - koniec semestra rocnika
	 */
	public void setKoniecSemestra(Date koniecSemestra) {
		this.koniecSemestra = koniecSemestra;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom skola
	 * 
	 * @return skola
	 */
	public Skola getSkola() {
		return skola;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom skola
	 * 
	 * @param skola - skola, pre ktoru bude rocnik vytvoreny
	 */
	public void setSkola(Skola skola) {
		this.skola = skola;
	}

}
