package sk.fiit.volby.domain.volby.ucastnici.volby;

import sk.fiit.volby.domain.Entity;

/**
 * trieda poskytujuca udaje vyskumnej praci
 * 
 * @author nikola
 */
public class VyskumnaPraca extends Entity {

	private static final long serialVersionUID = 103765627074617351L;

	/**
	 * nazov vyskumnej prace
	 */
	private String nazov;

	/**
	 * obsah vyskumnej prace v par vetach
	 */
	private String popis;

	/**
	 * konstruktor pre vytvorenie objektu vyskumnej prace s pozadovanymi parametrami
	 * 
	 * @param nazov - nazov vyskumnej prace
	 * @param popis - popis vyskumnej prace
	 */
	public VyskumnaPraca(String nazov, String popis) {
		this.nazov = nazov;
		this.popis = popis;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom nazov
	 * 
	 * @return nazov
	 */
	public String getNazov() {
		return nazov;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom nazov
	 * 
	 * @param nazov - nazov vyskumnej prace
	 */
	public void setNazov(String nazov) {
		this.nazov = nazov;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom popis
	 * 
	 * @return popis
	 */
	public String getPopis() {
		return popis;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom popis
	 * 
	 * @param popis - popis vyskumnej prace
	 */
	public void setPopis(String popis) {
		this.popis = popis;
	}
}
