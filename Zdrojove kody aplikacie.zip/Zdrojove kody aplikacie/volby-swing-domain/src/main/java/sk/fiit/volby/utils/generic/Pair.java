package sk.fiit.volby.utils.generic;

/**
 * rozhranie, ktore sluzi na ziskanie klucu a hodnoty z dvojice
 * 
 * @author nikola
 */
public interface Pair<K, V> {

	/**
	 * metoda na vratenie kluca v pozadovanom zazname zo zoznamu
	 * 
	 * @return K
	 */
	public K ziskatKlucZaznamu();

	/**
	 * metoda na vratenie hodnoty v pozadovanom zazname zo zoznamu
	 * 
	 * @return V
	 */
	public V ziskatHodnotuZaznamu();

}
