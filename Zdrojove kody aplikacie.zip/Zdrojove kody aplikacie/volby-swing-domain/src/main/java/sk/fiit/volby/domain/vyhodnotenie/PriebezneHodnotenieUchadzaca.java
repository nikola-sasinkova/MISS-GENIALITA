package sk.fiit.volby.domain.vyhodnotenie;

import sk.fiit.volby.domain.Entity;
import sk.fiit.volby.domain.volby.ucastnici.volby.Porotca;
import sk.fiit.volby.domain.volby.ucastnici.volby.Uchadzac;
import sk.fiit.volby.domain.volby.ucastnici.volby.Ziak;

/**
 * trieda poskytujuca udaje priebezneho hodnotenia uchadzaca
 * 
 * @author nikola
 */
public class PriebezneHodnotenieUchadzaca extends Entity {

	private static final long serialVersionUID = -1348871561843180428L;

	/**
	 * priebezne hodnotenie, ktore dal porotca
	 */
	private Porotca porotca;

	/**
	 * priebezne hodnotenie, ktore dal ziak
	 */
	private Ziak ziak;

	/**
	 * priebezne hodnotenie pre uchadzaca
	 */
	private Uchadzac uchadzac;

	/**
	 * pocet bodov, ktore uchadzac dostane od porotcu (0-10)
	 */
	private int pocetBodovOdPorotcu;

	/**
	 * pocet bodov, ktore uchadzac dostane od ziaka (0-10)
	 */
	private int pocetBodovOdZiaka;

	/**
	 * prazdny konstruktor pre vytvorenie objektu hodnotenie
	 */
	public PriebezneHodnotenieUchadzaca() {
		super();

	}

	/**
	 * konstruktor pre vytvorenie objektu priebezneho hodnotenia s pozadovanymi
	 * parametrami
	 * 
	 * @param porotca             - priebezne hodnotenie, ktore dal porotca
	 * @param uchadzac            - priebezne hodnotenie pre uchadzaca
	 * @param pocetBodovOdPorotcu - pocet bodov, ktore uchadzac dostane od porotcu
	 *                            (0-10)
	 */
	public PriebezneHodnotenieUchadzaca(Porotca porotca, Uchadzac uchadzac, int pocetBodovOdPorotcu) {
		super();
		this.porotca = porotca;
		this.uchadzac = uchadzac;
		this.pocetBodovOdPorotcu = pocetBodovOdPorotcu;

	}

	/**
	 * konstruktor pre vytvorenie objektu priebezneho vyhodnotenia s pozadovanymi
	 * parametrami
	 * 
	 * @param ziak              - priebezne hodnotenie, ktore dal ziak
	 * @param uchadzac          - priebezne hodnotenie pre uchadzaca
	 * @param pocetBodovOdZiaka - pocet bodov, ktore uchadzac dostane od ziaka
	 *                          (0-10)
	 */
	public PriebezneHodnotenieUchadzaca(Ziak ziak, Uchadzac uchadzac, int pocetBodovOdZiaka) {
		super();
		this.ziak = ziak;
		this.uchadzac = uchadzac;
		this.pocetBodovOdZiaka = pocetBodovOdZiaka;

	}

	/**
	 * metoda na vratenie atributu triedy s nazvom pocetBodovOdPorotcu
	 * 
	 * @return pocetBodovOdPorotcu
	 */
	public int getPocetBodovOdPorotcu() {
		return pocetBodovOdPorotcu;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom pocetBodovOdPorotcu
	 * 
	 * @param pocetBodovOdPorotcu - priebezne hodnotenie, ktore dal porotca
	 */
	public void setPocetBodovOdPorotcu(int pocetBodovOdPorotcu) {
		this.pocetBodovOdPorotcu = pocetBodovOdPorotcu;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom pocetBodovOdZiaka
	 * 
	 * @return pocetBodovOdZiaka
	 */
	public int getPocetBodovOdZiaka() {
		return pocetBodovOdZiaka;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom pocetBodovOdZiaka
	 * 
	 * @param pocetBodovOdZiaka - priebezne hodnotenie, ktore dal ziak
	 */
	public void setPocetBodovOdZiaka(int pocetBodovOdZiaka) {
		this.pocetBodovOdZiaka = pocetBodovOdZiaka;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom porotca
	 * 
	 * @return porotca
	 */
	public Porotca getPorotca() {
		return porotca;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom porotca
	 * 
	 * @param porotca - priebezne hodnotenie, ktore dal porotca
	 */
	public void setPorotca(Porotca porotca) {
		this.porotca = porotca;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom ziak
	 * 
	 * @return ziak
	 */
	public Ziak getZiak() {
		return ziak;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom ziak
	 * 
	 * @param ziak - priebezne hodnotenie, ktore dal ziak
	 */
	public void setZiak(Ziak ziak) {
		this.ziak = ziak;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom uchadzac
	 * 
	 * @return uchadzac
	 */
	public Uchadzac getUchadzac() {
		return uchadzac;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom uchadzac
	 * 
	 * @param uchadzac - priebezne hodnotenie pre uchadzaca
	 */
	public void setUchadzac(Uchadzac uchadzac) {
		this.uchadzac = uchadzac;
	}

}
