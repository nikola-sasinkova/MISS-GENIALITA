package sk.fiit.volby.utils.generic;

import java.io.Serializable;

/**
 * trieda, v ktorej su vyuzivane genericke typy K (key), V (value)
 * 
 * @author nikola
 */
public class VolbyPair<K, V> implements Pair<K, V>, Serializable {

	private static final long serialVersionUID = 4670965368294738979L;

	/**
	 * key, v ktorom je drzany kluc (v aplikacii vyuzivame ako porotca)
	 */
	private K key;

	/**
	 * hodnota priradena klucu (priebezne hodnotenie vytvorene porotcom)
	 */
	private V value;

	/**
	 * konstruktor pre vytvorenie objektu VolbyPair s pozadovanymi parametrami
	 * 
	 * @param key   - key, v ktorom je drzany kluc (v aplikacii vyuzivame ako
	 *              porotca)
	 * @param value - hodnota priradena klucu (priebezne hodnotenie vytvorene
	 *              porotcom)
	 */
	public VolbyPair(K key, V value) {
		this.key = key;
		this.value = value;
	}

	/**
	 * metoda na vratenie kluca v pozadovanom zazname zo zoznamu
	 * 
	 * @return key
	 */
	public K ziskatKlucZaznamu() {
		return key;
	}

	/**
	 * metoda na vratenie hodnoty v pozadovanom zazname zo zoznamu
	 * 
	 * @return value
	 */
	public V ziskatHodnotuZaznamu() {
		return value;
	}

}
