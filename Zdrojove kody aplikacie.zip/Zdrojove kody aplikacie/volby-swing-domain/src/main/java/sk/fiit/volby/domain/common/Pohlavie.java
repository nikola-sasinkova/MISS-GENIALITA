package sk.fiit.volby.domain.common;

/**
 * hodnoty, ktore moze nadobudat pohlavie
 * 
 * @author nikola
 */
public enum Pohlavie {

	/**
	 * Zena 
	 */
	ZENA,

	/**
	 * Muz
	 */
	MUZ

}
