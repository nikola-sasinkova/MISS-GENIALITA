package sk.fiit.volby.domain.volby.ucastnici.volby;

import sk.fiit.volby.domain.common.Osoba;
import sk.fiit.volby.domain.common.Pohlavie;
import sk.fiit.volby.domain.skola.Skola;

/**
 * trieda poskytujuca udaje porotcu
 * 
 * @author nikola
 */
public class Porotca extends Osoba {

	private static final long serialVersionUID = 2562057733376733363L;

	/**
	 * rola, v ktorej vystupuje osoba ako porotca v danom rocniku
	 */
	private RolaPorotcu rolaPorodcu;

	/**
	 * prazdny konstruktor pre vytvorenie objektu porotcu
	 */
	public Porotca() {
		super();
	}

	/**
	 * konstruktor pre vytvorenie objektu porotcu s pozadovanymi parametrami
	 * 
	 * @param skola          - skola, v ktorej porotca posobi
	 * @param id             - identifikator porotcu
	 * @param titulPredMenom - titul pred menom porotcu
	 * @param meno           - meno porotcu
	 * @param stredneMeno    - stredne meno porotcu
	 * @param priezvisko     - priezvisko porotcu
	 * @param titulZaMenom   - titul za menom porotcu
	 * @param pohlavie       - pohlavie porotcu
	 * @param rolaPorodcu    - rola porotcu
	 */
	public Porotca(Skola skola, int id, String titulPredMenom, String meno, String stredneMeno, String priezvisko,
			String titulZaMenom, Pohlavie pohlavie, RolaPorotcu rolaPorodcu) {
		super(skola, id, titulPredMenom, meno, stredneMeno, priezvisko, titulZaMenom, pohlavie);
		this.rolaPorodcu = rolaPorodcu;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom rolaPorodcu
	 * 
	 * @return rolaPorodcu
	 */
	public RolaPorotcu getRolaPorotcu() {
		return rolaPorodcu;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom rolaPorotcu
	 * 
	 * @param rolaPorodcu - rola porotcu
	 */
	public void setRolaPorodcu(RolaPorotcu rolaPorodcu) {
		this.rolaPorodcu = rolaPorodcu;
	}

}
