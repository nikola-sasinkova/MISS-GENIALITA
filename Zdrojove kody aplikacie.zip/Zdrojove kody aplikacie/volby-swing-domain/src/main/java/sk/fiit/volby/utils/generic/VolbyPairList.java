package sk.fiit.volby.utils.generic;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * trieda, v ktorej su vyuzivane genericke typy K (key), V (value)
 * 
 * @author nikola
 */
public class VolbyPairList<K, V> implements Serializable {

	private static final long serialVersionUID = -4875089474817367689L;

	/**
	 * zoznam vsetkych naparovanych dvojic objektov (napr. v aplikacii vyuzivane pre
	 * dvojicu porotca = K a priebezne hodnotenie = V)
	 */
	List<VolbyPair<K, V>> zoznamParovanychDvojic;

	/**
	 * prazdny konstruktor pre vytvorenie objektu VolbyPairList
	 */
	public VolbyPairList() {
	}

	/**
	 * metoda, ktora sluzi na pridanie naparovanej dvojice do zoznamu
	 * 
	 * @param parovanaDvojica - parovana dvojica
	 */
	public void pridatDoZoznamuDvojicu(VolbyPair<K, V> parovanaDvojica) {
		getZoznamParovanychDvojic().add(parovanaDvojica);
	}

	/**
	 * metoda, ktora sluzi na odobratie naparovanej dvojice zo zoznamu
	 * 
	 * @param parovanaDvojica - parovana dvojica
	 */
	public void odobratZoZoznamuDvojicu(VolbyPair<K, V> parovanaDvojica) {
		getZoznamParovanychDvojic().remove(parovanaDvojica);
	}

	/**
	 * metoda, ktora sluzi na ziskanie zoznamu naparovanych dvojic
	 * 
	 * @return zoznamParovanychDvojic
	 */
	public List<VolbyPair<K, V>> getZoznamParovanychDvojic() {
		if (zoznamParovanychDvojic == null) {
			zoznamParovanychDvojic = new ArrayList<VolbyPair<K, V>>();
		}
		return zoznamParovanychDvojic;
	}

}
