package sk.fiit.volby.domain.pouzivatel;

import sk.fiit.volby.domain.Entity;
import sk.fiit.volby.domain.common.Osoba;

/**
 * trieda poskytujuca udaje pouzivatela
 * 
 * @author nikola
 */
public class Pouzivatel extends Entity {

	private static final long serialVersionUID = 8263051705196954081L;

	/**
	 * prihlasovacie meno pouzivatela do systemu
	 */
	private String login;

	/**
	 * heslo pouzivatela, ktore sluzi na prihlasenie sa do systemu
	 */
	private String heslo;

	/**
	 * interpretacia osoby, s ktorou pouzivatel interaguje ziak/uchadzac/porotca
	 */
	private Osoba osoba;

	/**
	 * konstruktor pre vytvorenie objektu pouzivatela s pozadovanymi parametrami
	 * 
	 * @param id    - identifikator pouzivatela
	 * @param login - prihlasovacie meno pouzivatela
	 * @param heslo - heslo pouzivatela
	 */
	public Pouzivatel(int id, String login, String heslo) {
		super(id);
		this.login = login;
		this.heslo = heslo;
	}

	/**
	 * konstruktor pre vytvorenie objektu pouzivatela s pozadovanymi parametrami
	 * 
	 * @param id    - identifikator pouzivatela
	 * @param login - prihlasovacie meno pouzivatela
	 * @param heslo - heslo pouzivatela
	 * @param osoba - osoba, ktorej je priradeny pouzivatel
	 */
	public Pouzivatel(int id, String login, String heslo, Osoba osoba) {
		super(id);
		this.login = login;
		this.heslo = heslo;
		this.osoba = osoba;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom login
	 * 
	 * @return login
	 */
	public String getLogin() {
		return login;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom login
	 * 
	 * @param login - prihlasovacie meno pouzivatela
	 */
	public void setLogin(String login) {
		this.login = login;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom heslo
	 * 
	 * @return heslo
	 */
	public String getHeslo() {
		return heslo;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom heslo
	 * 
	 * @param heslo - heslo pouzivatela
	 */
	public void setHeslo(String heslo) {
		this.heslo = heslo;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom osoba
	 * 
	 * @return osoba
	 */
	public Osoba getOsoba() {
		return osoba;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom osoba
	 * 
	 * @param osoba - osoba, ktorej je priradeny pouzivatel
	 */
	public void setOsoba(Osoba osoba) {
		this.osoba = osoba;
	}

}
