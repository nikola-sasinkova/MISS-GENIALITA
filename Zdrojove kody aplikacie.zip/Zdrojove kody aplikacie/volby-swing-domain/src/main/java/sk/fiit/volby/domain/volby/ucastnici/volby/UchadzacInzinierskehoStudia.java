package sk.fiit.volby.domain.volby.ucastnici.volby;

import sk.fiit.volby.domain.common.Pohlavie;
import sk.fiit.volby.domain.skola.Skola;
import sk.fiit.volby.domain.volby.Sutaz;
import sk.fiit.volby.domain.vyhodnotenie.FinalneHodnotenieUchadzaca;
import sk.fiit.volby.domain.vyhodnotenie.PriebezneHodnotenieUchadzaca;
import sk.fiit.volby.utils.generic.VolbyPair;

/**
 * trieda poskytujuca udaje uchadzaca inzinierskeho studia
 * 
 * @author nikola
 */
public class UchadzacInzinierskehoStudia extends Uchadzac {

	private static final long serialVersionUID = 2927053219959789293L;

	/**
	 * koeficient, ktory zohladnuje stupen studia pri vypocte bodov
	 */
	private static final double koeficientZohladneniaStupnaStudia = 1;

	/**
	 * konstruktor pre vytvorenie objektu uchadzaca inzinierskeho studia s
	 * pozadovanymi parametrami
	 * 
	 * @param skola                - skola, v ktorej uchadzac posobi
	 * @param id                   - identifikator uchadzaca
	 * @param titulPredMenom       - titul pred menom uchadzaca
	 * @param meno                 - meno uchadzaca
	 * @param stredneMeno          - stredne meno uchadzaca
	 * @param priezvisko           - priezvisko uchadzaca
	 * @param titulZaMenom         - titul za menom uchadzaca
	 * @param pohlavie             - pohlavie uchadzaca
	 * @param identifikatorZiaka   - identifikator ziaka
	 * @param kvalifikovany        - priznak, ci je uchadzac kvalifikovany
	 * @param sutaz                - sutaz, do ktorej sa uchadzac prihlasil
	 * @param stupenVzdelaniaZiaka - stupen vzdelania ziaka
	 */
	public UchadzacInzinierskehoStudia(Skola skola, int id, String meno, String stredneMeno, String priezvisko,
			String titulPredMenom, String titulZaMenom, Pohlavie pohlavie, String identifikatorZiaka,
			boolean kvalifikovany, Sutaz sutaz, StupenVzdelaniaZiaka stupenVzdelaniaZiaka) {
		super(skola, id, meno, stredneMeno, priezvisko, titulPredMenom, titulZaMenom, pohlavie, identifikatorZiaka,
				kvalifikovany, sutaz, stupenVzdelaniaZiaka);
	}

	/**
	 * metoda, ktora sluzi na vypocet bodoveho hodnotenia (algoritmus)
	 */
	@Override
	public void vypocetBodovehoHodnotenia() {

		int pocetBodovOdPorotcov = 0;
		int pocetBodovOdZiakov = 0;

		for (VolbyPair<Porotca, PriebezneHodnotenieUchadzaca> priebezneHodnotenieUchadzaca : getPriebezneHodnoteniaPorotcov()
				.getZoznamParovanychDvojic()) {
			pocetBodovOdPorotcov = pocetBodovOdPorotcov
					+ priebezneHodnotenieUchadzaca.ziskatHodnotuZaznamu().getPocetBodovOdPorotcu();
		}

		for (PriebezneHodnotenieUchadzaca priebezneHodnotenieUchadzaca : getPriebezneHodnoteniaZiakov()) {
			pocetBodovOdZiakov = pocetBodovOdZiakov + priebezneHodnotenieUchadzaca.getPocetBodovOdZiaka();
		}

		// Vypocet podielu bodov od porotcov a bodov od ziakov
		double podiel = (double) pocetBodovOdPorotcov / pocetBodovOdZiakov;

		// Vypocet celkoveho poctu bodov
		int celkovyPocetZiskanychBodov = (int) Math
				.round(koeficientZohladneniaStupnaStudia * (podiel * pocetBodovOdZiakov + pocetBodovOdPorotcov));

		FinalneHodnotenieUchadzaca finalneHodnotenieUchadzaca = new FinalneHodnotenieUchadzaca(this, pocetBodovOdZiakov,
				pocetBodovOdPorotcov, celkovyPocetZiskanychBodov);
		setFinalneHodnotenie(finalneHodnotenieUchadzaca);

	}

}
