package sk.fiit.volby.domain.skola;

/**
 * hodnoty, ktore moze nadobudat typ skoly
 * 
 * @author nikola
 */
public enum TypSkoly {

	/**
	 * Vysoka skola
	 */
	VYSOKA_SKOLA,

	/**
	 * Stredna skola
	 */
	STREDNA_SKOLA,

	/**
	 * Zakladna skola
	 */
	ZAKLADNA_SKOLA;

}
