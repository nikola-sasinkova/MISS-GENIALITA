package sk.fiit.volby.service.exception;

/**
 * biznisova exception vdaka ktorej sa odchytava chybovy stav, aby v porote
 * mohol byt len jeden predseda
 * 
 * @author nikola
 */
public class VporoteMozeBytLenJedenPredseda extends Exception {

	private static final long serialVersionUID = -5701610951547503774L;

	/**
	 * prazdny konstruktor pre vytvorenie chyby v pripade, ze pouzivatel chce
	 * vytvorit dalsieho porotcu do zoznamu
	 */
	public VporoteMozeBytLenJedenPredseda() {
		super();
	}

}
