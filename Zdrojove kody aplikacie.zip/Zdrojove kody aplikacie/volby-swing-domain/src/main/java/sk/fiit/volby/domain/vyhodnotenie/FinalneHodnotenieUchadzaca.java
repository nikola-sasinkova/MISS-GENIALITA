package sk.fiit.volby.domain.vyhodnotenie;

import sk.fiit.volby.domain.Entity;
import sk.fiit.volby.domain.volby.ucastnici.volby.Uchadzac;

/**
 * trieda poskytujuca udaje finalneho hodnotenia uchadzaca
 * 
 * @author nikola
 */
public class FinalneHodnotenieUchadzaca extends Entity {

	private static final long serialVersionUID = -5856193095145761383L;

	/**
	 * uchadzac, ktoremu bude priradene finalne hodnotenie
	 */
	private Uchadzac uchadzac;

	/**
	 * finalny pocet bodov v sutazi po prepocte algoritmom
	 */
	private int finalnyPocetBodov;

	/**
	 * finalny pocet ziskanych bodov od ziakov
	 */
	private int finalnyPocetOdZiaka;

	/**
	 * finalny pocet ziskanych bodov od porotcov
	 */
	private int finalnyPocetOdPorotcu;

	/**
	 * konstruktor pre vytvorenie objektu finalneho hodnotenia s pozadovanymi
	 * parametrami
	 * 
	 * @param uchadzac              - uchadzac, ktoremu bude priradene finalne
	 *                              hodnotenie
	 * @param finalnyPocetOdZiaka   - finalny pocet ziskanych bodov od ziakov
	 * @param finalnyPocetOdPorotcu - finalny pocet ziskanych bodov od porotcov
	 * @param finalnyPocetBodov     - finalny pocet bodov v sutazi po prepocte
	 *                              algoritmom
	 */
	public FinalneHodnotenieUchadzaca(Uchadzac uchadzac, int finalnyPocetOdZiaka, int finalnyPocetOdPorotcu,
			int finalnyPocetBodov) {
		super();
		this.uchadzac = uchadzac;
		this.finalnyPocetOdZiaka = finalnyPocetOdZiaka;
		this.finalnyPocetOdPorotcu = finalnyPocetOdPorotcu;
		this.finalnyPocetBodov = finalnyPocetBodov;

	}

	/**
	 * metoda na vratenie atributu triedy s nazvom finalnyPocetBodov
	 * 
	 * @return finalnyPocetBodov
	 */
	public int getFinalnyPocetBodov() {
		return finalnyPocetBodov;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom finalnyPocetBodov
	 * 
	 * @param finalnyPocetBodov - finalny pocet bodov v sutazi po prepocte
	 *                          algoritmom
	 */
	public void setFinalnyPocetBodov(int finalnyPocetBodov) {
		this.finalnyPocetBodov = finalnyPocetBodov;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom uchadzac
	 * 
	 * @return uchadzac
	 */
	public Uchadzac getUchadzac() {
		return uchadzac;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom uchadzac
	 * 
	 * @param uchadzac - uchadzac, ktoremu bude priradene finalne hodnotenie
	 */
	public void setUchadzac(Uchadzac uchadzac) {
		this.uchadzac = uchadzac;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom finalnyPocetOdZiaka
	 * 
	 * @return finalnyPocetOdZiaka
	 */
	public int getFinalnyPocetOdZiaka() {
		return finalnyPocetOdZiaka;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom finalnyPocetOdZiaka
	 * 
	 * @param finalnyPocetOdZiaka - finalny pocet ziskanych bodov od ziakov
	 */
	public void setFinalnyPocetOdZiaka(int finalnyPocetOdZiaka) {
		this.finalnyPocetOdZiaka = finalnyPocetOdZiaka;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom finalnyPocetOdPorotcu
	 * 
	 * @return finalnyPocetOdPorotcu
	 */
	public int getFinalnyPocetOdPorotcu() {
		return finalnyPocetOdPorotcu;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom finalnyPocetOdPorotcu
	 * 
	 * @param finalnyPocetOdPorotcu - finalny pocet ziskanych bodov od porotcov
	 */
	public void setFinalnyPocetOdPorotcu(int finalnyPocetOdPorotcu) {
		this.finalnyPocetOdPorotcu = finalnyPocetOdPorotcu;
	}

}
