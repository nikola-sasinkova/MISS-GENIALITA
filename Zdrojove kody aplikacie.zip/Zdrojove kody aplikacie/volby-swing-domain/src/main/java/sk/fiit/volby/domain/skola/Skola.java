package sk.fiit.volby.domain.skola;

import java.io.Serializable;

import sk.fiit.volby.domain.Entity;
import sk.fiit.volby.domain.common.Adresa;
import sk.fiit.volby.domain.common.Kontakt;

/**
 * trieda poskytujuca udaje skoly
 * 
 * @author nikola
 */
public class Skola extends Entity implements Serializable {

	private static final long serialVersionUID = 1746888995467906185L;

	/**
	 * typ skoly (napr. vysoka, stredna, ...)
	 */
	private TypSkoly typ;

	/**
	 * nazov skoly
	 */
	private String nazov;

	/**
	 * adresa sidla skoly
	 */
	private Adresa adresa;

	/**
	 * kontakt na informacie skoly
	 */
	private Kontakt kontakt;

	/**
	 * prazdny konstruktor pre vytvorenie objektu skoly
	 */
	public Skola() {
		super();
	}

	/**
	 * konstruktor pre vytvorenie objektu skoly s pozadovanymi parametrami
	 * 
	 * @param id      - identifikator skoly
	 * @param typ     - typ skoly
	 * @param nazov   - nazov skoly
	 * @param adresa  - adresa skoly
	 * @param kontakt - kontakt skoly
	 */
	public Skola(int id, TypSkoly typ, String nazov, Adresa adresa, Kontakt kontakt) {
		super(id);
		this.typ = typ;
		this.nazov = nazov;
		this.adresa = adresa;
		this.kontakt = kontakt;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom typ
	 * 
	 * @return typ
	 */
	public TypSkoly getTyp() {
		return typ;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom typ
	 * 
	 * @param typ - typ skoly
	 */
	public void setTyp(TypSkoly typ) {
		this.typ = typ;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom nazov
	 * 
	 * @return nazov
	 */
	public String getNazov() {
		return nazov;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom nazov
	 * 
	 * @param nazov - nazov skoly
	 */
	public void setNazov(String nazov) {
		this.nazov = nazov;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom adresa
	 * 
	 * @return adresa
	 */
	public Adresa getAdresa() {
		return adresa;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom adresa
	 * 
	 * @param adresa - adresa skoly
	 */
	public void setAdresa(Adresa adresa) {
		this.adresa = adresa;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom kontakt
	 * 
	 * @return kontakt
	 */
	public Kontakt getKontakt() {
		return kontakt;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom kontakt
	 * 
	 * @param kontakt - kontakt skoly
	 */
	public void setKontakt(Kontakt kontakt) {
		this.kontakt = kontakt;
	}

	/**
	 * vnorena trieda, ktorou ziskavame GPS suradnice skoly
	 */
	public class GpsKoordinatori {

		/**
		 * gps suradnica - latitude
		 */
		private String gpsDlzka = "12.123123";

		/**
		 * gps suradnica - longtitude
		 */
		private String gpsSirka = "45.123123";

		/**
		 * metoda, ktora vrati GPS suradnice skoly
		 * 
		 * @return gpsDlzka, gpsSirka
		 */
		public String[] getSuradnice() {
			return new String[] { gpsDlzka, gpsSirka };
		}

	}
}
