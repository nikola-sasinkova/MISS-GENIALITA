
package sk.fiit.volby.domain.volby.ucastnici.volby;

import sk.fiit.volby.domain.common.Osoba;
import sk.fiit.volby.domain.common.Pohlavie;
import sk.fiit.volby.domain.skola.Skola;

/**
 * trieda poskytujuca udaje ziaka
 * 
 * @author nikola
 */
public class Ziak extends Osoba {

	private static final long serialVersionUID = -9027176996414053865L;

	/**
	 * biznisovy identifikator ziaka uvadzany na jeho identifikacnej karte (napr.
	 * 128720)
	 */
	private String identifikatorZiaka;

	/**
	 * urcuje stupen vzdelania ziaka
	 */
	private StupenVzdelaniaZiaka stupenVzdelaniaZiaka;

	/**
	 * prazdny konstruktor pre vytvorenie objektu ziaka
	 */
	public Ziak() {
		super();
	}

	/**
	 * konstruktor pre vytvorenie objektu ziaka s pozadovanymi parametrami
	 * 
	 * @param skola                - skola, v ktorej ziak posobi
	 * @param id                   - identifikator ziaka
	 * @param titulPredMenom       - titul pred menom ziaka
	 * @param meno                 - meno ziaka
	 * @param stredneMeno          - stredne meno ziaka
	 * @param priezvisko           - priezvisko ziaka
	 * @param titulZaMenom         - titul za menom ziaka
	 * @param pohlavie             - pohlavie ziaka
	 * @param identifikatorZiaka   - identifikator ziaka
	 * @param stupenVzdelaniaZiaka - stupen vzdelania ziaka
	 */
	public Ziak(Skola skola, int id, String meno, String stredneMeno, String priezvisko, String titulPredMenom,
			String titulZaMenom, Pohlavie pohlavie, String identifikatorZiaka,
			StupenVzdelaniaZiaka stupenVzdelaniaZiaka) {
		super(skola, id, titulPredMenom, meno, stredneMeno, priezvisko, titulZaMenom, pohlavie);
		this.identifikatorZiaka = identifikatorZiaka;
		this.stupenVzdelaniaZiaka = stupenVzdelaniaZiaka;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom identifikatorZiaka
	 * 
	 * @return identifikatorZiaka
	 */
	public String getIdentifikatorZiaka() {
		return identifikatorZiaka;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom identifikatorZiaka
	 * 
	 * @param identifikatorZiaka - identifikator ziaka
	 */
	public void setIdentifikatorZiaka(String identifikatorZiaka) {
		this.identifikatorZiaka = identifikatorZiaka;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom stupenVzdelaniaZiaka
	 * 
	 * @return stupenVzdelaniaZiaka
	 */
	public StupenVzdelaniaZiaka getStupenVzdelaniaZiaka() {
		return stupenVzdelaniaZiaka;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom stupenVzdelaniaZiakaF
	 * 
	 * @param stupenVzdelaniaZiaka - stupen vzdelania ziaka
	 */
	public void setStupenVzdelaniaZiaka(StupenVzdelaniaZiaka stupenVzdelaniaZiaka) {
		this.stupenVzdelaniaZiaka = stupenVzdelaniaZiaka;
	}

}
