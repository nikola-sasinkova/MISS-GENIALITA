package sk.fiit.volby.domain.volby.ucastnici.volby;

/**
 * hodnoty, ktore moze nadobudat stupen vzdelania ziaka
 * 
 * @author nikola
 */
public enum StupenVzdelaniaZiaka {

	/**
	 * Bakalrske studium
	 */
	BAKALARSKE_STUDIUM,

	/**
	 * Inzinierske studium
	 */
	INZINIERSKE_STUDIUM

}
