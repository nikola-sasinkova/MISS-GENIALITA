package sk.fiit.volby.domain.volby;

import java.util.Date;

import sk.fiit.volby.domain.Entity;
import sk.fiit.volby.domain.skola.Skola;

/**
 * trieda poskytujuca udaje sutaze
 * 
 * @author nikola
 */
public class Sutaz extends Entity {

	private static final long serialVersionUID = -1211286923473714895L;

	/**
	 * skola, na ktorej bude sutaz prebiehat
	 */
	private Skola skola;

	/**
	 * rocnik, do ktoreho bude sutaz zaradena
	 */
	private Rocnik rocnik;

	/**
	 * nazov sutaze (napr. MISS Genialita)
	 */
	private String nazov;

	/**
	 * doplnujuce informacie k sutazi
	 */
	private String popis;

	/**
	 * datum, do ktoreho mozu byt podane prihlasky
	 */
	private Date datumUkonceniaPrihlasovania;

	/**
	 * datum, kedy bude hlasovanie spustene
	 */
	private Date datumSpusteniaHlasovania;

	/**
	 * datum, od ktoreho budu dostupne informacie o sutazi
	 */
	private Date datumZverejnenia;

	/**
	 * prazdny konstruktor pre vytvorenie objektu sutaze
	 */
	public Sutaz() {
		super();
	}

	/**
	 * konstruktor pre vytvorenie objektu sutaze s pozadovanymi parametrami
	 * 
	 * @param id                          - identifikator sutaze
	 * @param skola                       - skola, pre ktoru bude sutaz vytvorena
	 * @param rocnik                      - rocnik, pre ktory bude sutaz vytvorena
	 * @param nazov                       - nazov sutaze
	 * @param popis                       - popis sutaze
	 * @param datumUkonceniaPrihlasovania - datum ukoncenia prihlasovania sutaze
	 * @param datumSpusteniaHlasovania    - datum spustenia hlasovania sutaze
	 * @param datumZverejnenia            - datum zverejnenia sutaze
	 */
	public Sutaz(int id, Skola skola, Rocnik rocnik, String nazov, String popis, Date datumUkonceniaPrihlasovania,
			Date datumSpusteniaHlasovania, Date datumZverejnenia) {
		super(id);
		this.skola = skola;
		this.rocnik = rocnik;
		this.nazov = nazov;
		this.popis = popis;
		this.datumUkonceniaPrihlasovania = datumUkonceniaPrihlasovania;
		this.datumSpusteniaHlasovania = datumSpusteniaHlasovania;
		this.datumZverejnenia = datumZverejnenia;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom nazov
	 * 
	 * @return nazov
	 */
	public String getNazov() {
		return nazov;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom nazov
	 * 
	 * @param nazov - nazov sutaze
	 */
	public void setNazov(String nazov) {
		this.nazov = nazov;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom popis
	 * 
	 * @return popis
	 */
	public String getPopis() {
		return popis;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom popis
	 * 
	 * @param popis - popis sutaze
	 */
	public void setPopis(String popis) {
		this.popis = popis;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom datumUkonceniaPrihlasovania
	 * 
	 * @return datumUkonceniaPrihlasovania
	 */
	public Date getDatumUkonceniaPrihlasovania() {
		return datumUkonceniaPrihlasovania;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom datumUkonceniaPrihlasovania
	 * 
	 * @param datumUkonceniaPrihlasovania - datum ukoncenia prihlasovania sutaze
	 */
	public void setDatumUkonceniaPrihlasovania(Date datumUkonceniaPrihlasovania) {
		this.datumUkonceniaPrihlasovania = datumUkonceniaPrihlasovania;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom datumSpusteniaHlasovania
	 * 
	 * @return datumSpusteniaHlasovania
	 */
	public Date getDatumSpusteniaHlasovania() {
		return datumSpusteniaHlasovania;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom datumSpusteniaHlasovania
	 * 
	 * @param datumSpusteniaHlasovania - datum spustenia hlasovania sutaze
	 */
	public void setDatumSpusteniaHlasovania(Date datumSpusteniaHlasovania) {
		this.datumSpusteniaHlasovania = datumSpusteniaHlasovania;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom datumZverejnenia
	 * 
	 * @return datumZverejnenia
	 */
	public Date getDatumZverejnenia() {
		return datumZverejnenia;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom datumZverejnenia
	 * 
	 * @param datumZverejnenia - datum zverejnenia sutaze
	 */
	public void setDatumZverejnenia(Date datumZverejnenia) {
		this.datumZverejnenia = datumZverejnenia;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom skola
	 * 
	 * @return skola
	 */
	public Skola getSkola() {
		return skola;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom skola
	 * 
	 * @param skola - skola, pre ktoru bude sutaz vytvorena
	 */
	public void setSkola(Skola skola) {
		this.skola = skola;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom rocnik
	 * 
	 * @return rocnik
	 */
	public Rocnik getRocnik() {
		return rocnik;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom rocnik
	 * 
	 * @param rocnik - rocnik, pre ktory bude sutaz vytvorena
	 */
	public void setRocnik(Rocnik rocnik) {
		this.rocnik = rocnik;
	}

}
