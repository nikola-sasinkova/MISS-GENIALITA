package sk.fiit.volby.domain.volby.ucastnici.volby;

/**
 * hodnoty, ktore moze nadobudat rola porotcu
 * 
 * @author nikola
 */
public enum RolaPorotcu {

	/**
	 * Predseda
	 */
	PREDSEDA,

	/**
	 * Clen
	 */
	CLEN

}
