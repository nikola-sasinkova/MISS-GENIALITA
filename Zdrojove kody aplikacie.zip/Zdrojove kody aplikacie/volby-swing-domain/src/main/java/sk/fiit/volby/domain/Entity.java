package sk.fiit.volby.domain;

import java.io.Serializable;

/**
 * trieda poskytujuca informacie o zakladnom identifikatore kazdeho objektu,
 * ktory dedi z tejto triedy
 * 
 * @author nikola
 */
public class Entity implements Serializable {

	private static final long serialVersionUID = -5753994552329768013L;

	/**
	 * logicky identifikator zaznamu danej entity, unikatne cislo
	 */
	private Integer id;

	/**
	 * prazdny konstruktor pre vytvorenie objektu entity
	 */
	public Entity() {
	}

	/**
	 * konstruktor pre vytvorenie objektu entity s pozadovanymi parametrami
	 * 
	 * @param id - logicky identifikator zaznamu danej entity, unikatne cislo
	 */
	public Entity(Integer id) {
		this.id = id;
	}

	/**
	 * metoda na vratenie atributu triedy s nazvom id
	 * 
	 * @return id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * metoda na nastavenie atributu triedy s nazvom id
	 * 
	 * @param id - logicky identifikator zaznamu danej entity, unikatne cislo
	 */
	public void setId(Integer id) {
		this.id = id;
	}

}
