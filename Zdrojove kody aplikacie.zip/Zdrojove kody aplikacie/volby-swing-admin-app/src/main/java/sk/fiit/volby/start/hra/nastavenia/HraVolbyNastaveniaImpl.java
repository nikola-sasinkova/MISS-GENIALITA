package sk.fiit.volby.start.hra.nastavenia;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import sk.fiit.volby.domain.pouzivatel.Pouzivatel;
import sk.fiit.volby.domain.skola.Skola;
import sk.fiit.volby.domain.volby.Rocnik;
import sk.fiit.volby.domain.volby.Sutaz;
import sk.fiit.volby.domain.volby.ucastnici.volby.Porotca;
import sk.fiit.volby.domain.volby.ucastnici.volby.Uchadzac;
import sk.fiit.volby.domain.volby.ucastnici.volby.Ziak;
import sk.fiit.volby.start.hra.InformovanieOzmeneUdajov;

/**
 * trieda, ktora predstavuje implementaciu nasej hry
 * 
 * @author nikola
 */
public class HraVolbyNastaveniaImpl implements Serializable {

	private static final long serialVersionUID = 8086286170040324084L;

	/**
	 * zoznam aktualnych skol v spustenej instancii mojej hry
	 */
	private List<Skola> skoly;

	/**
	 * zoznam aktualnych porotcov v spustenej instancii mojej hry
	 */
	private List<Porotca> porotcovia;

	/**
	 * zoznam aktualnych ziakov v spustenej instancii mojej hry
	 */
	private List<Ziak> ziaci;

	/**
	 * zoznam aktualnych uchadzacov v spustenej instancii mojej hry
	 */
	private List<Uchadzac> uchadzaci;

	/**
	 * zoznam aktualnych rocnikov v spustenej instancii mojej hry
	 */
	private List<Rocnik> rocniky;

	/**
	 * zoznam aktualnych sutazi v spustenej instancii mojej hry
	 */
	private List<Sutaz> sutaze;

	/**
	 * zoznam aktualnych pouzivatelov v spustenej instancii mojej hry
	 */
	private List<Pouzivatel> pouzivatelia;

	/**
	 * zoznam obrazoviek, ktore implementuju interface InformovanieOzmeneUdajov
	 * (tieto obrazovky musia implementovat tento interface a disponovat konkretnou
	 * implemntaciou metody inform, ktorou sa akutalizuju udaje na prislunej
	 * obrazovke)
	 */
	transient private List<InformovanieOzmeneUdajov> informovanieOzmeneUdajovList = new ArrayList<>();

	/**
	 * prazdny konstruktor pre vytvorenie mojej hry
	 */
	public HraVolbyNastaveniaImpl() {
	}

	/**
	 * metoda na vytvorenie incializacnych udajov pre realizaciu volieb
	 * 
	 * @param hraVolbyNastavenia - nastavenia hry
	 */
	public void vytvorenieInicializacnychUdajov(HraVolbyNastavenia hraVolbyNastavenia) {
		skoly = new ArrayList<Skola>();
		porotcovia = new ArrayList<Porotca>();
		ziaci = new ArrayList<Ziak>();
		uchadzaci = new ArrayList<Uchadzac>();
		rocniky = new ArrayList<Rocnik>();
		sutaze = new ArrayList<Sutaz>();
		pouzivatelia = new ArrayList<Pouzivatel>();

		hraVolbyNastavenia.nastavenie(skoly, porotcovia, ziaci, uchadzaci, rocniky, sutaze, pouzivatelia);

		// notifikovanie obrazoviek, ktore implementuju interface
		// informovanieOzmeneUdajov, aby sa
		// akutliazovali prehlady a tabulky na jednotlivych obrazovkach (napr. prehlad
		// skol, prehlad porotcov, ...)
		informInformovanieOzmeneUdajovList();
	}

	/**
	 * metoda na incializaciu udajov nacitanych zo suboru pre realizaciu volieb
	 * 
	 * @param nacitaneUdajeHryVolby - instancia nasej hry
	 * @param hraVolbyNastavenia    - nastavenia hry
	 */
	public void vytvorenieInicializacnychUdajov(HraVolbyNastaveniaImpl nacitaneUdajeHryVolby,
			HraVolbyNastavenia hraVolbyNastavenia) {
		skoly = new ArrayList<Skola>();
		porotcovia = new ArrayList<Porotca>();
		ziaci = new ArrayList<Ziak>();
		uchadzaci = new ArrayList<Uchadzac>();
		rocniky = new ArrayList<Rocnik>();
		sutaze = new ArrayList<Sutaz>();
		pouzivatelia = new ArrayList<Pouzivatel>();

		hraVolbyNastavenia.nacitanie(skoly, porotcovia, ziaci, uchadzaci, rocniky, sutaze, pouzivatelia,
				nacitaneUdajeHryVolby);

		// notifikovanie obrazoviek, ktore implementuju interface
		// informovanieOzmeneUdajov, aby sa
		// akutliazovali prehlady a tabulky na jednotlivych obrazovkach (napr. prehlad
		// skol, prehlad porotcov, ...)
		informInformovanieOzmeneUdajovList();
	}

	/**
	 * zaradenie obrazovky implementujucej interface informovanieOzmeneUdajov do
	 * zoznamu
	 * 
	 * @param informovanieOzmeneUdajov - interface na zmenu udajov
	 */
	public void zaradenieObrazovkyDoSLListZoznamu(InformovanieOzmeneUdajov informovanieOzmeneUdajov) {
		informovanieOzmeneUdajovList.add(informovanieOzmeneUdajov);
	}

	/**
	 * metoda, ktorou sa prechadza zoznam vsetkych obrazoviek implementujucich
	 * interface informovanieOzmeneUdajov a na kazdej z nich sa zavola konkretna
	 * implementacia metody inform (aby doslo k aktualizacii udajov na obrazovkach)
	 */
	public void informInformovanieOzmeneUdajovList() {

		Iterator<InformovanieOzmeneUdajov> informovanieOzmeneUdajovIterator = informovanieOzmeneUdajovList.iterator();

		while (informovanieOzmeneUdajovIterator.hasNext()) {
			InformovanieOzmeneUdajov informovanieOzmeneUdajov = informovanieOzmeneUdajovIterator.next();
			informovanieOzmeneUdajov.inform();

		}
	}

	/**
	 * metoda na nastavenie parametrov hry cez navrhovy vzor strategy
	 * 
	 * @param skoly        - zoznam skol v hre
	 * @param porotcovia   - zoznam porotcov v hre
	 * @param ziaci        - zoznam ziakov v hre
	 * @param uchadzaci    - zoznam uchadzacov v hre
	 * @param rocniky      - zoznam rocnikov v hre
	 * @param sutaze       - zoznam sutazi v hre
	 * @param pouzivatelia - zoznam pouzivtelov v hre
	 */
	protected void nastavenieUdajovCezNavrhovyVzorStrategy(List<Skola> skoly, List<Porotca> porotcovia,
			List<Ziak> ziaci, List<Uchadzac> uchadzaci, List<Rocnik> rocniky, List<Sutaz> sutaze,
			List<Pouzivatel> pouzivatelia) {

		this.skoly = skoly;
		this.porotcovia = porotcovia;
		this.ziaci = ziaci;
		this.uchadzaci = uchadzaci;
		this.rocniky = rocniky;
		this.sutaze = sutaze;
		this.pouzivatelia = pouzivatelia;

	}

	/**
	 * metoda na vratenie zoznamu skol definovanych v nasej hre
	 * 
	 * @return skoly
	 */
	public List<Skola> getSkoly() {
		return skoly;
	}

	/**
	 * metoda na vratenie zoznamu porotcov definovanych v nasej hre
	 * 
	 * @return porotcovia
	 */
	public List<Porotca> getPorotcovia() {
		return porotcovia;
	}

	/**
	 * metoda, ktora sluzi na zaradenie porotcu do zoznamu porotcov v nasej hre
	 * 
	 * @param porotcovia - zoznam porotcov v hre
	 */
	public void setPorotcovia(List<Porotca> porotcovia) {
		this.porotcovia = porotcovia;
	}

	/**
	 * metoda, ktora sluzi na zaradenie skoly do zoznamu skol v nasej hre
	 * 
	 * @param skoly - zoznam skol v hre
	 */
	public void setSkoly(List<Skola> skoly) {
		this.skoly = skoly;
	}

	/**
	 * metoda na vratenie zoznamu ziakov definovanych v nasej hre
	 * 
	 * @return ziaci
	 */
	public List<Ziak> getZiaci() {
		return ziaci;
	}

	/**
	 * metoda, ktora sluzi na zaradenie ziaka do zoznamu ziakov v nasej hre
	 * 
	 * @param ziaci - zoznam ziakov v hre
	 */
	public void setZiaci(List<Ziak> ziaci) {
		this.ziaci = ziaci;
	}

	/**
	 * metoda na vratenie zoznamu uchadzacov definovanych v nasej hre
	 * 
	 * @return uchadzaci
	 */
	public List<Uchadzac> getUchadzaci() {
		return uchadzaci;
	}

	/**
	 * metoda, ktora sluzi na zaradenie uchadzaca do zoznamu uchadzacov v nasej hre
	 * 
	 * @param uchadzaci - zoznam uchadzacov v hre
	 */
	public void setUchadzaci(List<Uchadzac> uchadzaci) {
		this.uchadzaci = uchadzaci;
	}

	/**
	 * metoda na vratenie zoznamu rocnikov definovanych v nasej hre
	 * 
	 * @return rocniky
	 */
	public List<Rocnik> getRocniky() {
		return rocniky;
	}

	/**
	 * metoda, ktora sluzi na zaradenie rocnika do zoznamu rocnikov v nasej hre
	 * 
	 * @param rocniky - zoznam rocnikov v hre
	 */
	public void setRocniky(List<Rocnik> rocniky) {
		this.rocniky = rocniky;
	}

	/**
	 * metoda na vratenie zoznamu sutazi definovanych v nasej hre
	 * 
	 * @return sutaze
	 */
	public List<Sutaz> getSutaze() {
		return sutaze;
	}

	/**
	 * metoda, ktora sluzi na zaradenie sutaze do zoznamu sutazi v nasej hre
	 * 
	 * @param sutaze - zoznam sutazi v hre
	 */
	public void setSutaze(List<Sutaz> sutaze) {
		this.sutaze = sutaze;
	}

	/**
	 * metoda na vratenie zoznamu pouzivatelov definovanych v nasej hre
	 * 
	 * @return pouzivatelia
	 */
	public List<Pouzivatel> getPouzivatelia() {
		return pouzivatelia;
	}

	/**
	 * metoda, ktora sluzi na zaradenie pouzivatela do zoznamu pouzivatelov v nasej
	 * hre
	 * 
	 * @param pouzivatelia - zoznam pouzivtelov v hre
	 */
	public void setPouzivatelia(List<Pouzivatel> pouzivatelia) {
		this.pouzivatelia = pouzivatelia;
	}

}
