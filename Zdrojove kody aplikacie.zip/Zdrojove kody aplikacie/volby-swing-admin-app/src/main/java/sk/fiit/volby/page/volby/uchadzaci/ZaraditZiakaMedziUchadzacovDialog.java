package sk.fiit.volby.page.volby.uchadzaci;

import java.awt.Component;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultListCellRenderer;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;

import sk.fiit.volby.domain.volby.Sutaz;
import sk.fiit.volby.domain.volby.ucastnici.volby.Ziak;
import sk.fiit.volby.start.RunApp;
import sk.fiit.volby.start.hra.nastavenia.HraVolbyNastaveniaImpl;

/**
 * trieda, ktora sluzi na zobrazenie prvkov formulara pre zaradenie ziaka medzi
 * uchadzacov
 * 
 * @author nikola
 */
public abstract class ZaraditZiakaMedziUchadzacovDialog extends JDialog {

	private static final long serialVersionUID = -5931309089862762142L;

	/**
	 * konstruktor pre vytvorenie obrazovky pre zaradenie ziaka medzi uchadzacov s
	 * pozadovanym parametrom
	 * 
	 * @param hraVolbyNastaveniaImpl - instancia mojej hry
	 * @param ziak - ziak, ktory bude zaradeny medzi uchadzacov
	 */
	public ZaraditZiakaMedziUchadzacovDialog(HraVolbyNastaveniaImpl hraVolbyNastaveniaImpl, Ziak ziak) {

		inicializaciaObrazovky(hraVolbyNastaveniaImpl, ziak);

	}

	/**
	 * inicializacia obrazovky
	 * 
	 * @param hraVolbyNastaveniaImpl - instancia mojej hry
	 * @param ziak - ziak, ktory bude zaradeny medzi uchadzacov
	 */
	public void inicializaciaObrazovky(HraVolbyNastaveniaImpl hraVolbyNastaveniaImpl, Ziak ziak) {

		setAlwaysOnTop(true);
		setTitle(RunApp.getProperties().getProperty("zaradit.ziaka.medzi.uchadzacov.dialog.title"));
		setType(Type.POPUP);
		setSize(470, 168);
		getContentPane().setLayout(null);

		Image imgAdminLogo = new ImageIcon(this.getClass().getResource("/logo.png")).getImage();
		setIconImage(imgAdminLogo);

		JLabel lblSutaze = new JLabel("Súťaže");
		lblSutaze.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblSutaze.setBounds(21, 29, 98, 14);
		getContentPane().add(lblSutaze);

		JComboBox<Sutaz> comboBoxSutaze = new JComboBox<Sutaz>();
		comboBoxSutaze.setBounds(124, 26, 278, 22);
		getContentPane().add(comboBoxSutaze);

		comboBoxSutaze.setRenderer(new DefaultListCellRenderer() {

			private static final long serialVersionUID = -29557693884269383L;

			@Override
			public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected,
					boolean cellHasFocus) {
				super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
				Sutaz sutaz = (Sutaz) value;
				setText(sutaz.getNazov());
				return this;

			}
		});

		for (Sutaz sutaz : hraVolbyNastaveniaImpl.getSutaze()) {
			comboBoxSutaze.addItem(sutaz);
		}

		// tlacitko na zaradenie uchadzaca do vybranej sutaze
		JButton btnUlozit = new JButton("Uložiť");
		btnUlozit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				Sutaz sutaz = (Sutaz) comboBoxSutaze.getModel().getSelectedItem();

				ZaraditZiakaMedziUchadzacovDialog.this.zaraditZiakaMedziUchadzacov(ziak, sutaz);

				ZaraditZiakaMedziUchadzacovDialog.this.dispose();

			}
		});
		btnUlozit.setBounds(214, 68, 89, 23);
		getContentPane().add(btnUlozit);

		// tlacitko na zrusenie okna
		JButton btnZrusit = new JButton("Zrusit");
		btnZrusit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ZaraditZiakaMedziUchadzacovDialog.this.dispose();
			}
		});
		btnZrusit.setBounds(313, 68, 89, 23);
		getContentPane().add(btnZrusit);

	}

	/**
	 * metoda, ktora zaradi ziaka medzi uchadzacov
	 * 
	 * @param ziak - ziak, ktory bude zaradeny medzi uchadzacov
	 * @param sutaz - sutaz, do ktorej bude ziak zaradeny
	 */
	protected abstract void zaraditZiakaMedziUchadzacov(Ziak ziak, Sutaz sutaz);

}
