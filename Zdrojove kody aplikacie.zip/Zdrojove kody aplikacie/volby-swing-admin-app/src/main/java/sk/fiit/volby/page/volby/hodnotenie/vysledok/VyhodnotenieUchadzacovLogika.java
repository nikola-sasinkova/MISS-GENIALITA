package sk.fiit.volby.page.volby.hodnotenie.vysledok;

import java.util.List;

import sk.fiit.volby.domain.volby.Sutaz;
import sk.fiit.volby.start.hra.InformovanieOzmeneUdajov;
import sk.fiit.volby.start.hra.nastavenia.HraVolbyNastaveniaImpl;

/**
 * obrazovka na zobrazenie prehladu vyhodnotenia (externalizovana logika vramci
 * ktorej je implementovana metoda inform, sluzi na aktualizaciu udajov)
 * 
 * @author nikola
 */
public class VyhodnotenieUchadzacovLogika extends VyhodnotenieUchadzacovPanel implements InformovanieOzmeneUdajov {

	private static final long serialVersionUID = -6419221107898781854L;

	/**
	 * aktualna instancia beziacej hry
	 */
	private HraVolbyNastaveniaImpl hraVolbyNastaveniaImpl;

	/**
	 * zoznam sutazi, ktore sa budu zobrazovat v comboboxe s prehladom sutazi
	 */
	private List<Sutaz> sutaze;

	/**
	 * konstruktor pre vytvorenie obrazovky prehladu vyhodnotenis s pozadovanymi
	 * parametrami
	 * 
	 * @param hraVolbyNastaveniaImpl - instancia mojej hry
	 */
	public VyhodnotenieUchadzacovLogika(HraVolbyNastaveniaImpl hraVolbyNastaveniaImpl) {
		super(hraVolbyNastaveniaImpl);
		this.hraVolbyNastaveniaImpl = hraVolbyNastaveniaImpl;
	}

	/**
	 * konkretna implementacia metody z interfacu InformovanieOzmeneUdajov pre
	 * obrazovku prehladu vyhodnoteni
	 */
	@Override
	public void inform() {

		sutaze = hraVolbyNastaveniaImpl.getSutaze();

		if (sutaze.size() > 0) {
			lblNazovSutaze.setText(sutaze.get(0).getNazov());
			btnVyhodnotitUchadzacaHned.setEnabled(true);
			btnVyhodnotitUchadzacaTask.setEnabled(true);
		} else {
			lblNazovSutaze.setText("V evidencii súťaží nie je žiadna súťaž");
			btnVyhodnotitUchadzacaHned.setEnabled(false);
			btnVyhodnotitUchadzacaTask.setEnabled(false);
		}

		lblMenoUchadzacaNaPrvomMieste.setText("1. miesto");
		lblMenoUchadzacaNaDruhomMieste.setText("2. miesto");
		lblMenoUchadzacaNaTretomMieste.setText("3. miesto");

	}

}
