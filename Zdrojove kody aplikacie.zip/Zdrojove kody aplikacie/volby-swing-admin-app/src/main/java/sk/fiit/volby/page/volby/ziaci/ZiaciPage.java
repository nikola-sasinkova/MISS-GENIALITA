package sk.fiit.volby.page.volby.ziaci;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import sk.fiit.volby.domain.common.Pohlavie;
import sk.fiit.volby.domain.volby.ucastnici.volby.StupenVzdelaniaZiaka;
import sk.fiit.volby.domain.volby.ucastnici.volby.Ziak;
import sk.fiit.volby.start.RunApp;

/**
 * obrazovka na zobrazenie prehladu ziakov
 * 
 * @author nikola
 */
public abstract class ZiaciPage extends JDialog {

	private static final long serialVersionUID = -6674258449463180952L;

	/**
	 * tabulka na zobrazenie prehladu ziakov
	 */
	protected JTable tablePrehladZiakov;

	/**
	 * prazdny konstruktor pre vytvorenie obrazovky prehladu ziakov
	 */
	public ZiaciPage() {

		inicializaciaObrazovky();

	}

	/**
	 * inicializacia obrazovky
	 */
	private void inicializaciaObrazovky() {

		setTitle(RunApp.getProperties().getProperty("prehlad.ziaci.page.title"));
		getContentPane().setLayout(null);
		setSize(740, 324);

		Image imgAdminLogo = new ImageIcon(this.getClass().getResource("/logo.png")).getImage();
		setIconImage(imgAdminLogo);

		JPanel panelPrehladZiakov = new JPanel();
		panelPrehladZiakov.setBorder(new LineBorder(new Color(0, 0, 0)));
		panelPrehladZiakov.setBounds(10, 11, 706, 265);
		getContentPane().add(panelPrehladZiakov);
		panelPrehladZiakov.setLayout(null);

		JScrollPane scrollPane = new JScrollPane();
		// panelPrehladZiakov.setBounds(10, 11, 921, 517);
		scrollPane.setBounds(10, 42, 690, 176);
		panelPrehladZiakov.add(scrollPane);

		// vytvorenie instancie tabulky s prehladom ziakov
		tablePrehladZiakov = new JTable();
		scrollPane.setViewportView(tablePrehladZiakov);
		tablePrehladZiakov.setFillsViewportHeight(true);
		tablePrehladZiakov.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		// nadefinovanie stlpcov, ktore bude obsahovat tabulka
		tablePrehladZiakov.setModel(new DefaultTableModel(new Object[][] {}, new String[] { "Titul pred menom", "meno",
				"stredn\u00E9 meno", "Priezvisko", "Titul za menom", "Identifikátor", "Stupen vzdelania žiaka" }) {

			private static final long serialVersionUID = -4539173740851125583L;

			// tabulka bude klikatelna
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		});

		tablePrehladZiakov.setColumnSelectionAllowed(true);
		tablePrehladZiakov.setCellSelectionEnabled(true);
		tablePrehladZiakov.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));

		tablePrehladZiakov.getColumnModel().getColumn(0).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - zo ziaka si zoberieme
			// titul pred menom, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Ziak ziak = (Ziak) value;
				setText(ziak.getTitulPredMenom());

				return this;
			}
		});

		tablePrehladZiakov.getColumnModel().getColumn(1).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - zo ziaka si zoberieme
			// meno, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Ziak ziak = (Ziak) value;
				setText(ziak.getMeno());

				return this;
			}
		});

		tablePrehladZiakov.getColumnModel().getColumn(2).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - zo ziaka si zoberieme
			// stredne meno, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Ziak ziak = (Ziak) value;
				setText(ziak.getStredneMeno());

				return this;
			}
		});

		tablePrehladZiakov.getColumnModel().getColumn(3).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - zo ziaka si zoberieme
			// priezvisko, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Ziak ziak = (Ziak) value;
				setText(ziak.getPriezvisko());

				return this;
			}
		});

		tablePrehladZiakov.getColumnModel().getColumn(4).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - zo ziaka si zoberieme
			// titul za menom, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Ziak ziak = (Ziak) value;
				setText(ziak.getTitulZaMenom());

				return this;
			}
		});

		tablePrehladZiakov.getColumnModel().getColumn(5).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - zo ziaka si zoberieme
			// identifikator, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Ziak ziak = (Ziak) value;
				setText(ziak.getIdentifikatorZiaka());

				return this;
			}
		});

		tablePrehladZiakov.getColumnModel().getColumn(6).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 3322545462709371147L;

			// customizacia pozadovanej hodnoty v bunke tabulky - zo ziaka si zoberieme
			// stupen vzdelania, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Ziak ziak = (Ziak) value;
				setText(ziak.getStupenVzdelaniaZiaka().name());

				return this;
			}
		});

		JPanel panelPrehladZiakovCaption = new JPanel();
		panelPrehladZiakovCaption.setBackground(new Color(0, 0, 0));
		panelPrehladZiakovCaption.setBounds(0, 0, 921, 31);
		panelPrehladZiakov.add(panelPrehladZiakovCaption);
		panelPrehladZiakovCaption.setLayout(null);

		JLabel lblPrehladZiakovCaption = new JLabel("Prehľad žiakov");
		lblPrehladZiakovCaption.setForeground(new Color(255, 255, 255));
		lblPrehladZiakovCaption.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblPrehladZiakovCaption.setBounds(10, 7, 127, 14);
		panelPrehladZiakovCaption.add(lblPrehladZiakovCaption);

		// tlacitko, ktore sluzi na pridanie noveho ziaka
		JButton btnPridat = new JButton("Pridať");
		btnPridat.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// vytvorenie instancie obrazovky pre aktualizaciu ziaka
				PridatZiakaDialog pridatZiakaDialog = new PridatZiakaDialog(new Ziak()) {

					private static final long serialVersionUID = -9142384259878262885L;

					// volanie metody pre vytvorenie ziaka
					@Override
					protected void vytvoritZiaka(String meno, String stredneMeno, String priezvisko,
							String titulPredMenom, String titulZaMenom, Pohlavie pohlavie, String identifikatorZiaka,
							StupenVzdelaniaZiaka stupenVzdelaniaZiaka) {
						ZiaciPage.this.vytvoritZiaka(meno, stredneMeno, priezvisko, titulPredMenom, titulZaMenom,
								pohlavie, identifikatorZiaka, stupenVzdelaniaZiaka);
					}

				};

				pridatZiakaDialog.setLocationRelativeTo(null);

				// obrazovka bude vzdy zobrazena v popredi
				pridatZiakaDialog.setAlwaysOnTop(true);

				// obrazovka bude modalna
				pridatZiakaDialog.setModal(true);
				pridatZiakaDialog.setVisible(true);

			}
		});
		btnPridat.setBounds(10, 229, 89, 23);
		panelPrehladZiakov.add(btnPridat);

		// button na vymazanie ziaka zo zoznamu ziakov
		JButton btnVymazat = new JButton("Vymazať");
		btnVymazat.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// kontrola, ci je vybrany zaznam v tabulke
				if (tablePrehladZiakov.getSelectionModel().isSelectionEmpty() == false) {

					// identifikacia riadku z tabulky, na ktory pouzivatel klikol
					int row = tablePrehladZiakov.getSelectedRow();

					// identifikacia stlpcu z tabulky, na ktory pouzivatel klikol
					int column = tablePrehladZiakov.getSelectedColumn();

					// ziskanie objektu ziak z pozadovanej bunky tabulky nachadzajucej sa na
					// pozicii row,column
					Ziak vybranyZiakZTabulky = (Ziak) tablePrehladZiakov.getModel().getValueAt(row, column);

					ZiaciPage.this.vymazatZiaka(vybranyZiakZTabulky.getId());

				}
			}
		});
		btnVymazat.setBounds(208, 229, 89, 23);
		panelPrehladZiakov.add(btnVymazat);

		// tlacitko na zobrazenie obrazovky pre aktualizaciu ziaka
		JButton btnUpravit = new JButton("Upraviť");
		btnUpravit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				// kontrola, ci je vybrany zaznam v tabulke
				if (tablePrehladZiakov.getSelectionModel().isSelectionEmpty() == false) {
					// identifikacia riadku z tabulky, na ktory pouzivatel klikol
					int row = tablePrehladZiakov.getSelectedRow();

					// identifikacia stlpcu z tabulky, na ktory pouzivatel klikol
					int column = tablePrehladZiakov.getSelectedColumn();

					// ziskanie objektu ziak z pozadovanej bunky tabulky nachadzajucej sa na
					// pozicii row,column
					Ziak ziak = (Ziak) tablePrehladZiakov.getModel().getValueAt(row, column);

					// vytvorenie instancie obrazovky pre aktualizaciu ziaka
					PridatZiakaDialog pridatZiakaDialog = new PridatZiakaDialog(ziak) {

						private static final long serialVersionUID = -9142384259878262885L;

						// volanie metody pre upravenie ziaka
						@Override
						protected void upravitZiaka(Integer ziakId, String meno, String stredneMeno, String priezvisko,
								String titulPredMenom, String titulZaMenom, Pohlavie pohlavie,
								String identifikatorZiaka, StupenVzdelaniaZiaka stupenVzdelaniaZiaka) {
							ZiaciPage.this.upravitZiaka(ziakId, meno, stredneMeno, priezvisko, titulPredMenom,
									titulZaMenom, pohlavie, identifikatorZiaka, stupenVzdelaniaZiaka);
						}

					};
					pridatZiakaDialog.setLocationRelativeTo(null);
					pridatZiakaDialog.setAlwaysOnTop(true);
					pridatZiakaDialog.setModal(true);
					pridatZiakaDialog.setVisible(true);
				}
			}
		});

		btnUpravit.setBounds(109, 229, 89, 23);
		panelPrehladZiakov.add(btnUpravit);

		// zrusenie okna so zoznamom ziakov
		JButton btnZrusit = new JButton("Zrušiť");
		btnZrusit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ZiaciPage.this.dispose();
			}
		});
		btnZrusit.setBounds(312, 229, 105, 23);
		panelPrehladZiakov.add(btnZrusit);

		// tlacitko na vytvorenie pouzivatela pre ziaka
		JButton btnVytvoritPouzivatela = new JButton("Vytvoriť používateľa");
		btnVytvoritPouzivatela.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				// kontrola, ci je vybrany zaznam v tabulke
				if (tablePrehladZiakov.getSelectionModel().isSelectionEmpty() == false) {
					// identifikacia riadku z tabulky, na ktory pouzivatel klikol
					int row = tablePrehladZiakov.getSelectedRow();

					// identifikacia stlpcu z tabulky, na ktory pouzivatel klikol
					int column = tablePrehladZiakov.getSelectedColumn();

					// ziskanie objektu ziak z pozadovanej bunky tabulky nachadzajucej sa na
					// pozicii row,column
					Ziak ziak = (Ziak) tablePrehladZiakov.getModel().getValueAt(row, column);

					ZiaciPage.this.vytvoritPouzivatelaZoZiaka(ziak);

				}

			}
		});
		btnVytvoritPouzivatela.setBounds(438, 229, 149, 23);
		panelPrehladZiakov.add(btnVytvoritPouzivatela);

	}

	/**
	 * metoda na vytvorenie ziaka s pozadovanymi parametrami
	 * 
	 * @param titulPredMenom       - titul pred menom ziaka
	 * @param meno                 - meno ziaka
	 * @param stredneMeno          - stredne meno ziaka
	 * @param priezvisko           - priezvisko ziaka
	 * @param titulZaMenom         - titul za menom ziaka
	 * @param pohlavie             - pohlavie ziaka
	 * @param identifikatorZiaka   - identifikator ziaka
	 * @param stupenVzdelaniaZiaka - stupen vzdelania ziaka
	 */
	protected abstract void vytvoritZiaka(String meno, String stredneMeno, String priezvisko, String titulPredMenom,
			String titulZaMenom, Pohlavie pohlavie, String identifikatorZiaka,
			StupenVzdelaniaZiaka stupenVzdelaniaZiaka);

	/**
	 * metoda na aktualizaciu ziaka s pozadovanymi parametrami
	 * 
	 * @param ziakId               - identifikator ziaka
	 * @param titulPredMenom       - titul pred menom ziaka
	 * @param meno                 - meno ziaka
	 * @param stredneMeno          - stredne meno ziaka
	 * @param priezvisko           - priezvisko ziaka
	 * @param titulZaMenom         - titul za menom ziaka
	 * @param pohlavie             - pohlavie ziaka
	 * @param identifikatorZiaka   - identifikator ziaka
	 * @param stupenVzdelaniaZiaka - stupen vzdelania ziaka
	 */
	protected abstract void upravitZiaka(int ziakId, String meno, String stredneMeno, String priezvisko,
			String titulPredMenom, String titulZaMenom, Pohlavie pohlavie, String identifikatorZiaka,
			StupenVzdelaniaZiaka stupenVzdelaniaZiaka);

	/**
	 * metoda na vymazanie ziaka
	 * 
	 * @param id               - identifikator ziaka
	 */
	protected abstract void vymazatZiaka(Integer id);

	/**
	 * metoda na vytvorenie pouzivatela pre ziaka
	 * 
	 * @param ziak - ziak, pre ktoreho bude vytvoreny pouzivatel
	 */
	protected abstract void vytvoritPouzivatelaZoZiaka(Ziak ziak);

}
