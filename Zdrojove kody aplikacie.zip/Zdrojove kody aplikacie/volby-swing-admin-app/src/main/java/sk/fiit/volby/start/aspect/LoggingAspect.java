package sk.fiit.volby.start.aspect;

import java.util.Arrays;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

/**
 * trieda, ktora sluzi na definovanie a implementaciu metod, ktore sa volaju pri
 * splneni konfiguracie nad danou metodou
 * 
 * @author nikola
 */
@Aspect
public class LoggingAspect {

	/**
	 * metoda, ktora zalogguje nazov metody, je volana pred metodou, ktora je
	 * definovana konfiguraciou
	 * 
	 * @param joinPoint - objekt obsahujuci udaje vyplyvajuce z aspect
	 * @throws Throwable - chyba, ktora nastane pocas spracovania
	 */
	@Before("execution(* sk.fiit.volby.start.hra.nastavenia.HraVolbyNastaveniaStrategiaVyberovyZoznam.nastavenie(..))")
	public void logBeforeNastavenia(JoinPoint joinPoint) throws Throwable {
		System.out.println("Aspect (before) - method : " + joinPoint.getSignature().getName());
	}

	/**
	 * metoda, ktora zalogguje nazov metody, je volana po metode, ktora je
	 * definovana konfiguraciou
	 * 
	 * @param joinPoint - objekt obsahujuci udaje vyplyvajuce z aspect
	 */
	@After("execution(* sk.fiit.volby.start.hra.nastavenia.HraVolbyNastaveniaStrategiaVyberovyZoznam.nastavenie(..))")
	public void logAfterNastavenia(JoinPoint joinPoint) {
		System.out.println("Aspect (after) - method : " + joinPoint.getSignature().getName());
	}

	/**
	 * metoda, ktora zalogguje nazov metody, je volana po metode, ktora je
	 * definovana konfiguraciou
	 * 
	 * @param joinPoint - objekt obsahujuci udaje vyplyvajuce z aspect
	 * @throws Throwable - chyba, ktora nastane pocas spracovania
	 */
	@Before("execution(* sk.fiit.volby.page.volby.hodnotenie.vysledok.VyhodnotenieUchadzacovPanel.vyhodnot(..))")
	public void logBeforevyhodnotenie(JoinPoint joinPoint) throws Throwable {
		System.out.println("Aspect (before) - method : " + joinPoint.getSignature().getName());
		System.out.println("arguments : " + Arrays.toString(joinPoint.getArgs()));
	}

}
