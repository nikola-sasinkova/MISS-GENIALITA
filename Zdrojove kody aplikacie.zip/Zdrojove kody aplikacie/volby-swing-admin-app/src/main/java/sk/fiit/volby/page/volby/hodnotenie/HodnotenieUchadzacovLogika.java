package sk.fiit.volby.page.volby.hodnotenie;

import java.util.List;

import javax.swing.table.DefaultTableModel;

import sk.fiit.volby.domain.volby.Sutaz;
import sk.fiit.volby.domain.volby.ucastnici.volby.Uchadzac;
import sk.fiit.volby.start.hra.InformovanieOzmeneUdajov;
import sk.fiit.volby.start.hra.nastavenia.HraVolbyNastaveniaImpl;

/**
 * obrazovka na zobrazenie prehladu hodnoteni (externalizovana logika vramci
 * ktorej je implementovana metoda inform, sluzi na aktualizaciu udajov)
 * 
 * @author nikola
 */
public class HodnotenieUchadzacovLogika extends HodnotenieUchadzacovPanel implements InformovanieOzmeneUdajov {

	private static final long serialVersionUID = -6419221107898781854L;

	/**
	 * aktualna instancia beziacej hry
	 */
	private HraVolbyNastaveniaImpl hraVolbyNastaveniaImpl;

	/**
	 * zoznam sutazi, ktore sa budu zobrazovat v comboboxe s prehladom sutazi
	 */
	private List<Sutaz> sutaze;

	/**
	 * zoznam uchadzacov, ktori sa budu zobrazovat v tabulke s prehladom uchadzacov
	 */
	private List<Uchadzac> uchadzaci;

	/**
	 * konstruktor pre vytvorenie obrazovky prehladu hodnoteni s pozadovanymi
	 * parametrami
	 * 
	 * @param hraVolbyNastaveniaImpl - instancia mojej hry
	 */
	public HodnotenieUchadzacovLogika(HraVolbyNastaveniaImpl hraVolbyNastaveniaImpl) {
		super(hraVolbyNastaveniaImpl);
		this.hraVolbyNastaveniaImpl = hraVolbyNastaveniaImpl;
	}

	/**
	 * konkretna implementacia metody z interfacu InformovanieOzmeneUdajov pre
	 * obrazovku prehladu hodnoteni
	 */
	@Override
	public void inform() {

		sutaze = hraVolbyNastaveniaImpl.getSutaze();
		uchadzaci = hraVolbyNastaveniaImpl.getUchadzaci();

		if (sutaze.size() > 0) {
			lblNazovSutaze.setText(sutaze.get(0).getNazov());
		} else {
			lblNazovSutaze.setText("V evidencii súťaží nie je žiadna súťaž");
		}

		if (uchadzaci.size() > 0) {
			btnHodnotitUchadzacaPorotca.setEnabled(true);
			btnHodnotitUchadzacaZiak.setEnabled(true);
		} else {
			btnHodnotitUchadzacaPorotca.setEnabled(false);
			btnHodnotitUchadzacaZiak.setEnabled(false);
		}

		DefaultTableModel modelUchadzaci = (DefaultTableModel) tablePrehladUchadzacov.getModel();
		modelUchadzaci.setRowCount(0);
		if (uchadzaci != null) {
			for (Uchadzac uchadzac : uchadzaci) {
				if (uchadzac.getVyskumnaPraca() != null && uchadzac.getVyskumnaPraca().getNazov().trim() != ""
						&& uchadzac.getVyskumnaPraca().getPopis().trim() != "") {
					modelUchadzaci.addRow(new Object[] { uchadzac, uchadzac, uchadzac, uchadzac, uchadzac, uchadzac,
							uchadzac, uchadzac, uchadzac, uchadzac, uchadzac });
				}
			}
		}

	}

	/**
	 * implementacia metody, ktora zabezpecuje aktualne zobrazenie finalneho poctu
	 * bodov od porotcu na uchadzacovi v prehlade uchadzacov
	 */
	@Override
	protected void refreshPrehladUcastnikov() {
		inform();
	}

}
