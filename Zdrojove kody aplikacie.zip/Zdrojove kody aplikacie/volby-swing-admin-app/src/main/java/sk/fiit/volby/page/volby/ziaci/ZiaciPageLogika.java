package sk.fiit.volby.page.volby.ziaci;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

import javax.swing.table.DefaultTableModel;

import sk.fiit.volby.domain.common.Pohlavie;
import sk.fiit.volby.domain.pouzivatel.Pouzivatel;
import sk.fiit.volby.domain.skola.Skola;
import sk.fiit.volby.domain.volby.ucastnici.volby.StupenVzdelaniaZiaka;
import sk.fiit.volby.domain.volby.ucastnici.volby.Ziak;
import sk.fiit.volby.start.hra.InformovanieOzmeneUdajov;
import sk.fiit.volby.start.hra.nastavenia.HraVolbyNastaveniaImpl;

/**
 * trieda, ktora vychadza (sa dedi) z obrazovky s prehladom ziakov, a ktora sa
 * pouziva v navrhovom vzore Observer
 * 
 * @author nikola
 */
public class ZiaciPageLogika extends ZiaciPage implements InformovanieOzmeneUdajov {

	private static final long serialVersionUID = -2686446594274111459L;

	/**
	 * aktualna instancia beziacej hry
	 */
	private HraVolbyNastaveniaImpl hraVolbyNastaveniaImpl;

	/**
	 * zoznam ziakov, ktori sa budu zobrazovat v tabulke s prehladom ziakov
	 */
	private List<Ziak> ziaci;

	/**
	 * zoznam pouzivatelov, ktori sa budu prihlasovat do aplikacie
	 */
	private List<Pouzivatel> pouzivatelia;

	/**
	 * konstruktor pre vytvorenie obrazovky prehladu ziakov s pozadovanymi
	 * parametrami
	 * 
	 * @param hraVolbyNastaveniaImpl - instancia mojej hry
	 */
	public ZiaciPageLogika(HraVolbyNastaveniaImpl hraVolbyNastaveniaImpl) {
		super();
		this.hraVolbyNastaveniaImpl = hraVolbyNastaveniaImpl;
	}

	/**
	 * konkretna implementacia metody z interfacu InformovanieOzmeneUdajov pre
	 * obrazovku prehladu ziakov
	 */
	@Override
	public void inform() {
		// ziskanie aktualnych ziakov z instancie mojej hry
		ziaci = hraVolbyNastaveniaImpl.getZiaci();

		// ziskanie aktualnych pouzivatelov z instancie mojej hry
		pouzivatelia = hraVolbyNastaveniaImpl.getPouzivatelia();

		// ziskanie modelu tabulky, ktory zobrazuje prehlad ziakov
		DefaultTableModel model = (DefaultTableModel) tablePrehladZiakov.getModel();

		// vynulovanie poctu riadkov v modeli tabulky
		model.setRowCount(0);

		// prechadzanie zoznamu ziakov a plnenie riadkov tabulky
		if (ziaci != null) {
			for (Ziak ziak : ziaci) {
				model.addRow(new Object[] { ziak, ziak, ziak, ziak, ziak, ziak, ziak });
			}
		}

	}

	/**
	 * metoda na aktualizaciu ziaka s pozadovanymi parametrami
	 * 
	 * @param ziakId               - identifikator ziaka
	 * @param titulPredMenom       - titul pred menom ziaka
	 * @param meno                 - meno ziaka
	 * @param stredneMeno          - stredne meno ziaka
	 * @param priezvisko           - priezvisko ziaka
	 * @param titulZaMenom         - titul za menom ziaka
	 * @param pohlavie             - pohlavie ziaka
	 * @param identifikatorZiaka   - identifikator ziaka
	 * @param stupenVzdelaniaZiaka - stupen vzdelania ziaka
	 */
	@Override
	protected void upravitZiaka(int ziakId, String meno, String stredneMeno, String priezvisko, String titulPredMenom,
			String titulZaMenom, Pohlavie pohlavie, String identifikatorZiaka,
			StupenVzdelaniaZiaka stupenVzdelaniaZiaka) {

		// vyber prvej skoly v poradi zo zoznamu skol (kedze mam len jednu skolu, vybera
		// sa konkretna skola)
		Skola skola = hraVolbyNastaveniaImpl.getSkoly().get(0);

		// prechadzanie zoznamu ziakov definovanych v hre
		for (Ziak ziak : ziaci) {

			// ak sa zhoduje id ziaka s id vybraneho ziaka zo zoznamu,
			// vybraneho ziaka aktualizujeme
			if (ziak.getId().equals(ziakId)) {
				ziak.setSkola(skola);
				ziak.setMeno(meno);
				ziak.setStredneMeno(stredneMeno);
				ziak.setPriezvisko(priezvisko);
				ziak.setTitulPredMenom(titulPredMenom);
				ziak.setTitulZaMenom(titulZaMenom);
				ziak.setPohlavie(pohlavie);
				ziak.setIdentifikatorZiaka(identifikatorZiaka);
				ziak.setStupenVzdelaniaZiaka(stupenVzdelaniaZiaka);

				// zavolanie konkretnej imlementacie metody inform z interfacu DataFollower
				inform();

				break;

			}

		}

	}

	/**
	 * metoda na vytvorenie ziaka s pozadovanymi parametrami
	 * 
	 * @param titulPredMenom       - titul pred menom ziaka
	 * @param meno                 - meno ziaka
	 * @param stredneMeno          - stredne meno ziaka
	 * @param priezvisko           - priezvisko ziaka
	 * @param titulZaMenom         - titul za menom ziaka
	 * @param pohlavie             - pohlavie ziaka
	 * @param identifikatorZiaka   - identifikator ziaka
	 * @param stupenVzdelaniaZiaka - stupen vzdelania ziaka
	 */
	@Override
	protected void vytvoritZiaka(String meno, String stredneMeno, String priezvisko, String titulPredMenom,
			String titulZaMenom, Pohlavie pohlavie, String identifikatorZiaka,
			StupenVzdelaniaZiaka stupenVzdelaniaZiaka) {

		// vyber prvej skoly v poradi zo zoznamu skol (kedze mam len jednu skolu, vybera
		// sa konkretna skola)
		Skola skola = hraVolbyNastaveniaImpl.getSkoly().get(0);

		// zoradenie zoznamu ziakov vzostupne podla id od najmensieho po najvacsie
		Collections.sort(ziaci, Comparator.comparing(Ziak::getId));

		// ziskanie najvacsej hodnoty id nachadzajucej sa v zozname a pripocitanie 1, ak
		// je zoznam prazdny id nastavim na 1
		int id = ziaci.size() == 0 ? 1 : ziaci.get(ziaci.size() - 1).getId() + 1;

		// vytvorenie instancie ziaka s pozadovanymi parametrami
		Ziak ziak = new Ziak(skola, id, meno, stredneMeno, priezvisko, titulPredMenom, titulZaMenom, pohlavie,
				identifikatorZiaka, stupenVzdelaniaZiaka);

		// zaradenie vytvoreneho ziaka do zoznamu ziakoc v mojej hre
		ziaci.add(ziak);

		// zavolanie konkretnej imlementacie metody inform z interfacu DataFollower
		inform();

	}

	/**
	 * metoda na vymazanie ziaka
	 * 
	 * @param id - identifikator ziaka
	 */
	@Override
	protected void vymazatZiaka(Integer id) {

		// prechadzanie zoznamu ziakov
		for (Ziak ziak : ziaci) {

			// ak sa zhoduje id ziaka s id vybraneho ziaka zo zoznamu,
			// vybraneho ziaka odstranime
			if (ziak.getId().equals(id)) {

				// odstranenie ziaka zo zoznamu
				ziaci.remove(ziak);

				// volanie implementacie metody inform z interfacu DataFollower, ktora sluzi na
				// refresh udajov v tabulke
				inform();
				break;
			}

		}

	}

	/**
	 * metoda, ktora sluzi na vytvorenie pouzivatela pre ziaka
	 */
	@Override
	protected void vytvoritPouzivatelaZoZiaka(Ziak ziak) {

		Collections.sort(pouzivatelia, Comparator.comparing(Pouzivatel::getId));
		int id = pouzivatelia.size() == 0 ? 1 : pouzivatelia.get(pouzivatelia.size() - 1).getId() + 1;

		Pouzivatel pouzivatel = new Pouzivatel(id, "login-" + ziak.getPriezvisko(), generateHeslo(10), ziak);
		pouzivatelia.add(pouzivatel);

		inform();

		hraVolbyNastaveniaImpl.informInformovanieOzmeneUdajovList();

	}

	/**
	 * metoda, ktora sluzi na vygenerovanie hesla
	 * 
	 * @param length - pocet znakov v hesle
	 * @return heslo
	 */
	private String generateHeslo(int length) {
		String bigLetter = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		String smallLetter = "abcdefghijklmnopqrstuvwxyz";

		StringBuilder sb = new StringBuilder();
		Random random = new Random();
		for (int i = 0; i < 1; i++) {
			sb.append(bigLetter.charAt(random.nextInt(bigLetter.length())));
		}
		for (int i = 0; i < length; i++) {
			sb.append(smallLetter.charAt(random.nextInt(smallLetter.length())));
		}

		return sb.toString();
	}

}
