package sk.fiit.volby.page.volby.uchadzaci;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import sk.fiit.volby.domain.volby.Sutaz;
import sk.fiit.volby.domain.volby.ucastnici.volby.Uchadzac;
import sk.fiit.volby.domain.volby.ucastnici.volby.Ziak;
import sk.fiit.volby.start.RunApp;
import sk.fiit.volby.start.hra.nastavenia.HraVolbyNastaveniaImpl;

/**
 * obrazovka na zobrazenie prehladu uchadzacov
 * 
 * @author nikola
 */
public abstract class UchadzaciPage extends JDialog {

	private static final long serialVersionUID = 2940219034336827522L;

	/**
	 * tabulka na zobrazenie prehladu ziakov
	 */
	protected JTable tablePrehladZiakov;

	/**
	 * tabulka na zobrazenie prehladu uchadzacov
	 */
	protected JTable tablePrehladUchadzacov;

	/**
	 * tlacidlo na pridanie ziaka
	 */
	protected JButton btnPridatZiaka;

	/**
	 * konstruktor pre vytvorenie obrazovky prehladu uchadzacov s pozadovanym
	 * parametrom
	 * 
	 * @param hraVolbyNastaveniaImpl - instancia mojej hry
	 */
	public UchadzaciPage(final HraVolbyNastaveniaImpl hraVolbyNastaveniaImpl) {

		inicializaciaObrazovky(hraVolbyNastaveniaImpl);

	}

	/**
	 * inicializacia obrazovky
	 * 
	 * @param hraVolbyNastaveniaImpl - instancia mojej hry
	 */
	public void inicializaciaObrazovky(final HraVolbyNastaveniaImpl hraVolbyNastaveniaImpl) {

		setTitle(RunApp.getProperties().getProperty("prehlad.uchadzacov.page.title"));

		getContentPane().setLayout(null);
		setSize(955, 605);

		Image imgAdminLogo = new ImageIcon(this.getClass().getResource("/logo.png")).getImage();
		setIconImage(imgAdminLogo);

		JPanel panelPrehladZiakov = new JPanel();
		panelPrehladZiakov.setBorder(new LineBorder(new Color(0, 0, 0)));
		panelPrehladZiakov.setBounds(10, 11, 921, 547);
		getContentPane().add(panelPrehladZiakov);
		panelPrehladZiakov.setLayout(null);

		JPanel panelPrehladZiakovCaption = new JPanel();
		panelPrehladZiakovCaption.setBackground(new Color(0, 0, 0));
		panelPrehladZiakovCaption.setBounds(0, 0, 921, 31);
		panelPrehladZiakov.add(panelPrehladZiakovCaption);
		panelPrehladZiakovCaption.setLayout(null);

		JLabel lblPrehladZiakovCaption = new JLabel("Prehlad ziakov a uchadzacov");
		lblPrehladZiakovCaption.setForeground(new Color(255, 255, 255));
		lblPrehladZiakovCaption.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblPrehladZiakovCaption.setBounds(10, 7, 199, 14);
		panelPrehladZiakovCaption.add(lblPrehladZiakovCaption);

		JLabel lblPrehladZiakovLabel = new JLabel("Prehľad žiakov");
		lblPrehladZiakovLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblPrehladZiakovLabel.setBounds(10, 42, 110, 14);
		panelPrehladZiakov.add(lblPrehladZiakovLabel);

		JScrollPane scrollPanePrehladZiakov = new JScrollPane();
		scrollPanePrehladZiakov.setBounds(10, 71, 901, 175);
		panelPrehladZiakov.add(scrollPanePrehladZiakov);

		// vytvorenie instancie tabulky s prehladom ziakov
		tablePrehladZiakov = new JTable();
		tablePrehladZiakov.setFillsViewportHeight(true);
		tablePrehladZiakov.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		// nadefinovanie stlpcov, ktore bude obsahovat tabulka
		tablePrehladZiakov.setModel(new DefaultTableModel(new Object[][] {}, new String[] { "Titul pred menom", "Meno",
				"Stredné meno", "Priezvisko", "Titul za menom", "Pohlavie", "Identifikator", "Stupen vzdelania" }) {

			private static final long serialVersionUID = -5459399120597283875L;

			// tabulka bude klikatelna
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}

		});
		tablePrehladZiakov.getColumnModel().getColumn(0).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - zo ziaka si zoberieme
			// titul pred menom, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Ziak ziak = (Ziak) value;
				setText(ziak.getTitulPredMenom());

				return this;
			}
		});
		tablePrehladZiakov.getColumnModel().getColumn(1).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - zo ziaka si zoberieme
			// meno, ktore budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Ziak ziak = (Ziak) value;
				setText(ziak.getMeno());

				return this;
			}
		});
		tablePrehladZiakov.getColumnModel().getColumn(2).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - zo ziaka si zoberieme
			// stredne meno, ktore budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Ziak ziak = (Ziak) value;
				setText(ziak.getStredneMeno());

				return this;
			}
		});
		tablePrehladZiakov.getColumnModel().getColumn(3).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - zo ziaka si zoberieme
			// priezvisko, ktore budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Ziak ziak = (Ziak) value;
				setText(ziak.getPriezvisko());

				return this;
			}
		});
		tablePrehladZiakov.getColumnModel().getColumn(4).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - zo ziaka si zoberieme
			// titul za menom, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Ziak ziak = (Ziak) value;
				setText(ziak.getTitulZaMenom());

				return this;
			}
		});
		tablePrehladZiakov.getColumnModel().getColumn(5).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - zo ziaka si zoberieme
			// pohlavie, ktore budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Ziak ziak = (Ziak) value;
				setText(RunApp.getProperties().getProperty(ziak.getPohlavie().name()));

				return this;
			}
		});
		tablePrehladZiakov.getColumnModel().getColumn(6).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - zo ziaka si zoberieme
			// identifikator, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Ziak ziak = (Ziak) value;
				setText(ziak.getIdentifikatorZiaka());

				return this;
			}
		});

		tablePrehladZiakov.getColumnModel().getColumn(7).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - zo ziaka si zoberieme
			// stupen vzdelania ziaka, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Ziak ziak = (Ziak) value;
				setText(ziak.getStupenVzdelaniaZiaka().name());

				return this;
			}
		});

		scrollPanePrehladZiakov.setBorder(new MatteBorder(1, 0, 0, 0, (Color) new Color(192, 192, 192)));
		scrollPanePrehladZiakov.setViewportView(tablePrehladZiakov);

		// tlacitko na zobrazenie obrazovky pre zaradenie ziaka medzi uchadzacov, do
		// konkretnej sutaze
		btnPridatZiaka = new JButton("Pridať");
		btnPridatZiaka.setEnabled(false);
		btnPridatZiaka.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (tablePrehladZiakov.getSelectionModel().isSelectionEmpty() == false) {
					int row = tablePrehladZiakov.getSelectedRow();
					int column = tablePrehladZiakov.getSelectedColumn();
					Ziak ziak = (Ziak) tablePrehladZiakov.getModel().getValueAt(row, column);

					ZaraditZiakaMedziUchadzacovDialog zaraditZiakaMedziUchadzacovDialog = new ZaraditZiakaMedziUchadzacovDialog(
							hraVolbyNastaveniaImpl, ziak) {

						private static final long serialVersionUID = 7238216039142941838L;

						@Override
						protected void zaraditZiakaMedziUchadzacov(Ziak ziak, Sutaz sutaz) {
							UchadzaciPage.this.zaraditZiakaMedziUchadzacov(ziak, sutaz);
						}

					};
					zaraditZiakaMedziUchadzacovDialog.setLocationRelativeTo(null);
					zaraditZiakaMedziUchadzacovDialog.setAlwaysOnTop(true);
					zaraditZiakaMedziUchadzacovDialog.setModal(true);
					zaraditZiakaMedziUchadzacovDialog.setVisible(true);

				}

			}
		});
		btnPridatZiaka.setBounds(10, 257, 90, 23);
		panelPrehladZiakov.add(btnPridatZiaka);

		// uchadzaci
		JLabel lblPrehladUchadzacovLabel = new JLabel("Prehlad uchadzacov");
		lblPrehladUchadzacovLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblPrehladUchadzacovLabel.setBounds(10, 303, 137, 14);
		panelPrehladZiakov.add(lblPrehladUchadzacovLabel);

		JScrollPane scrollPanePrehladUchadzacov = new JScrollPane();
		scrollPanePrehladUchadzacov.setBorder(new MatteBorder(1, 0, 0, 0, (Color) new Color(192, 192, 192)));
		scrollPanePrehladUchadzacov.setBounds(10, 328, 901, 175);

		// vytvorenie instancie tabulky s prehladom uchadzacov
		tablePrehladUchadzacov = new JTable();
		tablePrehladUchadzacov.setFillsViewportHeight(true);
		tablePrehladUchadzacov.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		// nadefinovanie stlpcov, ktore bude obsahovat tabulka
		tablePrehladUchadzacov.setModel(new DefaultTableModel(new Object[][] {},
				new String[] { "Titul pred menom", "Meno", "Stredné meno", "Priezvisko", "Titul za menom", "Pohlavie",
						"Identifikator", "Pouzivatel", "Sutaz", "Skola", "Stupen vzdelania" }) {

			private static final long serialVersionUID = -5459399120597283875L;

			// tabulka bude klikatelna
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}

		});
		tablePrehladUchadzacov.getColumnModel().getColumn(0).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - z uchadzaca si zoberieme
			// titul pred menom, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Uchadzac uchadzac = (Uchadzac) value;
				setText(uchadzac.getTitulPredMenom());

				return this;
			}
		});
		tablePrehladUchadzacov.getColumnModel().getColumn(1).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - z uchadzaca si zoberieme
			// meno, ktore budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Uchadzac uchadzac = (Uchadzac) value;
				setText(uchadzac.getMeno());

				return this;
			}
		});
		tablePrehladUchadzacov.getColumnModel().getColumn(2).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - z uchadzaca si zoberieme
			// stredne meno, ktore budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Uchadzac uchadzac = (Uchadzac) value;
				setText(uchadzac.getStredneMeno());

				return this;
			}
		});
		tablePrehladUchadzacov.getColumnModel().getColumn(3).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - z uchadzaca si zoberieme
			// priezvisko, ktore budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Uchadzac uchadzac = (Uchadzac) value;
				setText(uchadzac.getPriezvisko());

				return this;
			}
		});
		tablePrehladUchadzacov.getColumnModel().getColumn(4).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - z uchadzaca si zoberieme
			// titul za menom, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Uchadzac uchadzac = (Uchadzac) value;
				setText(uchadzac.getTitulZaMenom());

				return this;
			}
		});
		tablePrehladUchadzacov.getColumnModel().getColumn(5).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - z uchadzaca si zoberieme
			// pohlavie, ktore budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Uchadzac uchadzac = (Uchadzac) value;
				setText(RunApp.getProperties().getProperty(uchadzac.getPohlavie().name()));

				return this;
			}
		});
		tablePrehladUchadzacov.getColumnModel().getColumn(6).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - z uchadzaca si zoberieme
			// identifikator, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Uchadzac uchadzac = (Uchadzac) value;
				setText(uchadzac.getIdentifikatorZiaka());

				return this;
			}
		});
		tablePrehladUchadzacov.getColumnModel().getColumn(7).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// TODO bude dokoncene
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

//				Uchadzac uchadzac = (Uchadzac) value;
//
//				Pouzivatel pouzivatel = uchadzac.getPouzivatel();
//				setText(pouzivatel != null && pouzivatel.getOsoba() instanceof Uchadzac ? "Ano" : "");
				setText("");

				return this;
			}
		});
		tablePrehladUchadzacov.getColumnModel().getColumn(8).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - z uchadzaca si zoberieme
			// nazov sutaze, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Uchadzac uchadzac = (Uchadzac) value;
				if (uchadzac.getSutaz() != null) {
					setText(uchadzac.getSutaz().getNazov());
				}

				return this;
			}
		});
		tablePrehladUchadzacov.getColumnModel().getColumn(9).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - z uchadzaca si zoberieme
			// nazov skoly, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Uchadzac uchadzac = (Uchadzac) value;
				setText(uchadzac.getSkola().getNazov());

				return this;
			}
		});

		tablePrehladUchadzacov.getColumnModel().getColumn(10).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - z uchadzaca si zoberieme
			// stupen vzdelania ziaka, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Uchadzac uchadzac = (Uchadzac) value;
				setText(uchadzac.getStupenVzdelaniaZiaka().name());

				return this;
			}
		});

		scrollPanePrehladUchadzacov.setBorder(new MatteBorder(1, 0, 0, 0, (Color) new Color(192, 192, 192)));
		scrollPanePrehladUchadzacov.setViewportView(tablePrehladUchadzacov);
		panelPrehladZiakov.add(scrollPanePrehladUchadzacov);

		// tlacitko na odobratie uchadzacov zo sutaze
		JButton btnOdobratUchadzaca = new JButton("Odobrat uchadzaca");
		btnOdobratUchadzaca.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (tablePrehladUchadzacov.getSelectionModel().isSelectionEmpty() == false) {
					int row = tablePrehladUchadzacov.getSelectedRow();
					int column = tablePrehladUchadzacov.getSelectedColumn();

					Uchadzac uchadzac = (Uchadzac) tablePrehladUchadzacov.getModel().getValueAt(row, column);
					UchadzaciPage.this.odobratUchadzacaZoZoznamuUchadzacov(uchadzac.getId());

				}

			}
		});
		btnOdobratUchadzaca.setBounds(10, 514, 148, 23);
		panelPrehladZiakov.add(btnOdobratUchadzaca);

		JButton btnZrusit = new JButton("Zrušiť ");
		btnZrusit.setBounds(165, 514, 89, 23);
		panelPrehladZiakov.add(btnZrusit);
		btnZrusit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UchadzaciPage.this.dispose();
			}
		});

	}

	/**
	 * metoda, ktora zaradi ziaka medzi uchadzacov
	 * 
	 * @param ziak  - ziak, ktory sa prihlasil do sutaze
	 * @param sutaz - sutaz, do ktorej sa ziak prihlasil
	 */
	protected abstract void zaraditZiakaMedziUchadzacov(Ziak ziak, Sutaz sutaz);

	/**
	 * metoda na odobratie uchadzaca zo zoznamu uchadzacov
	 * 
	 * @param uchadzacId - identifikator uchadzaca
	 */
	protected abstract void odobratUchadzacaZoZoznamuUchadzacov(Integer uchadzacId);

}
