package sk.fiit.volby.start.hra.nastavenia;

import java.util.List;

import sk.fiit.volby.domain.pouzivatel.Pouzivatel;
import sk.fiit.volby.domain.skola.Skola;
import sk.fiit.volby.domain.volby.Rocnik;
import sk.fiit.volby.domain.volby.Sutaz;
import sk.fiit.volby.domain.volby.ucastnici.volby.Porotca;
import sk.fiit.volby.domain.volby.ucastnici.volby.StupenVzdelaniaZiaka;
import sk.fiit.volby.domain.volby.ucastnici.volby.Uchadzac;
import sk.fiit.volby.domain.volby.ucastnici.volby.UchadzacBakalarskehoStudia;
import sk.fiit.volby.domain.volby.ucastnici.volby.UchadzacInzinierskehoStudia;
import sk.fiit.volby.domain.volby.ucastnici.volby.Ziak;

/**
 * interface, ktory poskytuje metody na vytvorenie udajov podla zvolenej
 * strategie alebo nacitanie udajov zo suboru do spustenej hry
 * 
 * @author nikola
 */
public interface HraVolbyNastavenia {

	/**
	 * metoda sluzi na vytvorenie udajov podla zvolenej strategie a ich naplnenie do
	 * spustenej hry
	 * 
	 * @param skoly        - zoznam skol v hre
	 * @param porotcovia   - zoznam porotcov v hre
	 * @param ziaci        - zoznam ziakov v hre
	 * @param uchadzaci    - zoznam uchadzacov v hre
	 * @param rocniky      - zoznam rocnikov v hre
	 * @param sutaze       - zoznam sutazi v hre
	 * @param pouzivatelia - zoznam pouzivtelov v hre
	 */
	void nastavenie(List<Skola> skoly, List<Porotca> porotcovia, List<Ziak> ziaci, List<Uchadzac> uchadzaci,
			List<Rocnik> rocniky, List<Sutaz> sutaze, List<Pouzivatel> pouzivatelia);

	/**
	 * metoda sluzi na naplnenie udajov nacitanych zo suboru podla zvolenej
	 * strategie do spustenej hry, default zabezpeci, ze v rozhrani mozem
	 * implemenotvat tuto metodu
	 * 
	 * @param skoly               - zoznam skol v hre
	 * @param porotcovia          - zoznam porotcov v hre
	 * @param ziaci               - zoznam ziakov v hre
	 * @param uchadzaci           - zoznam uchadzacov v hre
	 * @param rocniky             - zoznam rocnikov v hre
	 * @param sutaze              - zoznam sutazi v hre
	 * @param pouzivatelia        - zoznam pouzivtelov v hre
	 * @param loadedVolbyGameData - nahrane udaje zo suboru
	 */
	default void nacitanie(List<Skola> skoly, List<Porotca> porotcovia, List<Ziak> ziaci, List<Uchadzac> uchadzaci,
			List<Rocnik> rocniky, List<Sutaz> sutaze, List<Pouzivatel> pouzivatelia,
			HraVolbyNastaveniaImpl loadedVolbyGameData) {

		if (loadedVolbyGameData.getSkoly() != null) {
			for (Skola skola : loadedVolbyGameData.getSkoly()) {
				skoly.add(new Skola(skola.getId(), skola.getTyp(), skola.getNazov(), skola.getAdresa(),
						skola.getKontakt()));
			}
		}

		if (loadedVolbyGameData.getPorotcovia() != null) {
			for (Porotca porotca : loadedVolbyGameData.getPorotcovia()) {
				porotcovia.add(new Porotca(porotca.getSkola(), porotca.getId(), porotca.getTitulPredMenom(),
						porotca.getMeno(), porotca.getStredneMeno(), porotca.getPriezvisko(), porotca.getTitulZaMenom(),
						porotca.getPohlavie(), porotca.getRolaPorotcu()));
			}
		}

		if (loadedVolbyGameData.getZiaci() != null) {
			for (Ziak ziak : loadedVolbyGameData.getZiaci()) {
				ziaci.add(new Ziak(ziak.getSkola(), ziak.getId(), ziak.getMeno(), ziak.getStredneMeno(),
						ziak.getPriezvisko(), ziak.getTitulPredMenom(), ziak.getTitulZaMenom(), ziak.getPohlavie(),
						ziak.getIdentifikatorZiaka(), ziak.getStupenVzdelaniaZiaka()));
			}
		}

		if (loadedVolbyGameData.getRocniky() != null) {
			for (Rocnik rocnik : loadedVolbyGameData.getRocniky()) {
				rocniky.add(new Rocnik(rocnik.getSkola(), rocnik.getId(), rocnik.getNazov(),
						rocnik.getZaciatokSemestra(), rocnik.getKoniecSemestra()));
			}
		}

		if (loadedVolbyGameData.getSutaze() != null) {
			for (Sutaz loadedSutaz : loadedVolbyGameData.getSutaze()) {
				Sutaz sutaz = new Sutaz(loadedSutaz.getId(), loadedSutaz.getSkola(), loadedSutaz.getRocnik(),
						loadedSutaz.getNazov(), loadedSutaz.getPopis(), loadedSutaz.getDatumUkonceniaPrihlasovania(),
						loadedSutaz.getDatumSpusteniaHlasovania(), loadedSutaz.getDatumZverejnenia());
				sutaze.add(sutaz);
				if (loadedVolbyGameData.getUchadzaci() != null) {
					for (Uchadzac loadedUchadzac : loadedVolbyGameData.getUchadzaci()) {
						if (loadedUchadzac.getSutaz().getId().equals(sutaz.getId())) {
							if (StupenVzdelaniaZiaka.BAKALARSKE_STUDIUM
									.equals(loadedUchadzac.getStupenVzdelaniaZiaka())) {
								UchadzacBakalarskehoStudia uchadzacBakalarskehoStudia = new UchadzacBakalarskehoStudia(
										loadedUchadzac.getSkola(), loadedUchadzac.getId(), loadedUchadzac.getMeno(),
										loadedUchadzac.getStredneMeno(), loadedUchadzac.getPriezvisko(),
										loadedUchadzac.getTitulPredMenom(), loadedUchadzac.getTitulZaMenom(),
										loadedUchadzac.getPohlavie(), loadedUchadzac.getIdentifikatorZiaka(),
										loadedUchadzac.isKvalifikovany(), sutaz,
										StupenVzdelaniaZiaka.BAKALARSKE_STUDIUM);
								uchadzacBakalarskehoStudia.setVyskumnaPraca(loadedUchadzac.getVyskumnaPraca());
								uchadzacBakalarskehoStudia.setPriebezneHodnoteniaPorotcov(
										loadedUchadzac.getPriebezneHodnoteniaPorotcov());
								uchadzacBakalarskehoStudia
										.setPriebezneHodnoteniaZiakov(loadedUchadzac.getPriebezneHodnoteniaZiakov());
								uchadzacBakalarskehoStudia.setFinalneHodnotenie(loadedUchadzac.getFinalneHodnotenie());
								uchadzaci.add(uchadzacBakalarskehoStudia);
							} else {
								UchadzacInzinierskehoStudia uchadzacInzinierskehoStudia = new UchadzacInzinierskehoStudia(
										loadedUchadzac.getSkola(), loadedUchadzac.getId(), loadedUchadzac.getMeno(),
										loadedUchadzac.getStredneMeno(), loadedUchadzac.getPriezvisko(),
										loadedUchadzac.getTitulPredMenom(), loadedUchadzac.getTitulZaMenom(),
										loadedUchadzac.getPohlavie(), loadedUchadzac.getIdentifikatorZiaka(),
										loadedUchadzac.isKvalifikovany(), sutaz,
										StupenVzdelaniaZiaka.INZINIERSKE_STUDIUM);
								uchadzacInzinierskehoStudia.setPriebezneHodnoteniaPorotcov(
										loadedUchadzac.getPriebezneHodnoteniaPorotcov());
								uchadzacInzinierskehoStudia
										.setPriebezneHodnoteniaZiakov(loadedUchadzac.getPriebezneHodnoteniaZiakov());
								uchadzacInzinierskehoStudia.setFinalneHodnotenie(loadedUchadzac.getFinalneHodnotenie());
								uchadzacInzinierskehoStudia.setVyskumnaPraca(loadedUchadzac.getVyskumnaPraca());
								uchadzaci.add(uchadzacInzinierskehoStudia);
							}
						}
					}
				}

			}
		}

		if (loadedVolbyGameData.getPouzivatelia() != null) {
			for (Pouzivatel pouzivatel : loadedVolbyGameData.getPouzivatelia()) {
				pouzivatelia.add(new Pouzivatel(pouzivatel.getId(), pouzivatel.getLogin(), pouzivatel.getHeslo()));
			}
		}

	}

}
