package sk.fiit.volby.page.pracovna.plocha;

import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

import sk.fiit.volby.domain.volby.Sutaz;
import sk.fiit.volby.domain.volby.ucastnici.volby.Uchadzac;
import sk.fiit.volby.page.prihlasovanie.PrihlasovaniePage;
import sk.fiit.volby.page.skoly.SkolyPageLogika;
import sk.fiit.volby.page.volby.hodnotenie.HodnotenieUchadzacovLogika;
import sk.fiit.volby.page.volby.hodnotenie.vysledok.VyhodnotenieUchadzacovLogika;
import sk.fiit.volby.page.volby.porotcovia.PorotcoviaPageLogika;
import sk.fiit.volby.page.volby.pouzivatelia.PouzivateliaPageLogika;
import sk.fiit.volby.page.volby.rocniky.RocnikyPageLogika;
import sk.fiit.volby.page.volby.sutaze.SutazePageLogika;
import sk.fiit.volby.page.volby.uchadzaci.UchadzaciPageLogika;
import sk.fiit.volby.page.volby.ziaci.ZiaciPageLogika;
import sk.fiit.volby.start.RunApp;
import sk.fiit.volby.start.hra.nastavenia.HraVolbyNastaveniaImpl;
import sk.fiit.volby.start.hra.nastavenia.HraVolbyNastaveniaNavrhovyVzorStrategy;
import sk.fiit.volby.start.hra.nastavenia.HraVolbyNastaveniaStrategiaVyberovyZoznam;

/**
 * hlavna obrazovka aplikacie, ktora sluzi na pristup k udajom z aplikacie
 * (napr. porotcovia, ziaci, uchadzaci, sutaze), k hodnteniu ziakmi a porotcami
 * a k vyhodnoteniu sutaze
 * 
 * @author nikola
 */
public class PracovnaPlochaPage extends JFrame {

	private static final long serialVersionUID = 6831999619995307607L;

	/**
	 * panel, ktory sluzi na zobrazenie prehladu skol
	 */
	private SkolyPageLogika skolyPageLogika;

	/**
	 * panel, ktory sluzi na zobrazenie prehladu porotcov
	 */
	private PorotcoviaPageLogika porotcoviaPageLogika;

	/**
	 * panel, ktory sluzi na zobrazenie prehladu ziakov
	 */
	private ZiaciPageLogika ziaciPageLogika;

	/**
	 * panel, ktory sluzi na zobrazenie prehladu uchadzacov
	 */
	private UchadzaciPageLogika uchadzaciPageLogika;

	/**
	 * panel, ktory sluzi na zobrazenie prehladu rocnikov
	 */
	private RocnikyPageLogika rocnikyPageLogika;

	/**
	 * panel, ktory sluzi na zobrazenie prehladu sutazi
	 */
	private SutazePageLogika sutazePageLogika;

	/**
	 * panel, ktory sluzi na zobrazenie prehladu pouzivatelov
	 */
	private PouzivateliaPageLogika pouzivateliaPageLogika;

	/**
	 * panel, ktory sluzi na zobrazenie prehladu hodnoteni uchadzacov
	 */
	private HodnotenieUchadzacovLogika hodnotenieUchadzacovLogika;

	/**
	 * panel, ktory sluzi na zobrazenie prehladu vyhodnotenia uchadzacov
	 */
	private VyhodnotenieUchadzacovLogika vyhodnotenieUchadzacovLogika;

	/**
	 * prazdny konstruktor pre vytvorenie obrazovky pracovnej plochy - cela dostupna
	 * funkcionalita suvisiaca s hrou
	 */
	public PracovnaPlochaPage() {

		inicializaciaObrazovky();

	}

	/**
	 * inicializacia obrazovky
	 */
	private void inicializaciaObrazovky() {

		// vytvorenie instancie hry
		HraVolbyNastaveniaImpl hraVolbyNastaveniaImpl = new HraVolbyNastaveniaImpl();

		// vytvorenie instancie obrazovky skoly
		skolyPageLogika = new SkolyPageLogika(hraVolbyNastaveniaImpl);

		// zaradenie objektu skola do zoznamu obrazoviek, ktore implementuju interface
		// InformovanieOzmeneUdajov
		hraVolbyNastaveniaImpl.zaradenieObrazovkyDoSLListZoznamu(skolyPageLogika);

		porotcoviaPageLogika = new PorotcoviaPageLogika(hraVolbyNastaveniaImpl);
		hraVolbyNastaveniaImpl.zaradenieObrazovkyDoSLListZoznamu(porotcoviaPageLogika);

		ziaciPageLogika = new ZiaciPageLogika(hraVolbyNastaveniaImpl);
		hraVolbyNastaveniaImpl.zaradenieObrazovkyDoSLListZoznamu(ziaciPageLogika);

		uchadzaciPageLogika = new UchadzaciPageLogika(hraVolbyNastaveniaImpl);
		hraVolbyNastaveniaImpl.zaradenieObrazovkyDoSLListZoznamu(uchadzaciPageLogika);

		rocnikyPageLogika = new RocnikyPageLogika(hraVolbyNastaveniaImpl);
		hraVolbyNastaveniaImpl.zaradenieObrazovkyDoSLListZoznamu(rocnikyPageLogika);

		sutazePageLogika = new SutazePageLogika(hraVolbyNastaveniaImpl) {

			private static final long serialVersionUID = 1L;

			@Override
			protected void refreshSutaze() {
				hraVolbyNastaveniaImpl.informInformovanieOzmeneUdajovList();
			}

			@Override
			protected void vynulovanieUdajovAkJeZoznamSutaziPrazdny(Sutaz sutaz) {
				List<Uchadzac> uchadzaci = new ArrayList<Uchadzac>();
				for (Uchadzac uchadzac : hraVolbyNastaveniaImpl.getUchadzaci()) {
					if (uchadzac.getSutaz().getId().equals(sutaz.getId()) == false) {
						uchadzaci.add(uchadzac);
					}
				}
				hraVolbyNastaveniaImpl.getUchadzaci().clear();
				hraVolbyNastaveniaImpl.getUchadzaci().addAll(uchadzaci);
			}

		};
		hraVolbyNastaveniaImpl.zaradenieObrazovkyDoSLListZoznamu(sutazePageLogika);

		pouzivateliaPageLogika = new PouzivateliaPageLogika(hraVolbyNastaveniaImpl);
		hraVolbyNastaveniaImpl.zaradenieObrazovkyDoSLListZoznamu(pouzivateliaPageLogika);

		setTitle(RunApp.getProperties().getProperty("pracovna.plocha.page.title"));
		setSize(600, 483);

		Image imgAdminLogo = new ImageIcon(this.getClass().getResource("/logo.png")).getImage();
		setIconImage(imgAdminLogo);

		getContentPane().setLayout(null);

		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(10, 10, 564, 361);
		getContentPane().add(tabbedPane);

		// zalozka administracie
		JPanel panelAdministracia = new JPanel();
		panelAdministracia.setBackground(new Color(255, 255, 255));
		tabbedPane.addTab("Administrácia", null, panelAdministracia, null);
		panelAdministracia.setLayout(null);

		// button sluziaci na zobrazenie obrazovky s prehladom skol
		JButton btnAdminSkoly = new JButton("");
		btnAdminSkoly.setToolTipText("Školy");
		btnAdminSkoly.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				// umiestnenie okna do stredu pc obrazovky
				skolyPageLogika.setLocationRelativeTo(null);
				// zobrazenie obrazovky
				skolyPageLogika.setVisible(true);

			}
		});
		Image imgAdminSkola = new ImageIcon(this.getClass().getResource("/admin-skola.png")).getImage();
		btnAdminSkoly.setIcon(new ImageIcon(imgAdminSkola));
		btnAdminSkoly.setBounds(10, 11, 120, 100);
		panelAdministracia.add(btnAdminSkoly);

		// button sluziaci na zobrazenie obrazovky s prehladom porotcov
		JButton btnAdminPorotcovia = new JButton("");
		btnAdminPorotcovia.setToolTipText("Porotcovia");
		btnAdminPorotcovia.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				porotcoviaPageLogika.setLocationRelativeTo(null);
				porotcoviaPageLogika.setVisible(true);

			}
		});

		Image imgAdminPorotcovia = new ImageIcon(this.getClass().getResource("/admin-porotcovia2.png")).getImage();
		btnAdminPorotcovia.setIcon(new ImageIcon(imgAdminPorotcovia));
		btnAdminPorotcovia.setBounds(140, 11, 120, 100);
		panelAdministracia.add(btnAdminPorotcovia);

		// button sluziaci na zobrazenie obrazovky s prehladom ziakov
		JButton btnAdminStudenti = new JButton("");
		btnAdminStudenti.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ziaciPageLogika.setLocationRelativeTo(null);
				ziaciPageLogika.setVisible(true);

			}
		});
		btnAdminStudenti.setToolTipText("Žiaci");
		Image imgAdminStudenti = new ImageIcon(this.getClass().getResource("/admin-student.png")).getImage();
		btnAdminStudenti.setIcon(new ImageIcon(imgAdminStudenti));
		btnAdminStudenti.setBounds(270, 11, 120, 100);
		panelAdministracia.add(btnAdminStudenti);

		// button sluziaci na zobrazenie obrazovky s prehladom rocnikov
		JButton btnAdminRocniky = new JButton("");
		btnAdminRocniky.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rocnikyPageLogika.setLocationRelativeTo(null);
				rocnikyPageLogika.setVisible(true);
			}
		});
		btnAdminRocniky.setToolTipText("Rocniky");
		Image imgAdminRocniky = new ImageIcon(this.getClass().getResource("/admin-rocniky.png")).getImage();
		btnAdminRocniky.setIcon(new ImageIcon(imgAdminRocniky));
		btnAdminRocniky.setBounds(10, 130, 120, 100);
		panelAdministracia.add(btnAdminRocniky);

		// button sluziaci na zobrazenie obrazovky s prehladom sutazi
		JButton btnAdminSutaze = new JButton("");
		btnAdminSutaze.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				sutazePageLogika.setLocationRelativeTo(null);
				sutazePageLogika.setVisible(true);
			}
		});
		btnAdminSutaze.setToolTipText("Súťaže (voľby)");
		Image imgAdminSutaze = new ImageIcon(this.getClass().getResource("/admin-sutaze.png")).getImage();
		btnAdminSutaze.setIcon(new ImageIcon(imgAdminSutaze));
		btnAdminSutaze.setBounds(140, 130, 120, 100);
		panelAdministracia.add(btnAdminSutaze);

		// button sluziaci na zobrazenie obrazovky s prehladom uchadzacov
		JButton btnAdminUchadzac = new JButton("");
		btnAdminUchadzac.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				uchadzaciPageLogika.setLocationRelativeTo(null);
				uchadzaciPageLogika.setVisible(true);
			}
		});
		btnAdminUchadzac.setToolTipText("Uchadzac");
		Image imgAdminUchadzac = new ImageIcon(this.getClass().getResource("/admin-uchadzac2.png")).getImage();
		btnAdminUchadzac.setIcon(new ImageIcon(imgAdminUchadzac));
		btnAdminUchadzac.setBounds(400, 11, 120, 100);
		panelAdministracia.add(btnAdminUchadzac);

		// button sluziaci na zobrazenie obrazovky s prehladom pouzivatelov
		JButton btnAdminPouzivatel = new JButton("");
		btnAdminPouzivatel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pouzivateliaPageLogika.setLocationRelativeTo(null);
				pouzivateliaPageLogika.setVisible(true);
			}
		});
		btnAdminPouzivatel.setToolTipText("Používateľ");
		Image imgAdminPouzivatel = new ImageIcon(this.getClass().getResource("/pouzivatelia.png")).getImage();
		btnAdminPouzivatel.setIcon(new ImageIcon(imgAdminPouzivatel));
		btnAdminPouzivatel.setBounds(270, 130, 120, 100);
		panelAdministracia.add(btnAdminPouzivatel);

		// zalozka pre hodnotenie
		JPanel panelHodnotenie = new JPanel();
		panelHodnotenie.setBackground(new Color(240, 240, 240));
		tabbedPane.addTab("Hodnotenie", null, panelHodnotenie, null);
		panelHodnotenie.setLayout(null);

		hodnotenieUchadzacovLogika = new HodnotenieUchadzacovLogika(hraVolbyNastaveniaImpl);
		hraVolbyNastaveniaImpl.zaradenieObrazovkyDoSLListZoznamu(hodnotenieUchadzacovLogika);

		hodnotenieUchadzacovLogika.setBackground(new Color(255, 255, 255));
		hodnotenieUchadzacovLogika.setBounds(10, 11, 539, 311);
		panelHodnotenie.add(hodnotenieUchadzacovLogika);

		// zalozka pre vyhodnotenie
		JPanel panelVyhodnotenie = new JPanel();
		panelVyhodnotenie.setBackground(new Color(240, 240, 240));
		tabbedPane.addTab("Vyhodnotenie", null, panelVyhodnotenie, null);
		panelVyhodnotenie.setLayout(null);

		vyhodnotenieUchadzacovLogika = new VyhodnotenieUchadzacovLogika(hraVolbyNastaveniaImpl);
		hraVolbyNastaveniaImpl.zaradenieObrazovkyDoSLListZoznamu(vyhodnotenieUchadzacovLogika);

		vyhodnotenieUchadzacovLogika.setBackground(new Color(255, 255, 255));
		vyhodnotenieUchadzacovLogika.setBounds(10, 11, 539, 311);
		panelVyhodnotenie.add(vyhodnotenieUchadzacovLogika);

		JLabel lblPrihlasenyPouzivatel = new JLabel("Používateľ:");
		lblPrihlasenyPouzivatel.setBounds(20, 381, 79, 13);
		getContentPane().add(lblPrihlasenyPouzivatel);

		// informacia o aktualne prihlasenom pouzivatelovi ziskana z prihlasovacieho
		// mena z Login Page
		JLabel lblMenoPrihlasenehoPouzivatela = new JLabel("");
		lblMenoPrihlasenehoPouzivatela.setText(PrihlasovaniePage.getAktualnePrihlasenyPouzivatel().getLogin());
		lblMenoPrihlasenehoPouzivatela.setBounds(90, 381, 176, 13);
		getContentPane().add(lblMenoPrihlasenehoPouzivatela);

		// button, ktory sluzi na odhlasenie pouzivatela
		JButton btnOdhlasit = new JButton("Odhlásiť");
		btnOdhlasit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				// pouzivatela nasettujeme na null, ked chcem, aby som sa znovu prihlasila
				PrihlasovaniePage.zrusitAktualnePrihlasenehoPouzivatelaPoOdhlaseni();

				// zavretie aktualne zobrazeneho okna
				dispose();
				// vytvorenie novej instancie obrazovky na prihlasenie
				PrihlasovaniePage frame = new PrihlasovaniePage();
				// vycentrovanie na stred pc obrazovky
				frame.setLocationRelativeTo(null);
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				// zobrazenie obrazovky
				frame.setVisible(true);

			}
		});
		btnOdhlasit.setBounds(495, 411, 85, 21);
		getContentPane().add(btnOdhlasit);

		// button na zavolanie funkcie pre vytvorenie inicializacnych dat pre hru
		JButton btnInicialiyaciaUdajov = new JButton("Inicializacia údajov");
		btnInicialiyaciaUdajov.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				// vytvorenie udajov s pouzitim strategie HraVolbyNastaveniaStrategiaPevnyZoznam
				// hraVolbyNastaveniaImpl.vytvorenieInicializacnychUdajov(new
				// HraVolbyNastaveniaStrategiaPevnyZoznam());
				hraVolbyNastaveniaImpl.vytvorenieInicializacnychUdajov(new HraVolbyNastaveniaStrategiaVyberovyZoznam());

				System.out.println("Udaje boli uspesne vytvorene pre zacatie hry.\n");

			}
		});
		btnInicialiyaciaUdajov.setBounds(6, 410, 127, 23);
		getContentPane().add(btnInicialiyaciaUdajov);

		// nacitanie udajov zo zaserializovaneho suboru
		JButton btnLoad = new JButton("Load");
		btnLoad.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				try {
					// nacitanie udajov zo zaserializovaneho suboru
					ObjectInputStream in = new ObjectInputStream(new FileInputStream("game-volby.out"));
					HraVolbyNastaveniaImpl nacitaneUdajeHryVolby = (HraVolbyNastaveniaImpl) in.readObject();
					in.close();
					// vytvorenie objektov nacitanych zo suboru
					hraVolbyNastaveniaImpl.vytvorenieInicializacnychUdajov(nacitaneUdajeHryVolby,
							new HraVolbyNastaveniaStrategiaVyberovyZoznam());
				} catch (FileNotFoundException e1) {
					System.out.println(
							"Pozadovany subor pre nacitanie parametrov hry 'game-volby.out' neexistuje. Prosim nainicializujte udaje a nasledne ich ulozte tlacidlo 'Save'");
				} catch (Exception e2) {
					e2.printStackTrace();
				}

			}
		});
		btnLoad.setBounds(335, 410, 74, 23);
		getContentPane().add(btnLoad);

		// button, ktory sluzi na ulozenie udajov do suboru
		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				try {
					// vytvorenie a zapisanie udajov do suboru game-volby.out, tento subor sa priamo
					// vytvori v adresari volby-swing-admin-app
					ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("game-volby.out"));
					out.writeObject(hraVolbyNastaveniaImpl);
					out.close();

				} catch (Exception e2) {
				}

			}
		});
		btnSave.setBounds(415, 410, 74, 23);
		getContentPane().add(btnSave);

		JButton btnInicialiyaciaUdajovStrategy = new JButton("Inicializácia údajov (Strategy)");
		btnInicialiyaciaUdajovStrategy.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				HraVolbyNastaveniaNavrhovyVzorStrategy hraVolbyNastaveniaNavrhovyVzorStrategy = new HraVolbyNastaveniaNavrhovyVzorStrategy(
						new HraVolbyNastaveniaStrategiaVyberovyZoznam());
				hraVolbyNastaveniaNavrhovyVzorStrategy
						.vytvorenieInicializacnychUdajovNavrhovyVzorStrategy(hraVolbyNastaveniaImpl);

			}
		});
		btnInicialiyaciaUdajovStrategy.setBounds(139, 410, 190, 23);
		getContentPane().add(btnInicialiyaciaUdajovStrategy);

		// potvrdzovacie okno po kliknuti na krizik na obrazovke dashboardu s
		// moznostami vyberu ano/nie
		addWindowListener(new java.awt.event.WindowAdapter() {
			@Override
			public void windowClosing(java.awt.event.WindowEvent windowEvent) {

				String title = RunApp.getProperties().getProperty("odhlasit.skutocne.si.zelate.odhlasit.sa.title");
				String msg = RunApp.getProperties().getProperty("odhlasit.skutocne.si.zelate.odhlasit.sa.sprava");

				if (JOptionPane.showConfirmDialog(PracovnaPlochaPage.this, msg, title, JOptionPane.YES_NO_OPTION,
						JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION) {

					PrihlasovaniePage.zrusitAktualnePrihlasenehoPouzivatelaPoOdhlaseni();

					PracovnaPlochaPage.this.dispose();

				}
			}
		});

	}
}
