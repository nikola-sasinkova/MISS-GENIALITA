package sk.fiit.volby.page.volby.sutaze;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.DefaultListCellRenderer;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import sk.fiit.volby.domain.volby.Rocnik;
import sk.fiit.volby.domain.volby.Sutaz;
import sk.fiit.volby.start.RunApp;
import sk.fiit.volby.start.hra.nastavenia.HraVolbyNastaveniaImpl;

/**
 * obrazovka na pridanie a aktualizaciu sutaze
 * 
 * @author nikola
 */
public class PridatSutazDialog extends JDialog {

	private static final long serialVersionUID = 2966582587600017198L;

	/**
	 * combobox s vyberom rocnika
	 */
	private JComboBox<Rocnik> comboBoxRocnikSutaze;

	/**
	 * policko na zadanie nazvu sutaze
	 */
	private JTextField textFieldNazovSutaze;

	/**
	 * policko na zadanie datumu ukoncenia sutaze
	 */
	private JTextField textFieldDatumUkoncenia;

	/**
	 * policko na zadanie datumu spustenia sutaze
	 */
	private JTextField textFieldDatumSpustenia;

	/**
	 * policko na zadanie datumu zverejnenia sutaze
	 */
	private JTextField textFieldDatumZverejnenia;

	/**
	 * policko na zadanie popisu
	 */
	private JTextArea textAreaPopis;

	/**
	 * popisok na zobrazenie chybovej hlasky - datum ukoncenia sutaze
	 */
	private JLabel lblDatumUkonceniaError;

	/**
	 * popisok na zobrazenie chybovej hlasky - datum spustenia sutaze
	 */
	private JLabel lblDatumSpusteniaError;

	/**
	 * popisok na zobrazenie chybovej hlasky - datum zverejnenia sutaze
	 */
	private JLabel lblDatumZverejneniaError;

	/**
	 * formatter, ktory sluzi na kontrolu stanoveneho formatu datumu
	 */
	private SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy");

	/**
	 * konstruktor pre vytvorenie obrazovky vytvorenia/aktualizacie sutaze
	 * 
	 * @param sutaz                  - vybrana sutaz z tabulky s prehladom sutazi
	 * @param hraVolbyNastaveniaImpl - instancia mojej hry
	 */
	public PridatSutazDialog(Sutaz sutaz, HraVolbyNastaveniaImpl hraVolbyNastaveniaImpl) {

		inicializaciaObrazovky(sutaz, hraVolbyNastaveniaImpl);

	}

	/**
	 * inicializacia obrazovky
	 * 
	 * @param sutaz                  - vybrana sutaz z tabulky s prehladom sutazi
	 * @param hraVolbyNastaveniaImpl - instancia mojej hry
	 */
	public void inicializaciaObrazovky(Sutaz sutaz, HraVolbyNastaveniaImpl hraVolbyNastaveniaImpl) {

		setAlwaysOnTop(true);
		setTitle(RunApp.getProperties().getProperty("pridat.aktualizovat.sutaz.dialog.title"));
		setType(Type.POPUP);
		setSize(430, 301);
		getContentPane().setLayout(null);

		Image imgAdminLogo = new ImageIcon(this.getClass().getResource("/logo.png")).getImage();
		setIconImage(imgAdminLogo);

		JLabel lblNazovSutaze = new JLabel("Názov súťaže");
		lblNazovSutaze.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblNazovSutaze.setBounds(21, 25, 98, 14);
		getContentPane().add(lblNazovSutaze);

		textFieldNazovSutaze = new JTextField();
		textFieldNazovSutaze.setBounds(146, 23, 256, 20);
		textFieldNazovSutaze.setText(sutaz.getNazov());
		getContentPane().add(textFieldNazovSutaze);

		// tlacitko na ulozenie/aktualizaciu porotcu
		JButton btnUlozit = new JButton("Uložiť");
		btnUlozit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (suUdajeFormularaValidne()) {

					try {
						// ziskanie prislusnej hodnoty z policka
						String nazov = textFieldNazovSutaze.getText();
						Rocnik rocnik = (Rocnik) comboBoxRocnikSutaze.getSelectedItem();
						String popis = textAreaPopis.getText();
						Date datumUkoncenia = formatter.parse(textFieldDatumUkoncenia.getText());
						Date datumSpustenia = formatter.parse(textFieldDatumSpustenia.getText());
						Date datumZverejnenia = formatter.parse(textFieldDatumZverejnenia.getText());

						if (sutaz.getId() == null) {
							// ak nema sutaz priradeny logicky identifikator, vytvorime objekt sutaze
							PridatSutazDialog.this.vytvoritSutaz(nazov, popis, rocnik, datumUkoncenia, datumSpustenia,
									datumZverejnenia);
						} else {
							// ak ma sutaz priradeny logicky identifikator, aktualizujeme hodnoty objektu
							// sutaze
							PridatSutazDialog.this.upravitSutaz(sutaz.getId(), nazov, popis, rocnik, datumUkoncenia,
									datumSpustenia, datumZverejnenia);
						}

						PridatSutazDialog.this.dispose();

					} catch (ParseException e1) {
						e1.printStackTrace();
					}

				}
			}
		});
		btnUlozit.setBounds(208, 232, 89, 23);
		getContentPane().add(btnUlozit);

		// tlacitko na zrusenie okna
		JButton btnZrusit = new JButton("Zrusit");
		btnZrusit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PridatSutazDialog.this.dispose();
			}
		});
		btnZrusit.setBounds(313, 232, 89, 23);
		getContentPane().add(btnZrusit);

		JLabel lblRocnikLabel = new JLabel("Rocnik sutaze");
		lblRocnikLabel.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblRocnikLabel.setBounds(21, 57, 89, 14);
		getContentPane().add(lblRocnikLabel);

		comboBoxRocnikSutaze = new JComboBox<Rocnik>();
		comboBoxRocnikSutaze.setBounds(146, 54, 256, 22);
		getContentPane().add(comboBoxRocnikSutaze);

		comboBoxRocnikSutaze.setRenderer(new DefaultListCellRenderer() {

			private static final long serialVersionUID = -29557693884269383L;

			@Override
			public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected,
					boolean cellHasFocus) {
				super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
				Rocnik rocnik = (Rocnik) value;
				if (rocnik != null) {
					setText(rocnik.getNazov());
				}
				return this;

			}
		});

		textAreaPopis = new JTextArea();
		textAreaPopis.setText(sutaz.getPopis());
		textAreaPopis.setBounds(146, 86, 256, 35);
		getContentPane().add(textAreaPopis);

		JLabel lblPopis = new JLabel("Popis");
		lblPopis.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblPopis.setBounds(21, 86, 49, 14);
		getContentPane().add(lblPopis);

		textFieldDatumUkoncenia = new JTextField();

		if (sutaz.getDatumUkonceniaPrihlasovania() != null) {
			String strDatumUkonceniaPrihlasovania = formatter.format(sutaz.getDatumUkonceniaPrihlasovania());
			textFieldDatumUkoncenia.setText(strDatumUkonceniaPrihlasovania);
		}
		textFieldDatumUkoncenia.setToolTipText("Zadať vo formáte DD.MM.YYYY");
		textFieldDatumUkoncenia.setBounds(146, 129, 96, 20);
		getContentPane().add(textFieldDatumUkoncenia);
		textFieldDatumUkoncenia.setColumns(10);

		textFieldDatumSpustenia = new JTextField();

		if (sutaz.getDatumSpusteniaHlasovania() != null) {
			String strDatumSpusteniaHlasovania = formatter.format(sutaz.getDatumSpusteniaHlasovania());
			textFieldDatumSpustenia.setText(strDatumSpusteniaHlasovania);
		}
		textFieldDatumSpustenia.setToolTipText("Zadať vo formáte DD.MM.YYYY");
		textFieldDatumSpustenia.setBounds(146, 160, 96, 20);
		getContentPane().add(textFieldDatumSpustenia);
		textFieldDatumSpustenia.setColumns(10);

		textFieldDatumZverejnenia = new JTextField();

		if (sutaz.getDatumSpusteniaHlasovania() != null) {
			String strDatumZverejnenia = formatter.format(sutaz.getDatumZverejnenia());
			textFieldDatumZverejnenia.setText(strDatumZverejnenia);
		}
		textFieldDatumZverejnenia.setToolTipText("Zadať vo formáte DD.MM.YYYY");
		textFieldDatumZverejnenia.setBounds(146, 191, 96, 20);
		getContentPane().add(textFieldDatumZverejnenia);
		textFieldDatumZverejnenia.setColumns(10);

		JLabel lblDatumUkoncenia = new JLabel("Datum ukoncenia");
		lblDatumUkoncenia.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblDatumUkoncenia.setBounds(21, 132, 98, 14);
		getContentPane().add(lblDatumUkoncenia);

		JLabel lblDatumSpustenia = new JLabel("Datum spustenia");
		lblDatumSpustenia.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblDatumSpustenia.setBounds(21, 163, 98, 14);
		getContentPane().add(lblDatumSpustenia);

		JLabel lblDatumZverejnenia = new JLabel("Datum zverejnenia");
		lblDatumZverejnenia.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblDatumZverejnenia.setBounds(21, 194, 96, 14);
		getContentPane().add(lblDatumZverejnenia);

		lblDatumUkonceniaError = new JLabel("Povolený formát: dd.MM.yyyy");
		lblDatumUkonceniaError.setFont(new Font("Tahoma", Font.PLAIN, 9));
		lblDatumUkonceniaError.setVisible(false);
		lblDatumUkonceniaError.setForeground(new Color(255, 0, 0));
		lblDatumUkonceniaError.setBounds(259, 132, 157, 14);
		getContentPane().add(lblDatumUkonceniaError);

		lblDatumSpusteniaError = new JLabel("Povolený formát: dd.MM.yyyy"); // Nová chybová správa pre dátum spustenia
		lblDatumSpusteniaError.setFont(new Font("Tahoma", Font.PLAIN, 9));
		lblDatumSpusteniaError.setVisible(false);
		lblDatumSpusteniaError.setForeground(new Color(255, 0, 0));
		lblDatumSpusteniaError.setBounds(259, 163, 142, 14);
		getContentPane().add(lblDatumSpusteniaError);

		lblDatumZverejneniaError = new JLabel("Povolený formát: dd.MM.yyyy"); // Nová chybová správa pre dátum
																				// zverejnenia
		lblDatumZverejneniaError.setFont(new Font("Tahoma", Font.PLAIN, 9));
		lblDatumZverejneniaError.setVisible(false);
		lblDatumZverejneniaError.setForeground(new Color(255, 0, 0));
		lblDatumZverejneniaError.setBounds(259, 194, 157, 14);
		getContentPane().add(lblDatumZverejneniaError);

		if (hraVolbyNastaveniaImpl.getRocniky() != null) {
			for (Rocnik rocnik : hraVolbyNastaveniaImpl.getRocniky()) {
				comboBoxRocnikSutaze.addItem(rocnik);
				if (sutaz.getRocnik() != null && rocnik.getId().equals(sutaz.getRocnik().getId())) {
					comboBoxRocnikSutaze.setSelectedItem(rocnik);
				}
			}
		}

	}

	/**
	 * metoda skontroluje spravnost vyplnenych udajov na formulari pridat \
	 * aktualizovat sutaz
	 * 
	 * @return boolean
	 */
	private boolean suUdajeFormularaValidne() {

		boolean valid = true;

		lblDatumUkonceniaError.setVisible(false);
		lblDatumSpusteniaError.setVisible(false);
		lblDatumZverejneniaError.setVisible(false);

		try {
			formatter.parse(textFieldDatumUkoncenia.getText());
		} catch (ParseException e) {
			// e.printStackTrace();
			lblDatumUkonceniaError.setVisible(true);
			valid = false;
		}

		try {
			formatter.parse(textFieldDatumSpustenia.getText()); // osetrenie datumu spustenia
		} catch (ParseException e) {
			lblDatumSpusteniaError.setVisible(true);
			valid = false;
		}

		try {
			formatter.parse(textFieldDatumZverejnenia.getText()); // osetrenie datumu zverejnenia
		} catch (ParseException e) {
			lblDatumZverejneniaError.setVisible(true);
			valid = false;
		}

		return valid;

	}

	/**
	 * abstraktna metoda, ktora je volana na kliknutie tlacitka ulozit ak nie je
	 * vyplnene id sutaze - vznika novy zaznam sutaze v zozname sutazi,
	 * implementacia tejto metody sa nachadza pri vytvoreni instancie tejto
	 * obrazovky
	 * 
	 * @param nazov                       - nazov sutaze
	 * @param rocnik                      - rocnik, pre ktory bude sutaz vytvorena
	 * @param popis                       - popis sutaze
	 * @param datumUkonceniaPrihlasovania - datum ukoncenia prihlasovania sutaze
	 * @param datumSpusteniaHlasovania    - datum spustenia hlasovania sutaze
	 * @param datumZverejnenia            - datum zverejnenia sutaze
	 */
	protected void vytvoritSutaz(String nazov, String popis, Rocnik rocnik, Date datumUkoncenieHlasovania,
			Date datumSpristupnenieHlasovania, Date datumZverejnenia) {
		return;
	};

	/**
	 * abstraktna metoda, ktora je volana na kliknutie tlacitka ulozit ak je
	 * vyplnene id sutaze - aktualizuje sa zaznam sutaze v zozname sutazi,
	 * implementacia tejto metody sa nachadza pri vytvoreni instancie tejto
	 * obrazovky
	 * 
	 * @param sutazId                     - identifikator sutaze
	 * @param nazov                       - nazov sutaze
	 * @param rocnik                      - rocnik, pre ktory bude sutaz vytvorena
	 * @param popis                       - popis sutaze
	 * @param datumUkonceniaPrihlasovania - datum ukoncenia prihlasovania sutaze
	 * @param datumSpusteniaHlasovania    - datum spustenia hlasovania sutaze
	 * @param datumZverejnenia            - datum zverejnenia sutaze
	 */
	protected void upravitSutaz(Integer sutazId, String nazov, String popis, Rocnik rocnik,
			Date datumUkoncenieHlasovania, Date datumSpristupnenieHlasovania, Date datumZverejnenia) {
		return;
	};
}
