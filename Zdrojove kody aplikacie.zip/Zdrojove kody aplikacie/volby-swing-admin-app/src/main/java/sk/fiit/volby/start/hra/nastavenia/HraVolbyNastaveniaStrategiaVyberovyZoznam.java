package sk.fiit.volby.start.hra.nastavenia;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Random;

import sk.fiit.volby.domain.common.Adresa;
import sk.fiit.volby.domain.common.Kontakt;
import sk.fiit.volby.domain.common.Pohlavie;
import sk.fiit.volby.domain.pouzivatel.Pouzivatel;
import sk.fiit.volby.domain.skola.Skola;
import sk.fiit.volby.domain.skola.TypSkoly;
import sk.fiit.volby.domain.volby.Rocnik;
import sk.fiit.volby.domain.volby.Sutaz;
import sk.fiit.volby.domain.volby.ucastnici.volby.Porotca;
import sk.fiit.volby.domain.volby.ucastnici.volby.RolaPorotcu;
import sk.fiit.volby.domain.volby.ucastnici.volby.StupenVzdelaniaZiaka;
import sk.fiit.volby.domain.volby.ucastnici.volby.Uchadzac;
import sk.fiit.volby.domain.volby.ucastnici.volby.UchadzacBakalarskehoStudia;
import sk.fiit.volby.domain.volby.ucastnici.volby.UchadzacInzinierskehoStudia;
import sk.fiit.volby.domain.volby.ucastnici.volby.VyskumnaPraca;
import sk.fiit.volby.domain.volby.ucastnici.volby.Ziak;
import sk.fiit.volby.domain.vyhodnotenie.PriebezneHodnotenieUchadzaca;

/**
 * trieda, ktora predstavuje strategiu hry k inicializacnemu naplneniu udajov
 * 
 * @author nikola
 */
public class HraVolbyNastaveniaStrategiaVyberovyZoznam implements HraVolbyNastavenia {

	/**
	 * staticka premenna definujuca stat
	 */
	private static final String STAT = "Slovenska republika";

	/**
	 * staticka premenna definujuca rok od ktoreho sa budu sutaze realizovat
	 */
	private static final int ROCNIK_ROK = 2023;

	/**
	 * inicializacny pocet skol
	 */
	private int pocetSkol = 1;

	/**
	 * inicializacny pocet porotcov
	 */
	private int pocetPorotcov = 10;

	/**
	 * inicializacny pocet ziakov
	 */
	private int pocetZiakov = 10;

	/**
	 * inicializacny pocet uchadzacov
	 */
	private int pocetUchadzacov = 6;

	/**
	 * inicializacny pocet rocnikov
	 */
	private int pocetRocnikov = 1;

	/**
	 * inicializacny pocet sutazi
	 */
	private int pocetSutazi = 1;
//	private int pocetPouzivatelov = 1;

	/**
	 * metoda, ktora zabezpecuje inicializacnych udajov do hry
	 */
	@Override
	public void nastavenie(List<Skola> skoly, List<Porotca> porotcovia, List<Ziak> ziaci, List<Uchadzac> uchadzaci,
			List<Rocnik> rocniky, List<Sutaz> sutaze, List<Pouzivatel> pouzivatelia) {

		Pouzivatel pouzivatelAdmin = new Pouzivatel(1, "nsasinkova-admin", "asdpds");
		pouzivatelia.add(pouzivatelAdmin);

		for (int i = 0; i < pocetSkol; ++i) {

			String nazov = getRandomNazovSkoly();

			String ulica = getRandomUlica();
			String cisloDomu = generateRandomNumbers(2) + "/" + generateRandomNumbers(2);
			String psc = generateRandomNumbers(3) + " " + generateRandomNumbers(2);
			String obec = getRandomMesto();

			String phone = "+421" + generateRandomNumbers(8);
			String email = generateRandomNumbers(10) + "@" + generateRandomNumbers(5) + ".sk";
			String web = "www.fiit.sk";

			Skola skola = new Skola(i + 1, TypSkoly.VYSOKA_SKOLA, nazov, new Adresa(ulica, cisloDomu, psc, obec, STAT),
					new Kontakt(phone, email, web));

//			Skola.GpsKoordinatori gpsKoordinatori = new Skola.GpsKoordinatori(psc, psc);
			skoly.add(skola);
		}

		for (Skola skola : skoly) {

			Porotca porotca = new Porotca(skola, 1, getRandomTitulPredMenom(), getRandomMeno(), "",
					getRandomPriezvisko(), getRandomTitulZaMenom(), Pohlavie.MUZ, RolaPorotcu.PREDSEDA);

			porotcovia.add(porotca);

			Pouzivatel pouzivatelPorotca = new Pouzivatel(1, "nsasinkova-porotca", "asdpds1");
			pouzivatelPorotca.setOsoba(porotca);
			pouzivatelia.add(pouzivatelPorotca);

			for (int i = 1; i <= pocetPorotcov; ++i) {

				String titulPredMenom = i % 2 == 0 ? getRandomTitulPredMenom() : "";
				String meno = getRandomMeno();
				String stredneMeno = i % 3 == 0 ? getRandomMeno() : "";
				String priezvisko = getRandomPriezvisko();
				String titulZaMenom = i % 4 == 0 ? getRandomTitulZaMenom() : "";

				porotcovia.add(new Porotca(skola, i + 1, titulPredMenom, meno, stredneMeno, priezvisko, titulZaMenom,
						Pohlavie.MUZ, RolaPorotcu.CLEN));

			}

		}

		for (Skola skola : skoly) {

			for (int i = 0; i < pocetZiakov; ++i) {

				String meno = getRandomMeno();
				String stredneMeno = i % 3 == 0 ? getRandomMeno() : "";
				String priezvisko = getRandomPriezvisko();
				String identifikatorZiaka = generateRandomNumbers(10);
				StupenVzdelaniaZiaka stupenVzdelaniaZiaka = i % 2 == 0 ? StupenVzdelaniaZiaka.BAKALARSKE_STUDIUM
						: StupenVzdelaniaZiaka.INZINIERSKE_STUDIUM;

				Ziak ziak = new Ziak(skola, i + 1, meno, stredneMeno, priezvisko, "", "", Pohlavie.MUZ,
						identifikatorZiaka, stupenVzdelaniaZiaka);

				ziaci.add(ziak);

//				if (i == 0) {
//					Pouzivatel pouzivatelZiak = new Pouzivatel(1, "nsasinkova-ziak", "asdpds2");
//					ziak.setPouzivatel(pouzivatelZiak);
//					pouzivatelia.add(pouzivatelZiak);
//				}

			}

		}

		int rok = ROCNIK_ROK;

		VyskumnaPraca vyskumnaPraca1 = new VyskumnaPraca("Lorem ipsum dolor sit amet, consectetur adipiscing elit",
				"Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum");
		VyskumnaPraca vyskumnaPraca2 = new VyskumnaPraca("Ut enim ad minim veniam, quis nostrud",
				"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.");
		VyskumnaPraca vyskumnaPraca3 = new VyskumnaPraca("Duis aute irure dolor in reprehenderit in voluptate",
				"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. ");

		for (Skola skola : skoly) {
			for (int i = 0; i < pocetRocnikov; ++i) {
				String nazov = rok + " / " + ++rok;
				Rocnik rocnik = new Rocnik(skola, i + 1, nazov, new Date(), new Date());
				rocniky.add(rocnik);

				for (int j = 0; j < pocetSutazi; ++j) {

					String nazovSutaze = getRandomNazovSutaze();
					String popisSutaze = generateRandomChars(250);
					Date datumUkonceniaPrihlasovania = j % 2 == 0 ? new Date() : null;
					Date datumSpusteniaHlasovania = j % 2 == 0 ? new Date() : null;
					Date datumZverejnenia = j % 2 == 0 ? new Date() : null;

					Sutaz sutaz = new Sutaz(j + 1, skola, rocnik, nazovSutaze, popisSutaze, datumUkonceniaPrihlasovania,
							datumSpusteniaHlasovania, datumZverejnenia);
					sutaze.add(sutaz);

					for (int k = 0; k < pocetUchadzacov; ++k) {

						if (k < ziaci.size()) {

							Ziak ziak = ziaci.get(k);

							if (StupenVzdelaniaZiaka.BAKALARSKE_STUDIUM.equals(ziak.getStupenVzdelaniaZiaka())) {

								Uchadzac uchadzac = new UchadzacBakalarskehoStudia(ziak.getSkola(), k + 1,
										ziak.getMeno(), ziak.getStredneMeno(), ziak.getPriezvisko(),
										ziak.getTitulPredMenom(), ziak.getTitulZaMenom(), ziak.getPohlavie(),
										ziak.getIdentifikatorZiaka(), false, sutaz,
										StupenVzdelaniaZiaka.BAKALARSKE_STUDIUM);
								if (k == 1) {
									uchadzac.setVyskumnaPraca(vyskumnaPraca1);
								} else if (k == 2) {
									uchadzac.setVyskumnaPraca(vyskumnaPraca2);
								} else if (k == 3) {
									uchadzac.setVyskumnaPraca(vyskumnaPraca3);
								}
								uchadzaci.add(uchadzac);

							} else {

								Uchadzac uchadzac = new UchadzacInzinierskehoStudia(ziak.getSkola(), k + 1,
										ziak.getMeno(), ziak.getStredneMeno(), ziak.getPriezvisko(),
										ziak.getTitulPredMenom(), ziak.getTitulZaMenom(), ziak.getPohlavie(),
										ziak.getIdentifikatorZiaka(), false, sutaz,
										StupenVzdelaniaZiaka.INZINIERSKE_STUDIUM);
								if (k == 1) {
									uchadzac.setVyskumnaPraca(vyskumnaPraca1);
								} else if (k == 2) {
									uchadzac.setVyskumnaPraca(vyskumnaPraca2);
								} else if (k == 3) {
									uchadzac.setVyskumnaPraca(vyskumnaPraca3);
								}
								uchadzaci.add(uchadzac);

							}

//							if (k == 0) {
//								Pouzivatel pouzivatelUchadzac = new Pouzivatel(1, "nsasinkova-uchadzac", "asdpds3",
//										uchadzac);
//								uchadzac.setPouzivatel(pouzivatelUchadzac);
//								pouzivatelia.add(pouzivatelUchadzac);
//							}

						}

					}

				}

			}
		}

		// ziskanie nahodneho poctu porotcov, ktorym sa nainicializuje priebezne
		// hodnotenie
		// pre konkretneho uchadzaca
		int randomPorotcaOrderNumber = getRandomNumber(1, porotcovia.size());

		// ziskanie nahodneho poctu ziakov, ktorym sa nainicializuje priebezne
		// hodnotenie
		// pre konkretneho uchadzaca
		int randomZiakOrderNumber = getRandomNumber(1, ziaci.size());

		for (Uchadzac uchadzac : uchadzaci) {

			// vyberame len tych uchadzacov, ktori odovzdali vyskumnu pracu
			if (uchadzac.getVyskumnaPraca() != null) {

				// prechadzame random vygenerovany pocet porotcov a pre kazdeho z nich nastavime
				// priebezny pocet bodov uchadzacovi, pocet bodov nahodne generujeme v rozsahu
				// od 10 do 100
				for (int j = 0; j < randomPorotcaOrderNumber; j++) {
					Porotca porotca = porotcovia.get(j);
					int randomNumber = getRandomNumber(10, 100);
					PriebezneHodnotenieUchadzaca hodnoteniePorotcu = new PriebezneHodnotenieUchadzaca(porotca, uchadzac,
							randomNumber);
					// zabezpecujeme aktualizaciu priebezneho hodnotenia od porotcu
					uchadzac.aktualizovatPriebezneHodnotenieUchadzacaPorotcu(hodnoteniePorotcu);
				}

				// prechadzame random vygenerovany pocet ziakov a pre kazdeho z nich nastavime
				// priebezny pocet bodov uchadzacovi, pocet bodov nahodne generujeme v rozsahu
				// od 1 do 10
				for (int j = 0; j < randomZiakOrderNumber; j++) {
					Ziak ziak = ziaci.get(j);
					int randomNumber = getRandomNumber(1, 10);
					PriebezneHodnotenieUchadzaca hodnotenieZiaka = new PriebezneHodnotenieUchadzaca(ziak, uchadzac,
							randomNumber);
					// zabezpecujeme aktualizaciu priebezneho hodnotenia od ziaka
					uchadzac.aktualizovatPriebezneHodnotenieUchadzacaZiaka(hodnotenieZiaka);
				}
				// vypocet celkoveho hodnotenia na zaklade priebeznych hodnoteni
				uchadzac.vypocetBodovehoHodnotenia();

			}

		}

	}

	/**
	 * metoda, ktora vrati text s nahodnymi cislami v dlzke definovanej vstupnym
	 * parametrom
	 * 
	 * @param length - pocet znakov v generovanom cisle
	 * @return generovaneCislo
	 */
	private String generateRandomNumbers(int length) {
		String numbers = "123456789";

		StringBuilder sb = new StringBuilder();
		Random random = new Random();
		for (int i = 0; i < length; i++) {
			sb.append(numbers.charAt(random.nextInt(numbers.length())));
		}

		return sb.toString();
	}

	/**
	 * metoda, ktora vrati text s nahodnymi znakmi v dlzke definovanej vstupnym
	 * parametrom
	 * 
	 * @param length - pocet znakov v generovanom texte
	 * @return generovanyText
	 */
	private String generateRandomChars(int length) {
		String bigLetter = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		String smallLetter = "abcdefghijklmnopqrstuvwxyz";

		StringBuilder sb = new StringBuilder();
		Random random = new Random();
		for (int i = 0; i < 1; i++) {
			sb.append(bigLetter.charAt(random.nextInt(bigLetter.length())));
		}
		for (int i = 0; i < length; i++) {
			sb.append(smallLetter.charAt(random.nextInt(smallLetter.length())));
		}

		return sb.toString();
	}

	/**
	 * metoda, ktora vrati niektoru skolu zo zoznamu ponukanych skol
	 * 
	 * @return skola
	 */
	private String getRandomNazovSkoly() {
		List<String> skoly = Arrays.asList("Univerzita Komenského v Bratislave",
				"Univerzita Pavla Jozefa safarika v Kosiciach",
				"Univerzita veterinarskeho lekarstva a farmacie v Kosiciach",
				"Univerzita Mateja Bela v Banskej Bystrici", "zilinska univerzita v ziline",
				"Slovenska technicka univerzita v Bratislave", "Ekonomicka univerzita v Bratislave");
		Random rand = new Random();
		return skoly.get(rand.nextInt(skoly.size()));
	}

	/**
	 * metoda, ktora vrati niektory titul zo zoznamu ponukanych titulov pred menom
	 * 
	 * @return titulPredMenom
	 */
	private String getRandomTitulPredMenom() {
		List<String> titulPredMenom = Arrays.asList("Ing.", "JUDr.", "MUDr.", "RNDr.", "PhMr.", "arch.", "Mgr.");
		Random rand = new Random();
		return titulPredMenom.get(rand.nextInt(titulPredMenom.size()));
	}

	/**
	 * metoda, ktora vrati niektore meno zo zoznamu ponukanych mien
	 * 
	 * @return meno
	 */
	private String getRandomMeno() {
		List<String> mena = Arrays.asList("Zuzana", "Peter", "Lubos", "Alena", "Frederik", "Ctibor", "Hubert",
				"Drahoslav", "Igor", "Bohdan", "Ivana", "Ela", "Ema", "Edita", "Bohumil", "Adolf", "Dominik", "Denis",
				"Emil", "Izidor");
		Random rand = new Random();
		return mena.get(rand.nextInt(mena.size()));
	}

	/**
	 * metoda, ktora vrati niektore priezvisko zo zoznamu ponukanych priezvisk
	 * 
	 * @return priezvisko
	 */
	private String getRandomPriezvisko() {
		List<String> mena = Arrays.asList("Anderle", "Babjak", "Bilko", "Ciger", "Dancak", "Hilmer", "Klepsatel",
				"Lukachich", "Neruda", "Olah", "Pepucha", "Palkovic", "Rozenberg", "Selecky", "Svrbik", "Tahy",
				"Zelenay", "Zubka", "Zipser", "Zorkoci");
		Random rand = new Random();
		return mena.get(rand.nextInt(mena.size()));
	}

	/**
	 * metoda, ktora vrati niektory titul zo zoznamu ponukanych titulov za menom
	 * 
	 * @return titulZaMenom
	 */
	private String getRandomTitulZaMenom() {
		List<String> titulyZaMenom = Arrays.asList("CSc.", "PhD.", "ArtD.", "DiS", "PhMr.", "DrSc.", "DiS.art");
		Random rand = new Random();
		return titulyZaMenom.get(rand.nextInt(titulyZaMenom.size()));
	}

	/**
	 * metoda, ktora vrati niektoru ulicu zo zoznamu ponukanych ulic
	 * 
	 * @return ulicu
	 */
	private String getRandomUlica() {
		List<String> ulice = Arrays.asList("Adamiho ulica", "Banicova ulica", "Bazova ulica", "Beskydska ulica",
				"Deviata ulica", "Domkarska ulica", "Fedinova ulica", "Havelkova ulica", "Keltska ulica",
				"Kolarska ulica", "Korenicova ulica", "Majova ulica", "Mladeznicka ulica", "Most Apollo", "Na skale",
				"Nabrezna ulica", "Nova Bellova ulica", "Novosvetska ulica", "Obilna ulica", "Ostredkova ulica");
		Random rand = new Random();
		return ulice.get(rand.nextInt(ulice.size()));
	}

	/**
	 * metoda, ktora vrati niektore mesto zo zoznamu ponukanych miest
	 * 
	 * @return mesto
	 */
	private String getRandomMesto() {
		List<String> mena = Arrays.asList("Bratislava", "zilina", "Presov", "Kosice", "Banska Bystrica", "Prievidza",
				"Poprad", "Martin", "Michalovce", "Liptovsky Mikulas", "Topolcany", "Dunajska Streda",
				"Dubnica nad Vahom", "Hlohovec", "Malacky", "Snina", "ziar nad Hronom", "Skalica", "Detva",
				"Zlaté Moravce");
		Random rand = new Random();
		return mena.get(rand.nextInt(mena.size()));
	}

	/**
	 * metoda, ktora vrati niektoru sutaz zo zoznamu ponukanych sutazi
	 * 
	 * @return nazovSutaze
	 */
	private String getRandomNazovSutaze() {
		List<String> sutaze = Arrays.asList("Hlada sa Miss Genius", "Hlada sa Miss University",
				"Hlada sa najinteligentnejsi student");
		Random rand = new Random();
		return sutaze.get(rand.nextInt(sutaze.size()));
	}

	/**
	 * metoda, ktora sluzi na vygenerovanie cisla v rozsahu vstupnych hodnot min,
	 * max
	 * 
	 * @param min - minimalne cislo
	 * @param max - maximalne cislo
	 * @return cislo
	 */
	public int getRandomNumber(int min, int max) {
		return (int) ((Math.random() * (max - min)) + min);
	}
}
