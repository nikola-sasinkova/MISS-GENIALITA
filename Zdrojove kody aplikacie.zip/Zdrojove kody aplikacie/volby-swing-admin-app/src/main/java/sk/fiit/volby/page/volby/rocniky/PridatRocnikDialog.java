package sk.fiit.volby.page.volby.rocniky;

import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;

import sk.fiit.volby.domain.volby.Rocnik;
import sk.fiit.volby.start.RunApp;

/**
 * obrazovka na pridanie a aktualizaciu rocnika
 * 
 * @author nikola
 */
public class PridatRocnikDialog extends JDialog {

	private static final long serialVersionUID = -5931309089862762142L;

	/**
	 * policko na zadanie nazvu rocnika
	 */
	private JTextField textFieldNazovRocnika;

	/**
	 * konstruktor pre vytvorenie obrazovky vytvorenia/aktualizacie rocnika
	 * 
	 * @param rocnik - vybrany rocnik z tabulky s prehladom rocnikov
	 */
	public PridatRocnikDialog(Rocnik rocnik) {

		inicializaciaObrazovky(rocnik);

	}

	/**
	 * inicializacia obrazovky
	 * 
	 * @param rocnik - vybrany rocnik z tabulky s prehladom rocnikov
	 */
	public void inicializaciaObrazovky(Rocnik rocnik) {

		setAlwaysOnTop(true);
		setTitle(RunApp.getProperties().getProperty("pridat.aktualizovat.rocnik.dialog.title"));
		setType(Type.POPUP);
		setSize(470, 168);
		getContentPane().setLayout(null);

		Image imgAdminLogo = new ImageIcon(this.getClass().getResource("/logo.png")).getImage();
		setIconImage(imgAdminLogo);

		JLabel lblNazovRocnika = new JLabel("Nazov rocnika");
		lblNazovRocnika.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNazovRocnika.setBounds(21, 29, 98, 14);
		getContentPane().add(lblNazovRocnika);

		textFieldNazovRocnika = new JTextField();
		textFieldNazovRocnika.setBounds(146, 27, 256, 20);
		textFieldNazovRocnika.setText(rocnik.getNazov());
		getContentPane().add(textFieldNazovRocnika);

		// tlacitko na ulozenie, aktualizaciu udajov o rocniku
		JButton btnUlozit = new JButton("Uložiť");
		btnUlozit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (suUdajeFormularaValidne()) {
					// ziskanie prislusnej hodnoty z policka
					String nazov = textFieldNazovRocnika.getText();

					if (rocnik.getId() == null) {
						// ak nema rocnik priradeny logicky identifikator, vytvorime objekt rocnika
						PridatRocnikDialog.this.vytvoritRocnik(nazov);
					} else {
						// ak ma rocnik priradeny logicky identifikator, aktualizujeme hodnoty objektu
						// rocnika
						PridatRocnikDialog.this.upravitRocnik(rocnik.getId(), nazov);
					}

					PridatRocnikDialog.this.dispose();
				}
			}
		});
		btnUlozit.setBounds(214, 68, 89, 23);
		getContentPane().add(btnUlozit);

		// tlaciko na zavretie okna
		JButton btnZrusit = new JButton("Zrusit");
		btnZrusit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PridatRocnikDialog.this.dispose();
			}
		});
		btnZrusit.setBounds(313, 68, 89, 23);
		getContentPane().add(btnZrusit);

	}

	/**
	 * metoda, ktora sluzi na validaciu udajov zadanych v polickach (nazov rocnika
	 * bude povinny)
	 * 
	 * @return valid
	 */
	private boolean suUdajeFormularaValidne() {

		boolean valid = true;
		return valid;

	}

	/**
	 * abstraktna metoda, ktora je volana na kliknutie tlacitka ulozit ak je
	 * vyplnene id rocnika - aktualizuje sa zaznam rocnika v zozname rocnikov,
	 * implementacia tejto metody sa nachadza pri vytvoreni instancie tejto
	 * obrazovky
	 * 
	 * @param nazov - nazov rocnika
	 */
	protected void vytvoritRocnik(String nazov) {
		return;
	};

	/**
	 * abstraktna metoda, ktora je volana na kliknutie tlacitka ulozit ak je
	 * vyplnene id rocnika - aktualizuje sa zaznam rocnika v zozname rocnikov,
	 * implementacia tejto metody sa nachadza pri vytvoreni instancie tejto
	 * obrazovky
	 * 
	 * @param rocnikId - identifikator rocnika
	 * @param nazov - nazov rocnika
	 */
	protected void upravitRocnik(int rocnikId, String nazov) {
		return;
	};

}
