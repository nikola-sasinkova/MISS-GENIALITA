package sk.fiit.volby.start;

import java.awt.EventQueue;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.swing.JFrame;

import sk.fiit.volby.page.prihlasovanie.PrihlasovaniePage;

/**
 * zakladna trieda na spustenie aplikacie, spusta sa cez: run as - java
 * application
 * 
 * @author nikola
 */
public class RunApp {

	/**
	 * nazov suboru v ktorom sa nachadzaju UTF-8 nazvy popiskov k polickam a hlasky
	 */
	private static final String propertiesFileName = "volby-admin-ui.properties";

	/**
	 * zoznam key - value vsetkych hodnot z property suboru
	 */
	private static Properties prop;

	/**
	 * zakladna menota na spustenie aplikacie
	 * 
	 * @param args - vstupne argumenty aplikacie
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {

				try {

					// nacitanie property suboru z resources aplikacie
					ClassLoader classLoader = getClass().getClassLoader();
					InputStream is = classLoader.getResourceAsStream(propertiesFileName);

					// nacitanie hodnot z property suboru
					readPropertiesFile(is);

					// vytvorenie instancie obrazovky na prihlasovanie pouzivatela
					PrihlasovaniePage frame = new PrihlasovaniePage();
					frame.setLocationRelativeTo(null);
					frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					frame.setVisible(true);

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * staticka metoda, ktora vracia Key value hodnoty z pozadovaneho suboru
	 * 
	 * @return prop
	 */
	public static Properties getProperties() {
		return prop;
	}

	/**
	 * nacitanie hodnot z property suboru
	 * 
	 * @param is - input stream
	 * @return prop
	 * @throws IOException - chyba nacitavanie properties suboru
	 */
	private static Properties readPropertiesFile(InputStream is) throws IOException {

		try {
			prop = new Properties();
			prop.load(is);
		} catch (FileNotFoundException fnfe) {
			fnfe.printStackTrace();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} finally {
			is.close();
		}
		return prop;
	}
}
