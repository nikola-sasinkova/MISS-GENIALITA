package sk.fiit.volby.page.skoly;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.MatteBorder;

import sk.fiit.volby.domain.skola.Skola;
import sk.fiit.volby.start.hra.InformovanieOzmeneUdajovSkoly;

/**
 * panel, ktory sluzi na zobrazenie informacii z kontaktu (primarne sa pouziva
 * na obrazovke skol)
 * 
 * @author nikola
 */
public class SkolaKontaktPanel extends JPanel implements InformovanieOzmeneUdajovSkoly {

	private static final long serialVersionUID = -4891251932915825489L;

	/**
	 * text sluziaci na vypis telefonu z kontaktu
	 */
	private JLabel lblKontaktTelefonValue;

	/**
	 * text sluziaci na vypis emailu z kontaktu
	 */
	private JLabel lblKontaktEmailValue;

	/**
	 * text sluziaci na vypis internetovej stranky z kontaktu
	 */
	private JLabel lblKontaktWebValue;

	/**
	 * text sluziaci na vypis gps suradnice - latitude
	 */
	private JLabel lblGpsLatitudeValue;
	
	/**
	 * text sluziaci na vypis gps suradnice - longtitude
	 */
	private JLabel lblGpsLogitudeValue;
	
	/**
	 * prazdny konstruktor pre vytvorenie panelu kontakt skoly pouzivaneho na
	 * obrazovke prehladu skol
	 */
	public SkolaKontaktPanel() {

		inicializaciaObrazovky();

	}

	/**
	 * inicializacia obrazovky
	 */
	private void inicializaciaObrazovky() {

		setBounds(10, 236, 500, 212);
		setLayout(null);

		JLabel lblPanelKontakt = new JLabel("Kontakt");
		lblPanelKontakt.setForeground(new Color(255, 128, 64));
		lblPanelKontakt.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblPanelKontakt.setBounds(10, 15, 60, 14);
		add(lblPanelKontakt);

		JPanel panelKontaktLineBorder = new JPanel();
		panelKontaktLineBorder.setLayout(null);
		panelKontaktLineBorder.setBorder(new MatteBorder(1, 0, 0, 0, (Color) new Color(192, 192, 192)));
		panelKontaktLineBorder.setBounds(0, 45, 500, 156);
		add(panelKontaktLineBorder);

		JLabel lblTelefon = new JLabel("");
		Image imgTelefon = new ImageIcon(this.getClass().getResource("/phone.png")).getImage();
		lblTelefon.setIcon(new ImageIcon(imgTelefon));
		lblTelefon.setBounds(10, 20, 20, 15);
		panelKontaktLineBorder.add(lblTelefon);

		JLabel lblEmail = new JLabel("Email");
		Image imgEmail = new ImageIcon(this.getClass().getResource("/email.png")).getImage();
		lblEmail.setIcon(new ImageIcon(imgEmail));
		lblEmail.setBounds(10, 45, 20, 15);
		panelKontaktLineBorder.add(lblEmail);

		JLabel lblWeb = new JLabel("Web");
		Image imgWeb = new ImageIcon(this.getClass().getResource("/www.png")).getImage();
		lblWeb.setIcon(new ImageIcon(imgWeb));
		lblWeb.setBounds(10, 70, 20, 15);
		panelKontaktLineBorder.add(lblWeb);

		// text sluziaci na vypis telefonu z kontaktu
		lblKontaktTelefonValue = new JLabel("nedefinované");
		lblKontaktTelefonValue.setForeground(new Color(158, 158, 158));
		lblKontaktTelefonValue.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblKontaktTelefonValue.setBounds(61, 20, 200, 15);
		panelKontaktLineBorder.add(lblKontaktTelefonValue);

		// text sluziaci na vypis emailu z kontaktu
		lblKontaktEmailValue = new JLabel("nedefinované");
		lblKontaktEmailValue.setForeground(new Color(158, 158, 158));
		lblKontaktEmailValue.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblKontaktEmailValue.setBounds(61, 45, 200, 15);
		panelKontaktLineBorder.add(lblKontaktEmailValue);

		// text sluziaci na vypis internetovej stranky z kontaktu
		lblKontaktWebValue = new JLabel("nedefinované");
		lblKontaktWebValue.setForeground(new Color(158, 158, 158));
		lblKontaktWebValue.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblKontaktWebValue.setBounds(61, 70, 200, 15);
		panelKontaktLineBorder.add(lblKontaktWebValue);
		
		JLabel lblGpsLatitude = new JLabel("GPS (LAT):");
		lblGpsLatitude.setBounds(253, 21, 64, 14);
		panelKontaktLineBorder.add(lblGpsLatitude);
		
		lblGpsLatitudeValue = new JLabel("nedefinované");
		lblGpsLatitudeValue.setForeground(new Color(158, 158, 158));
		lblGpsLatitudeValue.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblGpsLatitudeValue.setBounds(314, 20, 150, 15);
		panelKontaktLineBorder.add(lblGpsLatitudeValue);
		
		JLabel lblGpsLogitude = new JLabel("GPS (LON):");
		lblGpsLogitude.setBounds(253, 46, 64, 14);
		panelKontaktLineBorder.add(lblGpsLogitude);
		
		lblGpsLogitudeValue = new JLabel("nedefinované");
		lblGpsLogitudeValue.setForeground(new Color(158, 158, 158));
		lblGpsLogitudeValue.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblGpsLogitudeValue.setBounds(314, 45, 150, 15);
		panelKontaktLineBorder.add(lblGpsLogitudeValue);
	}

	// implementacie metody inform, ktora sluzi na zobrazenie aktualnych udajov o
	// kontakte z vybranej skoly z prehladu skol
	@Override
	public void inform(Skola skola) {

		lblKontaktTelefonValue.setText(skola.getKontakt().getPhone());
		lblKontaktEmailValue.setText(skola.getKontakt().getEmail());
		lblKontaktWebValue.setText(skola.getKontakt().getWww());
		Skola.GpsKoordinatori gosLatitude = skola.new GpsKoordinatori();
		lblGpsLatitudeValue.setText(gosLatitude.getSuradnice()[0]);
		lblGpsLogitudeValue.setText(gosLatitude.getSuradnice()[1]);
		
		

	}
}
