package sk.fiit.volby.page.skoly;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.MatteBorder;

import sk.fiit.volby.domain.skola.Skola;
import sk.fiit.volby.start.hra.InformovanieOzmeneUdajovSkoly;

/**
 * panel, ktory sluzi na zobrazenie informacii z adresy (primarne sa pouziva na
 * obrazovke skol)
 * 
 * @author nikola
 */
public class SkolaAdresaPanel extends JPanel implements InformovanieOzmeneUdajovSkoly {

	private static final long serialVersionUID = 6814097447302402490L;

	/**
	 * text sluziaci na vypis ulice z adresy
	 */
	private JLabel lblAdresaUlicaValue;

	/**
	 * text sluziaci na vypis mesta z adresy
	 */
	private JLabel lblAdresaMestoValue;

	/**
	 * text sluziaci na vypis PSC z adresy
	 */
	private JLabel lblAdresaPSCValue;

	/**
	 * text sluziaci na vypis statu z adresy
	 */
	private JLabel lblAdresaStatValue;

	/**
	 * prazdny konstruktor pre vytvorenie panelu adresa skoly pouzivaneho na
	 * obrazovke prehladu skol
	 */
	public SkolaAdresaPanel() {

		inicializaciaObrazovky();

	}

	/**
	 * inicializacia obrazovky
	 */
	private void inicializaciaObrazovky() {

		setLayout(null);
		setBounds(10, 46, 500, 179);

		JLabel lblPanelAdresa = new JLabel("Adresa");
		lblPanelAdresa.setForeground(new Color(255, 128, 64));
		lblPanelAdresa.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblPanelAdresa.setBounds(10, 15, 60, 14);
		add(lblPanelAdresa);

		JPanel panelAdresaLineBorder = new JPanel();
		panelAdresaLineBorder.setBorder(new MatteBorder(1, 0, 0, 0, (Color) new Color(192, 192, 192)));
		panelAdresaLineBorder.setBounds(0, 45, 500, 128);
		add(panelAdresaLineBorder);
		panelAdresaLineBorder.setLayout(null);

		JLabel lblAdresaUlica = new JLabel("Ulica");
		lblAdresaUlica.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblAdresaUlica.setBounds(10, 20, 50, 15);
		panelAdresaLineBorder.add(lblAdresaUlica);

		JLabel lblAdresaMesto = new JLabel("Mesto");
		lblAdresaMesto.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblAdresaMesto.setBounds(10, 45, 50, 15);
		panelAdresaLineBorder.add(lblAdresaMesto);

		JLabel lblAdresaPSC = new JLabel("PSČ");
		lblAdresaPSC.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblAdresaPSC.setBounds(10, 70, 50, 15);
		panelAdresaLineBorder.add(lblAdresaPSC);

		JLabel lblAdresaStat = new JLabel("Štát");
		lblAdresaStat.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblAdresaStat.setBounds(10, 95, 50, 15);
		panelAdresaLineBorder.add(lblAdresaStat);

		// text sluziaci na vypis ulice z adresy
		lblAdresaUlicaValue = new JLabel("nedefinované");
		lblAdresaUlicaValue.setForeground(new Color(158, 158, 158));
		lblAdresaUlicaValue.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblAdresaUlicaValue.setBounds(100, 20, 360, 15);
		panelAdresaLineBorder.add(lblAdresaUlicaValue);

		// text sluziaci na vypis mesta z adresy
		lblAdresaMestoValue = new JLabel("nedefinované");
		lblAdresaMestoValue.setForeground(new Color(158, 158, 158));
		lblAdresaMestoValue.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblAdresaMestoValue.setBounds(100, 45, 360, 15);
		panelAdresaLineBorder.add(lblAdresaMestoValue);

		// text sluziaci na vypis PSC z adresy
		lblAdresaPSCValue = new JLabel("nedefinované");
		lblAdresaPSCValue.setForeground(new Color(158, 158, 158));
		lblAdresaPSCValue.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblAdresaPSCValue.setBounds(100, 70, 360, 15);
		panelAdresaLineBorder.add(lblAdresaPSCValue);

		// text sluziaci na vypis statu z adresy
		lblAdresaStatValue = new JLabel("nedefinované");
		lblAdresaStatValue.setForeground(new Color(158, 158, 158));
		lblAdresaStatValue.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblAdresaStatValue.setBounds(100, 95, 360, 15);
		panelAdresaLineBorder.add(lblAdresaStatValue);
	}

	// implementacia metody inform, ktora sluzi na zobrazenie aktualnych udajov o
	// adrese z vybranej skoly z prehladu skol
	@Override
	public void inform(Skola skola) {
		lblAdresaUlicaValue.setText(skola.getAdresa().getUlica());
		lblAdresaMestoValue.setText(skola.getAdresa().getObec());
		lblAdresaPSCValue.setText(skola.getAdresa().getPsc());
		lblAdresaStatValue.setText(skola.getAdresa().getStat());

	}

}
