package sk.fiit.volby.page.volby.rocniky;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import sk.fiit.volby.domain.volby.Rocnik;
import sk.fiit.volby.start.RunApp;

/**
 * obrazovka na zobrazenie prehladu rocnikov
 * 
 * @author nikola
 */
public abstract class RocnikyPage extends JDialog {

	private static final long serialVersionUID = -2540021982433143238L;

	/**
	 * tabulka na zobrazenie prehladu rocnikov
	 */
	protected JTable tablePrehladRocnikov;

	/**
	 * prazdny konstruktor pre vytvorenie obrazovky prehladu rocnikov 
	 */
	public RocnikyPage() {

		inicializaciaObrazovky();
	
	}
	
	/**
	 * inicializacia obrazovky
	 */
	private void inicializaciaObrazovky() {

		setTitle(RunApp.getProperties().getProperty("prehlad.rocnikov.page.title"));
		setSize(729, 380);
		getContentPane().setLayout(null);

		Image imgAdminLogo = new ImageIcon(this.getClass().getResource("/logo.png")).getImage();
		setIconImage(imgAdminLogo);

		JPanel panelPrehladRocnikov = new JPanel();
		panelPrehladRocnikov.setBorder(new LineBorder(new Color(0, 0, 0)));
		panelPrehladRocnikov.setBounds(10, 11, 682, 315);
		getContentPane().add(panelPrehladRocnikov);
		panelPrehladRocnikov.setLayout(null);

		// tlacitko na pridanie rocnika
		JButton btnPridatRocnika = new JButton("Pridať");
		btnPridatRocnika.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				Rocnik novyRocnik = new Rocnik();
				// vytvorenie instancie obrazovky pre zadanie noveho rocnika
				PridatRocnikDialog pridatRocnikDialog = new PridatRocnikDialog(novyRocnik) {

					private static final long serialVersionUID = 8767775591734715243L;

					// volanie metody vytvorenia noveho rocnika
					@Override
					protected void vytvoritRocnik(String nazov) {
						RocnikyPage.this.vytvoritRocnik(nazov);

					}

				};
				pridatRocnikDialog.setLocationRelativeTo(null);
				pridatRocnikDialog.setAlwaysOnTop(true);
				pridatRocnikDialog.setModal(true);
				pridatRocnikDialog.setVisible(true);
			}
		});
		btnPridatRocnika.setBounds(10, 280, 90, 23);
		panelPrehladRocnikov.add(btnPridatRocnika);

		JScrollPane scrollPanePrehladRocnikov = new JScrollPane();
		scrollPanePrehladRocnikov.setBounds(10, 42, 644, 227);
		panelPrehladRocnikov.add(scrollPanePrehladRocnikov);

		// vytvorenie instancie tabulky s prehladom rocnikov
		tablePrehladRocnikov = new JTable();
		tablePrehladRocnikov.setFillsViewportHeight(true);
		tablePrehladRocnikov.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		// nadefinovanie stlpcov, ktore bude obsahovat tabulka
		tablePrehladRocnikov.setModel(new DefaultTableModel(new Object[][] {}, new String[] { "Názov", "Skola" }) {

			private static final long serialVersionUID = -5459399120597283875L;

			// tabulka bude klikatelna
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}

		});
		tablePrehladRocnikov.getColumnModel().getColumn(0).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - z rocnika si zoberieme
			// nazov rocnika, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Rocnik rocnik = (Rocnik) value;
				setText(rocnik.getNazov());

				return this;
			}
		});
		tablePrehladRocnikov.getColumnModel().getColumn(1).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - z rocnika si zoberieme
			// nazov skoly, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Rocnik rocnik = (Rocnik) value;
				setText(rocnik.getSkola().getNazov());

				return this;
			}
		});

		scrollPanePrehladRocnikov.setBorder(new MatteBorder(1, 0, 0, 0, (Color) new Color(192, 192, 192)));
		scrollPanePrehladRocnikov.setViewportView(tablePrehladRocnikov);

		JPanel panelPrehladRocnikovCaption = new JPanel();
		panelPrehladRocnikovCaption.setBackground(new Color(0, 0, 0));
		panelPrehladRocnikovCaption.setBounds(0, 0, 682, 31);
		panelPrehladRocnikov.add(panelPrehladRocnikovCaption);
		panelPrehladRocnikovCaption.setLayout(null);

		JLabel lblPrehladRocnikovCaption = new JLabel("Prehlad rocnikov");
		lblPrehladRocnikovCaption.setForeground(new Color(255, 255, 255));
		lblPrehladRocnikovCaption.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblPrehladRocnikovCaption.setBounds(10, 7, 127, 14);
		panelPrehladRocnikovCaption.add(lblPrehladRocnikovCaption);

		// tlacitko na zobrazenie obrazovky pre aktualizaciu rocnika
		JButton btnUpravitRocnika = new JButton("Upraviť");
		btnUpravitRocnika.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				// kontrola, ci je vybrany zaznam v tabulke
				if (tablePrehladRocnikov.getSelectionModel().isSelectionEmpty() == false) {

					// identifikacia riadku z tabulky, na ktory pouzivatel klikol
					int row = tablePrehladRocnikov.getSelectedRow();

					// identifikacia stlpcu z tabulky, na ktory pouzivatel klikol
					int column = tablePrehladRocnikov.getSelectedColumn();

					// ziskanie objektu rocnik z pozadovanej bunky tabulky nachadzajucej sa na
					// pozicii row,column
					Rocnik rocnik = (Rocnik) tablePrehladRocnikov.getModel().getValueAt(row, column);

					// vytvorenie instancie obrazovky pre aktualizaciu rocnika
					PridatRocnikDialog pridatRocnikaDialog = new PridatRocnikDialog(rocnik) {

						private static final long serialVersionUID = -9142384259878262885L;

						// volanie metody pre upravenie rocnika
						@Override
						protected void upravitRocnik(int rocnikId, String nazov) {
							RocnikyPage.this.upravitRocnik(rocnikId, nazov);
						}

					};
					pridatRocnikaDialog.setLocationRelativeTo(null);
					pridatRocnikaDialog.setAlwaysOnTop(true);
					pridatRocnikaDialog.setModal(true);
					pridatRocnikaDialog.setVisible(true);
				}
			}
		});

		btnUpravitRocnika.setBounds(110, 280, 90, 23);
		panelPrehladRocnikov.add(btnUpravitRocnika);

		// button na vymazanie rocnika zo zoznamu rocnikov
		JButton btnVymazatRocnika = new JButton("Vymazať");
		btnVymazatRocnika.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				// kontrola, ci je vybrany zaznam v tabulke
				if (tablePrehladRocnikov.getSelectionModel().isSelectionEmpty() == false) {

					// identifikacia riadku z tabulky, na ktory pouzivatel klikol
					int row = tablePrehladRocnikov.getSelectedRow();

					// identifikacia stlpcu z tabulky, na ktory pouzivatel klikol
					int column = tablePrehladRocnikov.getSelectedColumn();

					// ziskanie objektu rocnik z pozadovanej bunky tabulky nachadzajucej sa na
					// pozicii row,column
					Rocnik rocnik = (Rocnik) tablePrehladRocnikov.getModel().getValueAt(row, column);

					// ak sa zhoduje id rocnika s id vybraneho rocnika zo zoznamu,
					// vybrany rocnik odstranime
					RocnikyPage.this.vymazatRocnik(rocnik.getId());

				}

			}

		});
		btnVymazatRocnika.setBounds(210, 280, 90, 23);
		panelPrehladRocnikov.add(btnVymazatRocnika);

		// zrusenie okna so zoznamom rocnikov
		JButton btnZrusit = new JButton("Zrušiť");
		btnZrusit.setBounds(310, 281, 85, 21);
		panelPrehladRocnikov.add(btnZrusit);
		btnZrusit.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				RocnikyPage.this.dispose();
			}

		});
	}

	/**
	 * metoda na vytvorenie rocnika s pozadovanymi parametrami
	 * 
	 * @param nazov - nazov rocnika
	 */
	protected abstract void vytvoritRocnik(String nazov);

	/**
	 * metoda na aktualizaciu rocnika s pozadovanymi parametrami
	 * 
	 * @param rocnikId - identifikator rocnika
	 * @param nazov - nazov rocnika
	 */
	protected abstract void upravitRocnik(int rocnikId, String nazov);

	/**
	 * metoda na vymazanie rocnika
	 * 
	 * @param rocnikId - identifikator rocnika
	 */
	protected abstract void vymazatRocnik(Integer id);

}
