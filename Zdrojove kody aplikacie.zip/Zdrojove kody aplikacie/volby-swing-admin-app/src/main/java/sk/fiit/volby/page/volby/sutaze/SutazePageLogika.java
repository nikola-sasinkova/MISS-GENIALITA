package sk.fiit.volby.page.volby.sutaze;

import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import javax.swing.table.DefaultTableModel;

import sk.fiit.volby.domain.skola.Skola;
import sk.fiit.volby.domain.volby.Rocnik;
import sk.fiit.volby.domain.volby.Sutaz;
import sk.fiit.volby.start.hra.InformovanieOzmeneUdajov;
import sk.fiit.volby.start.hra.nastavenia.HraVolbyNastaveniaImpl;

/**
 * trieda, ktora vychadza (sa dedi) z obrazovky s prehladom sutazi, a ktora sa
 * pouziva v navrhovom vzore Observer
 * 
 * @author nikola
 */
public abstract class SutazePageLogika extends SutazePage implements InformovanieOzmeneUdajov {

	private static final long serialVersionUID = -8833746473705218699L;

	/**
	 * aktualna instancia beziacej hry
	 */
	private HraVolbyNastaveniaImpl hraVolbyNastaveniaImpl;

	/**
	 * zoznam sutazi, ktori sa budu zobrazovat v tabulke s prehladom sutazi
	 */
	private List<Sutaz> sutaze;

	/**
	 * konstruktor pre vytvorenie obrazovky prehladu sutazi s pozadovanymi
	 * parametrami
	 * 
	 * @param hraVolbyNastaveniaImpl - instancia mojej hry
	 */
	public SutazePageLogika(HraVolbyNastaveniaImpl hraVolbyNastaveniaImpl) {
		super(hraVolbyNastaveniaImpl);
		this.hraVolbyNastaveniaImpl = hraVolbyNastaveniaImpl;
	}

	/**
	 * konkretna implementacia metody z interfacu InformovanieOzmeneUdajov pre
	 * obrazovku prehladu sutazi
	 */
	@Override
	public void inform() {

		// ziskanie aktualnych sutazi z instancie mojej hry
		sutaze = hraVolbyNastaveniaImpl.getSutaze();

		// ziskanie modelu tabulky, ktory zobrazuje prehlad sutazi
		DefaultTableModel model = (DefaultTableModel) tablePrehladSutazi.getModel();

		// vynulovanie poctu riadkov v modeli tabulky
		model.setRowCount(0);

		if (sutaze != null) {
			// prechadzanie zoznamu sutazi a plnenie riadkov tabulky
			for (Sutaz sutaz : sutaze) {
				model.addRow(new Object[] { sutaz, sutaz, sutaz, sutaz, sutaz, sutaz, sutaz });
			}
		}

	}

	/**
	 * metoda na vytvorenie sutaze s pozadovanymi parametrami
	 * 
	 * @param nazov                       - nazov sutaze
	 * @param popis                       - popis sutaze
	 * @param rocnik                      - rocnik, pre ktory bude sutaz vytvorena
	 * @param datumUkonceniaPrihlasovania - datum ukoncenia prihlasovania sutaze
	 * @param datumSpusteniaHlasovania    - datum spustenia hlasovania sutaze
	 * @param datumZverejnenia            - datum zverejnenia sutaze
	 */
	@Override
	protected void vytvoritSutaz(String nazov, String popis, Rocnik rocnik, Date datumUkoncenieHlasovania,
			Date datumSpristupnenieHlasovania, Date datumZverejnenia) {

		// vyber prvej skoly v poradi zo zoznamu skol (kedze mam len jednu skolu, vybera
		// sa konkretna skola)
		Skola skola = hraVolbyNastaveniaImpl.getSkoly().get(0);

		// zoradenie zoznamu sutazi vzostupne podla id od najmensieho po najvacsie
		Collections.sort(sutaze, Comparator.comparing(Sutaz::getId));

		// ziskanie najvacsej hodnoty id nachadzajucej sa v zozname a pripocitanie 1, ak
		// je zoznam prazdny id nastavim na 1
		int id = sutaze.size() == 0 ? 1 : sutaze.get(sutaze.size() - 1).getId() + 1;

		// vytvorenie instancie sutaze s pozadovanymi parametrami
		Sutaz sutaz = new Sutaz(id, skola, rocnik, nazov, popis, datumUkoncenieHlasovania, datumSpristupnenieHlasovania,
				datumZverejnenia);

		// zaradenie vytvorenej sutaze do zoznamu sutazi v mojej hre
		sutaze.add(sutaz);

		// zavolanie konkretnej imlementacie metody inform z interfacu DataFollower
		inform();

		SutazePageLogika.this.refreshSutaze();

	}

	/**
	 * metoda na upravenie sutaze s pozadovanymi parametrami
	 * 
	 * @param sutazId                     - identifikator sutaze
	 * @param nazov                       - nazov sutaze
	 * @param popis                       - popis sutaze
	 * @param rocnik                      - rocnik, pre ktory bude sutaz vytvorena
	 * @param datumUkonceniaPrihlasovania - datum ukoncenia prihlasovania sutaze
	 * @param datumSpusteniaHlasovania    - datum spustenia hlasovania sutaze
	 * @param datumZverejnenia            - datum zverejnenia sutaze
	 */
	@Override
	protected void upravitSutaz(int sutazId, String nazov, String popis, Rocnik rocnik, Date datumUkoncenieHlasovania,
			Date datumSpusteniaHlasovania, Date datumZverejnenia) {

		// vyber prvej skoly v poradi zo zoznamu skol (kedze mam len jednu skolu, vybera
		// sa konkretna skola)
		Skola skola = hraVolbyNastaveniaImpl.getSkoly().get(0);

		// prechadzanie zoznamu sutazi definovanych v hre
		for (Sutaz sutaz : sutaze) {

			// ak sa zhoduje id sutaze s id vybranej sutaze zo zoznamu,
			// vybranu sutaz aktualizujeme
			if (sutaz.getId().equals(sutazId)) {
				sutaz.setNazov(nazov);
				sutaz.setSkola(skola);
				sutaz.setPopis(popis);
				sutaz.setRocnik(rocnik);
				sutaz.setDatumUkonceniaPrihlasovania(datumUkoncenieHlasovania);
				sutaz.setDatumSpusteniaHlasovania(datumSpusteniaHlasovania);
				sutaz.setDatumZverejnenia(datumZverejnenia);

				// zavolanie konkretnej imlementacie metody inform z interfacu DataFollower
				inform();

				SutazePageLogika.this.refreshSutaze();

				break;
			}
		}

	}

	/**
	 * metoda na vymazanie sutaze
	 * 
	 * @param id - identifikator sutaze
	 */
	@Override
	protected void vymazatSutaz(Integer id) {

		for (Sutaz sutaz : sutaze) {
			if (sutaz.getId().equals(id)) {
				sutaze.remove(sutaz);

				// ak sutaz nie je v tabulke sutazi, tak sa vynuluju aj vsetky zavisle entity -
				// uchadzaci
				SutazePageLogika.this.vynulovanieUdajovAkJeZoznamSutaziPrazdny(sutaz);
				inform();

				// refreshnu sa vsetky panely, aby sa aktualizoval pocet sutazi zobrazujucich sa
				// v paneloch
				SutazePageLogika.this.refreshSutaze();

				break;
			}
		}

	}

	/**
	 * refreshnu sa vsetky panely, aby sa aktualizoval pocet sutazi zobrazujucich sa
	 * v paneloch
	 */
	protected abstract void refreshSutaze();

	/**
	 * ak sutaz nie je v tabulke sutazi, tak sa vynuluju aj vsetky zavisle entity -
	 * uchadzaci
	 */
	protected abstract void vynulovanieUdajovAkJeZoznamSutaziPrazdny(Sutaz sutaz);

}
