package sk.fiit.volby.page.volby.pouzivatelia;

import java.util.List;

import javax.swing.table.DefaultTableModel;

import sk.fiit.volby.domain.pouzivatel.Pouzivatel;
import sk.fiit.volby.start.hra.InformovanieOzmeneUdajov;
import sk.fiit.volby.start.hra.nastavenia.HraVolbyNastaveniaImpl;

/**
 * trieda, ktora vychadza (sa dedi) z obrazovky s prehladom pouzivatelov, a
 * ktora sa pouziva v navrhovom vzore Observer
 * 
 * @author nikola
 */
public class PouzivateliaPageLogika extends PouzivateliaPage implements InformovanieOzmeneUdajov {

	private static final long serialVersionUID = 8052391743170545469L;

	/**
	 * aktualna instancia beziacej hry
	 */
	private HraVolbyNastaveniaImpl hraVolbyNastaveniaImpl;

	/**
	 * zoznam pouzivatelov, ktori sa budu zobrazovat v tabulke s prehladom
	 * pouzivatelov
	 */
	private List<Pouzivatel> pouzivatelia;

	/**
	 * konstruktor pre vytvorenie obrazovky prehladu pouzivatelov s pozadovanymi
	 * parametrami
	 * 
	 * @param hraVolbyNastaveniaImpl - instancia mojej hry
	 */
	public PouzivateliaPageLogika(HraVolbyNastaveniaImpl hraVolbyNastaveniaImpl) {
		super();
		this.hraVolbyNastaveniaImpl = hraVolbyNastaveniaImpl;
	}

	/**
	 * konkretna implementacia metody z interfacu InformovanieOzmeneUdajov pre
	 * obrazovku prehladu pouzivatelov
	 */
	@Override
	public void inform() {
		// ziskanie aktualnych pouzivatelov z instancie mojej hry
		pouzivatelia = hraVolbyNastaveniaImpl.getPouzivatelia();

		// ziskanie modelu tabulky, ktory zobrazuje prehlad pouzivatelov
		DefaultTableModel model = (DefaultTableModel) tablePrehladPouzivatelov.getModel();

		// vynulovanie poctu riadkov v modeli tabulky
		model.setRowCount(0);

		// prechadzanie zoznamu pouzivatelov a plnenie riadkov tabulky
		if (pouzivatelia != null) {
			for (Pouzivatel pouzivatel : pouzivatelia) {
				model.addRow(new Object[] { pouzivatel, pouzivatel, pouzivatel, pouzivatel, pouzivatel });
			}
		}

	}

	/**
	 * metoda na vymazanie pouzivatela
	 * 
	 * @param id - identifikator pouzivatela
	 */
	@Override
	protected void vymazatPouzivatela(Integer id) {

		for (Pouzivatel pouzivatel : pouzivatelia) {
			if (pouzivatel.getId().equals(id)) {
				pouzivatelia.remove(pouzivatel);
				inform();
				break;
			}
		}

	}

}
