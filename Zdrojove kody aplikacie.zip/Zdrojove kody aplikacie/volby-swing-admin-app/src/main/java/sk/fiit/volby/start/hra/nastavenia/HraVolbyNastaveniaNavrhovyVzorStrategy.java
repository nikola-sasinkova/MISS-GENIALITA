package sk.fiit.volby.start.hra.nastavenia;

import java.util.ArrayList;
import java.util.List;

import sk.fiit.volby.domain.pouzivatel.Pouzivatel;
import sk.fiit.volby.domain.skola.Skola;
import sk.fiit.volby.domain.volby.Rocnik;
import sk.fiit.volby.domain.volby.Sutaz;
import sk.fiit.volby.domain.volby.ucastnici.volby.Porotca;
import sk.fiit.volby.domain.volby.ucastnici.volby.Uchadzac;
import sk.fiit.volby.domain.volby.ucastnici.volby.Ziak;

/**
 * trieda implementujuca navrhovy vzor strategy
 * 
 * @author nikola
 */
public class HraVolbyNastaveniaNavrhovyVzorStrategy {

	/**
	 * rozhranie, ktore sluzi na inicialne naplnenie udajov (privatny interface)
	 */
	private HraVolbyNastavenia hraVolbyNastavenia;

	/**
	 * konstruktor s pozadovanym parametrom
	 * 
	 * @param hraVolbyNastavenia - nastavenia hry
	 */
	public HraVolbyNastaveniaNavrhovyVzorStrategy(HraVolbyNastavenia hraVolbyNastavenia) {
		this.hraVolbyNastavenia = hraVolbyNastavenia;
	}

	/**
	 * metoda, ktora sluzi na vytvorenie inicializacnych udajov s navrhovym vzorom
	 * strategy
	 * 
	 * @param hraVolbyNastaveniaImpl - instancia mojej hry
	 */
	public void vytvorenieInicializacnychUdajovNavrhovyVzorStrategy(HraVolbyNastaveniaImpl hraVolbyNastaveniaImpl) {

		List<Skola> skoly = new ArrayList<Skola>();
		List<Porotca> porotcovia = new ArrayList<Porotca>();
		List<Ziak> ziaci = new ArrayList<Ziak>();
		List<Uchadzac> uchadzaci = new ArrayList<Uchadzac>();
		List<Rocnik> rocniky = new ArrayList<Rocnik>();
		List<Sutaz> sutaze = new ArrayList<Sutaz>();
		List<Pouzivatel> pouzivatelia = new ArrayList<Pouzivatel>();

		hraVolbyNastavenia.nastavenie(skoly, porotcovia, ziaci, uchadzaci, rocniky, sutaze, pouzivatelia);

		// refreshovanie dat prostrenictvom strategy pattern observer
		hraVolbyNastaveniaImpl.nastavenieUdajovCezNavrhovyVzorStrategy(skoly, porotcovia, ziaci, uchadzaci, rocniky,
				sutaze, pouzivatelia);

		hraVolbyNastaveniaImpl.informInformovanieOzmeneUdajovList();

	}
}
