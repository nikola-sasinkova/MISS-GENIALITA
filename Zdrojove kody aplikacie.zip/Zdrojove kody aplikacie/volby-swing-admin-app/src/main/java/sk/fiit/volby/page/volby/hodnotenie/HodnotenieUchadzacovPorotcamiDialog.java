package sk.fiit.volby.page.volby.hodnotenie;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import sk.fiit.volby.domain.volby.ucastnici.volby.Porotca;
import sk.fiit.volby.domain.volby.ucastnici.volby.Uchadzac;
import sk.fiit.volby.domain.vyhodnotenie.PriebezneHodnotenieUchadzaca;
import sk.fiit.volby.start.RunApp;
import sk.fiit.volby.utils.generic.VolbyPair;

/**
 * obrazovka na zobrazenie prehladu hodnoteni porotcami
 * 
 * @author nikola
 */
public abstract class HodnotenieUchadzacovPorotcamiDialog extends JDialog {

	private static final long serialVersionUID = 5828595145975178136L;

	/**
	 * tabulka na zobrazenie prehladu porotcov
	 */
	protected JTable tablePrehladPorodcov;

	/**
	 * policko na zobrazenie nazvu prace uchadzaca
	 */
	private JTextField textFieldUchadzacNazovPrace;

	/**
	 * policko na zobrazenie formatovaneho mena uchadzaca
	 */
	private JTextField textFieldFormatovaneMenoUchadzaca;

	/**
	 * policko na zobrazenie a zadavanie poctu bodov
	 */
	private JTextField textFieldPocetBodov;

	/**
	 * konstruktor s pozadovanymi parametrami
	 * 
	 * @param porotcovia - porotcovia, ktori budu hodnotit
	 * @param uchadzac   - vybrany uchadzac, ktoreho budu porotcovia hodnotit
	 */
	public HodnotenieUchadzacovPorotcamiDialog(List<Porotca> porotcovia, Uchadzac uchadzac) {

		inicializaciaObrazovky(porotcovia, uchadzac);

	}

	/**
	 * inicializacia obrazovky
	 * 
	 * @param porotcovia - porotcovia, ktori budu hodnotit
	 * @param uchadzac   - vybrany uchadzac, ktoreho budu porotcovia hodnotit
	 */
	public void inicializaciaObrazovky(List<Porotca> porotcovia, Uchadzac uchadzac) {

		getContentPane().setLayout(null);
		setBounds(0, 0, 924, 395);

		setTitle(RunApp.getProperties().getProperty("hodnotenie.uchadzaca.porotcom.page.title"));
		getContentPane().setLayout(null);
		setSize(740, 439);

		Image imgAdminLogo = new ImageIcon(this.getClass().getResource("/logo.png")).getImage();
		setIconImage(imgAdminLogo);

		JPanel panelPrehladPorotcov = new JPanel();
		panelPrehladPorotcov.setBorder(new LineBorder(new Color(0, 0, 0)));
		panelPrehladPorotcov.setBounds(10, 11, 706, 378);
		getContentPane().add(panelPrehladPorotcov);
		panelPrehladPorotcov.setLayout(null);

		JScrollPane scrollPane = new JScrollPane();
		// panelPrehladPorotcov.setBounds(10, 11, 921, 517);
		scrollPane.setBounds(10, 42, 690, 176);
		panelPrehladPorotcov.add(scrollPane);

		// vytvorenie instancie tabulky s prehladom porotcov
		tablePrehladPorodcov = new JTable();
		scrollPane.setViewportView(tablePrehladPorodcov);
		tablePrehladPorodcov.setFillsViewportHeight(true);
		tablePrehladPorodcov.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		// nadefinovanie stlpcov, ktore bude obsahovat tabulka
		tablePrehladPorodcov.setModel(new DefaultTableModel(new Object[][] {}, new String[] { "Titul pred menom",
				"Meno", "Stredne meno", "Priezvisko", "Titul za menom", "Rola", "Pocet bodov" }) {

			private static final long serialVersionUID = -5459399120597283875L;

			// tabulka bude klikatelna
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}

		});

		tablePrehladPorodcov.getColumnModel().getColumn(0).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - z porotcu si zoberieme
			// titul pred menom, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Porotca porodcaDto = (Porotca) value;
				setText(porodcaDto.getTitulPredMenom());

				return this;
			}
		});
		tablePrehladPorodcov.getColumnModel().getColumn(1).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - z porotcu si zoberieme
			// meno, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Porotca porodcaDto = (Porotca) value;
				setText(porodcaDto.getMeno());

				return this;
			}
		});
		tablePrehladPorodcov.getColumnModel().getColumn(2).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - z porotcu si zoberieme
			// stredne meno, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Porotca porodcaDto = (Porotca) value;
				setText(porodcaDto.getStredneMeno());

				return this;
			}
		});
		tablePrehladPorodcov.getColumnModel().getColumn(3).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - z porotcu si zoberieme
			// priezvisko, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Porotca porodcaDto = (Porotca) value;
				setText(porodcaDto.getPriezvisko());

				return this;
			}
		});
		tablePrehladPorodcov.getColumnModel().getColumn(4).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - z porotcu si zoberieme
			// titul za menom, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Porotca porodcaDto = (Porotca) value;
				setText(porodcaDto.getTitulZaMenom());

				return this;
			}
		});

		tablePrehladPorodcov.getColumnModel().getColumn(5).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - z porotcu si zoberieme
			// rolu porotcu, ktoru budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Porotca porodcaDto = (Porotca) value;
				setText(porodcaDto.getRolaPorotcu().name());

				return this;
			}
		});

		tablePrehladPorodcov.getColumnModel().getColumn(6).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - z hodnotenia si zoberieme
			// pocet bodov od porotcu, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Porotca porodca = (Porotca) value;
				PriebezneHodnotenieUchadzaca hodnotenie = getHodnoteniePorotcu(porodca, uchadzac);
				setText(String.valueOf(hodnotenie.getPocetBodovOdPorotcu()));

				return this;
			}
		});

		// listener pocuvajuci na kliknutie myskou do tabulky porotcov, ked sa klikne do
		// tabulky myskou, ziska sa prislusny porotca z riadku, z porotcu sa ziska jeho
		// prislusne
		// hodnotenie (informacia zobrazujuca sa v poslednom stlpci) a nasledne sa
		// zobrazi v
		// policku hodnotenia
		tablePrehladPorodcov.addMouseListener(new java.awt.event.MouseAdapter() {
			@Override
			public void mouseClicked(java.awt.event.MouseEvent evt) {

				int row = tablePrehladPorodcov.rowAtPoint(evt.getPoint());
				int column = tablePrehladPorodcov.columnAtPoint(evt.getPoint());
				if (row >= 0 && column >= 0) {
					Porotca porotca = (Porotca) tablePrehladPorodcov.getModel().getValueAt(row, column);
					PriebezneHodnotenieUchadzaca hodnotenie = getHodnoteniePorotcu(porotca, uchadzac);
					// zobrazenie hodnoty priebezneho hodnotenia do policka - pocet bodov
					textFieldPocetBodov.setText(String.valueOf(hodnotenie.getPocetBodovOdPorotcu()));
				}
			}
		});
		refreshPrehladPorotcov(porotcovia);

		JPanel panelPrehladPorotcovCaption = new JPanel();
		panelPrehladPorotcovCaption.setBackground(new Color(0, 0, 0));
		panelPrehladPorotcovCaption.setBounds(0, 0, 921, 31);
		panelPrehladPorotcov.add(panelPrehladPorotcovCaption);
		panelPrehladPorotcovCaption.setLayout(null);

		JLabel lblPrehladPorotcovCaption = new JLabel("Hodnotenie uchadzaca porotcami");
		lblPrehladPorotcovCaption.setForeground(new Color(255, 255, 255));
		lblPrehladPorotcovCaption.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblPrehladPorotcovCaption.setBounds(10, 7, 224, 14);
		panelPrehladPorotcovCaption.add(lblPrehladPorotcovCaption);

		// zrusenie okna so zoznamom porotcov
		JButton btnZrusit = new JButton("Zrušiť");
		btnZrusit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				HodnotenieUchadzacovPorotcamiDialog.this.dispose();
			}
		});
		btnZrusit.setBounds(591, 344, 105, 23);
		panelPrehladPorotcov.add(btnZrusit);

		JLabel lblUchadzacLabel = new JLabel("Uchadzac");
		lblUchadzacLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblUchadzacLabel.setBounds(20, 229, 80, 14);
		panelPrehladPorotcov.add(lblUchadzacLabel);

		JLabel lblUchadzacNazovPraceLabel = new JLabel("Názov práce");
		lblUchadzacNazovPraceLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblUchadzacNazovPraceLabel.setBounds(20, 253, 80, 14);
		panelPrehladPorotcov.add(lblUchadzacNazovPraceLabel);

		JLabel lblUchadzacPopisPraceLabel = new JLabel("Popis práce");
		lblUchadzacPopisPraceLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblUchadzacPopisPraceLabel.setBounds(20, 277, 80, 14);
		panelPrehladPorotcov.add(lblUchadzacPopisPraceLabel);

		textFieldFormatovaneMenoUchadzaca = new JTextField();
		textFieldFormatovaneMenoUchadzaca.setBounds(110, 229, 296, 20);
		textFieldFormatovaneMenoUchadzaca.setText(uchadzac.getFormatovaneMenoOsoby());
		panelPrehladPorotcov.add(textFieldFormatovaneMenoUchadzaca);

		textFieldUchadzacNazovPrace = new JTextField();
		textFieldUchadzacNazovPrace.setBounds(110, 253, 296, 20);
		textFieldUchadzacNazovPrace.setText(uchadzac.getVyskumnaPraca().getNazov());
		panelPrehladPorotcov.add(textFieldUchadzacNazovPrace);

		JTextArea textArea = new JTextArea();
		textArea.setBounds(110, 277, 296, 54);
		textArea.setWrapStyleWord(true);
		textArea.setLineWrap(true);
		textArea.setText(uchadzac.getVyskumnaPraca().getPopis());
		panelPrehladPorotcov.add(textArea);

		JLabel lblPocetBodovLabel = new JLabel("Pocet bodov");
		lblPocetBodovLabel.setForeground(new Color(255, 0, 0));
		lblPocetBodovLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblPocetBodovLabel.setBounds(449, 229, 78, 14);
		panelPrehladPorotcov.add(lblPocetBodovLabel);

		textFieldPocetBodov = new JTextField();
		textFieldPocetBodov.setBounds(449, 251, 86, 20);
		panelPrehladPorotcov.add(textFieldPocetBodov);

		JButton btnNastavitPocetBodov = new JButton("Nastaviť");
		btnNastavitPocetBodov.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (tablePrehladPorodcov.getSelectionModel().isSelectionEmpty() == false) {
					int row = tablePrehladPorodcov.getSelectedRow();
					int column = tablePrehladPorodcov.getSelectedColumn();

					Porotca porotca = (Porotca) tablePrehladPorodcov.getModel().getValueAt(row, column);
					if (textFieldPocetBodov.getText().trim() != "") {

						PriebezneHodnotenieUchadzaca priebezneHodnotenieUchadzaca = getHodnoteniePorotcu(porotca,
								uchadzac);
						priebezneHodnotenieUchadzaca
								.setPocetBodovOdPorotcu(Integer.parseInt(textFieldPocetBodov.getText().trim()));
						uchadzac.aktualizovatPriebezneHodnotenieUchadzacaPorotcu(priebezneHodnotenieUchadzaca);

						uchadzac.vypocetBodovehoHodnotenia();

						// obnovenie udajov v tabulke s prehladom porotcov
						refreshPrehladPorotcov(porotcovia);

						// obnovenie udajov v tabulke s prehladom uchadzacov
						refreshPrehladUcastnikov();

					}

				}

			}
		});
		btnNastavitPocetBodov.setBounds(545, 250, 89, 23);
		panelPrehladPorotcov.add(btnNastavitPocetBodov);

	}

	/**
	 * zo zoznamu vsetkych priebeznych hodnoteni porotcov, ziskame priebezne
	 * hodnotenie pre pozadovaneho porotcu, ak priebezne hodnotenie u porotcu
	 * neexistuje, vytvorime ho s hodnotou 0
	 * 
	 * prechadza vsetky priebezne hodnotenia, ktore su na uchadzacovi, da ich
	 * zoznam, na uchadzacovi drzim vsetky jeho hodnotenia, za vsetkych porotcov
	 * 
	 * da vsetkych uchadzacov a ich priebezne hodnotenia za vsetkych porotcov
	 * 
	 * @param porotca  - porotca, ktoreho hodnotenie pozadujeme zistit
	 * @param uchadzac - vybrany uchadzac, ktoreho hodnotenie pozadujeme zistit
	 * @return priebezneHodnotenieUchadzaca
	 */
	private PriebezneHodnotenieUchadzaca getHodnoteniePorotcu(Porotca porotca, Uchadzac uchadzac) {

		for (VolbyPair<Porotca, PriebezneHodnotenieUchadzaca> priebezneHodnotenieUchadzaca : uchadzac
				.getPriebezneHodnoteniaPorotcov().getZoznamParovanychDvojic()) {
			Porotca porotcaZoZoznamu = priebezneHodnotenieUchadzaca.ziskatKlucZaznamu();
			if (porotcaZoZoznamu.getId().equals(porotca.getId())) {
				return priebezneHodnotenieUchadzaca.ziskatHodnotuZaznamu();
			}
		}

		PriebezneHodnotenieUchadzaca priebezneHodnotenieUchadzaca = new PriebezneHodnotenieUchadzaca(porotca, uchadzac,
				0);
		uchadzac.aktualizovatPriebezneHodnotenieUchadzacaPorotcu(priebezneHodnotenieUchadzaca);
		return priebezneHodnotenieUchadzaca;

	}

	/**
	 * zobrazenie a obnovenie udajov v tabulke na aktualne hodnoty - vynulujeme
	 * tabulku tak, ze ma 0 zaznamov a znova nacitame porotcov s hodnotenim
	 * 
	 * @param porotcovia - porotcovia, ktori budu hodnotit
	 */
	private void refreshPrehladPorotcov(List<Porotca> porotcovia) {

		DefaultTableModel modelPorotcovia = (DefaultTableModel) tablePrehladPorodcov.getModel();
		// vycistime celu prehladovu tabulku
		modelPorotcovia.setRowCount(0);
		if (porotcovia != null) {
			for (Porotca porotca : porotcovia) {
				modelPorotcovia.addRow(new Object[] { porotca, porotca, porotca, porotca, porotca, porotca, porotca });
			}
		}

	}

	/**
	 * abstraktna metoda, ktora zabezpecuje aktualne zobrazenie finalneho poctu
	 * bodov od porotcu na uchadzacovi v prehlade uchadzacov
	 */
	protected abstract void refreshPrehladUcastnikov();
}
