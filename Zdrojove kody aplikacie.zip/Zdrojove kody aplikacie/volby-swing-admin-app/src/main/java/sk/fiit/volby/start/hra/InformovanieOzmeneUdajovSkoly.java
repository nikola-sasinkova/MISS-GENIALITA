package sk.fiit.volby.start.hra;

import sk.fiit.volby.domain.skola.Skola;

/**
 * interface poskytujuci metody na refresh udajov na jednotlivych paneloch
 * obrazovky SkolaPage
 * 
 * @author nikola
 */
public interface InformovanieOzmeneUdajovSkoly {

	/**
	 * metoda, ktorej implementacia bude poskytovat konkretnu aktualizaciu udajov na
	 * konkretnom panely obrazovky SkolaPage (napr. kontakt, adresa, ...)
	 * 
	 * @param skola - skola, ktore je predmetom aktualizacie udajov
	 */
	void inform(Skola skola);

}
