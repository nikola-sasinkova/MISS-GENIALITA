package sk.fiit.volby.start.hra;

/**
 * interface poskytujuci metody na refreh udajov na jednotlivych obrazovkach
 * 
 * @author nikola
 */
public interface InformovanieOzmeneUdajov {

	/**
	 * metoda, ktorej implementacia bude poskytovat konkretnu aktualizaciu udajov na
	 * konkretnej obrazovke
	 */
	void inform();

}
