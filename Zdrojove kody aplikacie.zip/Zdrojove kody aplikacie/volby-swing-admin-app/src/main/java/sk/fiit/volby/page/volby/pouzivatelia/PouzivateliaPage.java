package sk.fiit.volby.page.volby.pouzivatelia;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import sk.fiit.volby.domain.pouzivatel.Pouzivatel;
import sk.fiit.volby.domain.volby.ucastnici.volby.Porotca;
import sk.fiit.volby.domain.volby.ucastnici.volby.Uchadzac;
import sk.fiit.volby.domain.volby.ucastnici.volby.Ziak;
import sk.fiit.volby.start.RunApp;

/**
 * obrazovka na zobrazenie prehladu pouzivatelov
 * 
 * @author nikola
 */
public abstract class PouzivateliaPage extends JDialog {

	private static final long serialVersionUID = -6968437329333357660L;

	/**
	 * tabulka na zobrazenie prehladu pouzivatelov
	 */
	protected JTable tablePrehladPouzivatelov;

	/**
	 * prazdny konstruktor pre vytvorenie obrazovky prehladu pouzivatelov
	 */
	public PouzivateliaPage() {

		inicializaciaObrazovky();

	}

	/**
	 * inicializacia obrazovky
	 */
	private void inicializaciaObrazovky() {

		setTitle(RunApp.getProperties().getProperty("prehlad.pouzivatelov.page.title"));
		setSize(955, 580);
		getContentPane().setLayout(null);

		Image imgAdminLogo = new ImageIcon(this.getClass().getResource("/logo.png")).getImage();
		setIconImage(imgAdminLogo);

		JPanel panelPrehladPouzivatelov = new JPanel();
		panelPrehladPouzivatelov.setBorder(new LineBorder(new Color(0, 0, 0)));
		panelPrehladPouzivatelov.setBounds(10, 11, 921, 517);
		getContentPane().add(panelPrehladPouzivatelov);
		panelPrehladPouzivatelov.setLayout(null);

		JScrollPane scrollPanePrehladPouzivatelov = new JScrollPane();
		scrollPanePrehladPouzivatelov.setBounds(10, 42, 901, 430);
		panelPrehladPouzivatelov.add(scrollPanePrehladPouzivatelov);

		// vytvorenie instancie tabulky s prehladom pouzivatelov
		tablePrehladPouzivatelov = new JTable();
		tablePrehladPouzivatelov.setFillsViewportHeight(true);
		tablePrehladPouzivatelov.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		// nadefinovanie stlpcov, ktore bude obsahovat tabulka
		tablePrehladPouzivatelov.setModel(new DefaultTableModel(new Object[][] {},
				new String[] { "Prihlasovacie meno", "Heslo", "Je porotcom ?", "Je ziakom ?", "Je uchadzacom ?" }) {

			private static final long serialVersionUID = -1146022595316798792L;

			// tabulka bude klikatelna
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}

		});
		tablePrehladPouzivatelov.getColumnModel().getColumn(0).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = -5674961094034782816L;

			// customizacia pozadovanej hodnoty v bunke tabulky - z pouzivatela si zoberieme
			// login, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Pouzivatel pouzivatel = (Pouzivatel) value;
				setText(pouzivatel.getLogin());

				return this;
			}
		});
		tablePrehladPouzivatelov.getColumnModel().getColumn(1).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 5012359686114748082L;

			// customizacia pozadovanej hodnoty v bunke tabulky - z pouzivatela si zoberieme
			// heslo, ktore budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Pouzivatel pouzivatel = (Pouzivatel) value;
				setText(pouzivatel.getHeslo());

				return this;
			}
		});
		tablePrehladPouzivatelov.getColumnModel().getColumn(2).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = -8192865227225564152L;

			// customizacia pozadovanej hodnoty v bunke tabulky - z pouzivatela si zoberieme
			// osobu, z ktorej zistime, ci pouzivatel vystupuje v nasej hre ako porotca
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Pouzivatel pouzivatel = (Pouzivatel) value;
				String jePorotcom = (pouzivatel.getOsoba() instanceof Porotca) ? "Ano" : "";
				setText(jePorotcom);

				return this;
			}
		});
		tablePrehladPouzivatelov.getColumnModel().getColumn(3).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = -6866339199216568889L;

			// customizacia pozadovanej hodnoty v bunke tabulky - z pouzivatela si zoberieme
			// osobu, z ktorej zistime, ci pouzivatel vystupuje v nasej hre ako ziak
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Pouzivatel pouzivatel = (Pouzivatel) value;
				String jeZiakom = (pouzivatel.getOsoba() instanceof Ziak) ? "Ano" : "";
				setText(jeZiakom);

				return this;
			}
		});
		tablePrehladPouzivatelov.getColumnModel().getColumn(4).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 8472058380451284270L;

			// customizacia pozadovanej hodnoty v bunke tabulky - z pouzivatela si zoberieme
			// osobu, z ktorej zistime, ci pouzivatel vystupuje v nasej hre ako uchadzac
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Pouzivatel pouzivatel = (Pouzivatel) value;
				String jeUchadzacom = (pouzivatel.getOsoba() instanceof Uchadzac) ? "Ano" : "";
				setText(jeUchadzacom);

				return this;
			}
		});

		scrollPanePrehladPouzivatelov.setBorder(new MatteBorder(1, 0, 0, 0, (Color) new Color(192, 192, 192)));
		scrollPanePrehladPouzivatelov.setViewportView(tablePrehladPouzivatelov);

		JPanel panelPrehladPouzivatelovCaption = new JPanel();
		panelPrehladPouzivatelovCaption.setBackground(new Color(0, 0, 0));
		panelPrehladPouzivatelovCaption.setBounds(0, 0, 921, 31);
		panelPrehladPouzivatelov.add(panelPrehladPouzivatelovCaption);
		panelPrehladPouzivatelovCaption.setLayout(null);

		JLabel lblPrehladPouzivatelovCaption = new JLabel("Prehľad používateľov");
		lblPrehladPouzivatelovCaption.setForeground(new Color(255, 255, 255));
		lblPrehladPouzivatelovCaption.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblPrehladPouzivatelovCaption.setBounds(10, 7, 150, 14);
		panelPrehladPouzivatelovCaption.add(lblPrehladPouzivatelovCaption);

		// zrusenie okna so zoznamom pouzivatelov
		JButton btnZrusit = new JButton("Zrušiť");
		btnZrusit.setBounds(109, 484, 85, 21);
		panelPrehladPouzivatelov.add(btnZrusit);

		// button na vymazanie pouzivatela zo zoznamu pouzivatelov
		JButton btnVymazat = new JButton("Vymazať");
		btnVymazat.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				// kontrola, ci je vybrany zaznam v tabulke
				if (tablePrehladPouzivatelov.getSelectionModel().isSelectionEmpty() == false) {

					// identifikacia riadku z tabulky, na ktory pouzivatel klikol
					int row = tablePrehladPouzivatelov.getSelectedRow();

					// identifikacia stlpcu z tabulky, na ktory pouzivatel klikol
					int column = tablePrehladPouzivatelov.getSelectedColumn();

					// ziskanie objektu pouzivatel z pozadovanej bunky tabulky nachadzajucej sa na
					// pozicii row,column
					Pouzivatel pouzivatel = (Pouzivatel) tablePrehladPouzivatelov.getModel().getValueAt(row, column);

					// ak sa zhoduje id pouzivatela s id vybraneho pouzivatela zo zoznamu,
					// vybraneho pouzivatela odstranime
					PouzivateliaPage.this.vymazatPouzivatela(pouzivatel.getId());

				}

			}
		});
		btnVymazat.setBounds(10, 483, 89, 23);
		panelPrehladPouzivatelov.add(btnVymazat);
		btnZrusit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PouzivateliaPage.this.dispose();
			}
		});
	}

	/**
	 * metoda na vymazanie pouzivatela
	 * 
	 * @param id - identifikator pouzivatela
	 */
	protected abstract void vymazatPouzivatela(Integer id);

}
