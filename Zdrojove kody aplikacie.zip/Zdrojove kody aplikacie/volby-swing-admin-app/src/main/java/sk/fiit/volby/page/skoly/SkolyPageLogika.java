package sk.fiit.volby.page.skoly;

import java.util.List;

import javax.swing.table.DefaultTableModel;

import sk.fiit.volby.domain.skola.Skola;
import sk.fiit.volby.start.hra.InformovanieOzmeneUdajov;
import sk.fiit.volby.start.hra.nastavenia.HraVolbyNastaveniaImpl;

/**
 * trieda, ktora vychadza (sa dedi) z obrazovky s prehladom skol, a ktora sa
 * pouziva v navrhovom vzore Observer
 * 
 * @author nikola
 */
public class SkolyPageLogika extends SkolyPage implements InformovanieOzmeneUdajov {

	private static final long serialVersionUID = 1759084734252262046L;

	/**
	 * aktualna instancia beziacej hry
	 */
	private HraVolbyNastaveniaImpl hraVolbyNastaveniaImpl;

	/**
	 * aktualny zoznam skolv hre
	 */
	private List<Skola> skoly;

	/**
	 * konstruktor pre vytvorenie obrazovky prehladu skol s pozadovanymi parametrami
	 * 
	 * @param hraVolbyNastaveniaImpl - instancia mojej hry
	 */
	public SkolyPageLogika(HraVolbyNastaveniaImpl hraVolbyNastaveniaImpl) {
		super();
		this.hraVolbyNastaveniaImpl = hraVolbyNastaveniaImpl;
	}

	/**
	 * konkretna implementacia metody z interfacu InformovanieOzmeneUdajov pre obrazovku
	 * prehladu skol
	 */
	public void inform() {

		skoly = hraVolbyNastaveniaImpl.getSkoly();

		DefaultTableModel model = (DefaultTableModel) tablePrehladSkol.getModel();
		model.setRowCount(0);

		for (Skola skola : skoly) {
			model.addRow(new Object[] { skola });
		}

	}

}
