package sk.fiit.volby.page.prihlasovanie;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import sk.fiit.volby.domain.pouzivatel.Pouzivatel;
import sk.fiit.volby.page.pracovna.plocha.PracovnaPlochaPage;
import sk.fiit.volby.start.RunApp;

/**
 * obrazovka na prihlasenie pouzivatela do aplikacie
 * 
 * @author nikola
 */
public class PrihlasovaniePage extends JFrame {

	private static final long serialVersionUID = 8791368913318936039L;

	/**
	 * policko na zadavanie prihlasovacieho mena
	 */
	private JTextField textFieldLogin;

	/**
	 * policko na zadavanie hesla
	 */
	private JTextField textFieldPassword;

	/**
	 * simulacia prihlaseneho pouzivatela - aktualne prihlaseny pouzivatel
	 */
	private static Pouzivatel pouzivatel;

	/**
	 * popis v ktorom sa bude zobrazovat sprava o nespravne vyplnenych
	 * prihlasovacich udajoch
	 */
	private JLabel lblError;

	/**
	 * prazdny konstruktor pre vytvorenie obrazovky na prihlasenie pouzivatela
	 */
	public PrihlasovaniePage() {

		inicializaciaObrazovky();

	}

	/**
	 * inicializacia obrazovky
	 */
	private void inicializaciaObrazovky() {

		setTitle(RunApp.getProperties().getProperty("login.page.title"));
		setSize(402, 165);

		Image imgAdminLogo = new ImageIcon(this.getClass().getResource("/logo.png")).getImage();
		setIconImage(imgAdminLogo);

		getContentPane().setLayout(null);

		JPanel panel = new JPanel();
		panel.setBounds(10, 10, 358, 107);
		getContentPane().add(panel);
		panel.setLayout(null);

		JLabel lblPanelLogin = new JLabel("Prihlasovacie meno");
		lblPanelLogin.setBounds(21, 10, 124, 14);
		panel.add(lblPanelLogin);
		lblPanelLogin.setFont(new Font("Tahoma", Font.PLAIN, 12));

		JLabel lblPanelPassword = new JLabel("Heslo");
		lblPanelPassword.setBounds(21, 38, 124, 14);
		panel.add(lblPanelPassword);
		lblPanelPassword.setFont(new Font("Tahoma", Font.PLAIN, 12));

		textFieldLogin = new JTextField();
		textFieldLogin.setBounds(157, 9, 176, 19);
		panel.add(textFieldLogin);

		textFieldPassword = new JPasswordField();
		textFieldPassword.setBounds(157, 37, 176, 19);
		panel.add(textFieldPassword);

		JButton btnPrihlasit = new JButton("Prihlásiť");
		btnPrihlasit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (suUdajeFormularaValidne()) {

					dispose();
					PracovnaPlochaPage pracovnaPlochaPage = new PracovnaPlochaPage();
					pracovnaPlochaPage.setLocationRelativeTo(null);
					pracovnaPlochaPage.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

					pracovnaPlochaPage.setVisible(true);

				}

			}
		});
		btnPrihlasit.setBounds(157, 67, 92, 21);
		panel.add(btnPrihlasit);

		JButton btnZrusit = new JButton("Zrušiť");
		btnZrusit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PrihlasovaniePage.this.dispose();
			}
		});
		btnZrusit.setBounds(259, 66, 78, 21);
		panel.add(btnZrusit);

		lblError = new JLabel("Nespravne meno alebo heslo");
		lblError.setFont(new Font("Tahoma", Font.PLAIN, 9));
		lblError.setVisible(false);
		lblError.setForeground(new Color(255, 0, 0));
		lblError.setBounds(21, 70, 148, 13);
		panel.add(lblError);

	}

	/**
	 * kontrolujem povinnost prihlasovacieho mena a hesla - true ak su splnene
	 * vsetky validacne kriteria
	 * 
	 * @return boolean
	 */
	private boolean suUdajeFormularaValidne() {

		boolean valid = true;

		lblError.setVisible(false);

		if (textFieldLogin.getText().isBlank() || textFieldPassword.getText().isBlank()) {
			valid = false;
			lblError.setVisible(true);
		} else {
			pouzivatel = new Pouzivatel(1, textFieldLogin.getText(), textFieldPassword.getText());
		}

		return valid;

	}

	/**
	 * metoda na ziskanie aktualne prihlaseneho pouzivatela - vrati pouzivatela,
	 * ktory je aktualne prihlaseny
	 * 
	 * @return Pouzivatel
	 */
	public static Pouzivatel getAktualnePrihlasenyPouzivatel() {
		return pouzivatel;
	}

	/**
	 * metoda, ktora sluzi na odhlasenie pouzivatela aplikacie - v aplikacii sa to
	 * riesi setovanim pouzivatela na null
	 */
	public static void zrusitAktualnePrihlasenehoPouzivatelaPoOdhlaseni() {
		pouzivatel = null;
	}

}
