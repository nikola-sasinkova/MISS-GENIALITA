package sk.fiit.volby.page.volby.porotcovia;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.table.DefaultTableModel;

import sk.fiit.volby.domain.common.Pohlavie;
import sk.fiit.volby.domain.skola.Skola;
import sk.fiit.volby.domain.volby.ucastnici.volby.Porotca;
import sk.fiit.volby.domain.volby.ucastnici.volby.RolaPorotcu;
import sk.fiit.volby.service.exception.VporoteMozeBytLenJedenPredseda;
import sk.fiit.volby.start.hra.InformovanieOzmeneUdajov;
import sk.fiit.volby.start.hra.nastavenia.HraVolbyNastaveniaImpl;

/**
 * trieda, ktora vychadza (sa dedi) z obrazovky s prehladom porotcov, a ktora sa
 * pouziva v navrhovom vzore Observer
 * 
 * @author nikola
 */
public class PorotcoviaPageLogika extends PorotcoviaPage implements InformovanieOzmeneUdajov {

	private static final long serialVersionUID = 2489622452912194428L;

	/**
	 * aktualna instancia beziacej hry
	 */
	private HraVolbyNastaveniaImpl hraVolbyNastaveniaImpl;

	/**
	 * zoznam porotcov, ktori sa budu zobrazovat v tabulke s prehladom porotcov
	 */
	private List<Porotca> porotcovia;

	/**
	 * konstruktor pre vytvorenie obrazovky prehladu porotcov s pozadovanymi
	 * parametrami
	 * 
	 * @param hraVolbyNastaveniaImpl - instancia mojej hry
	 */
	public PorotcoviaPageLogika(HraVolbyNastaveniaImpl hraVolbyNastaveniaImpl) {
		super();
		this.hraVolbyNastaveniaImpl = hraVolbyNastaveniaImpl;
	}

	/**
	 * konkretna implementacia metody z interfacu InformovanieOzmeneUdajov pre
	 * obrazovku prehladu porotcov
	 */
	@Override
	public void inform() {
		// ziskanie aktualnych porotcov z instancie mojej hry
		porotcovia = hraVolbyNastaveniaImpl.getPorotcovia();

		// ziskanie modelu tabulky, ktory zobrazuje prehlad porotcov
		DefaultTableModel model = (DefaultTableModel) tablePrehladPorodcov.getModel();

		// vynulovanie poctu riadkov v modeli tabulky
		model.setRowCount(0);

		// prechadzanie zoznamu porotcov a plnenie riadkov tabulky
		if (porotcovia != null) {
			for (Porotca porotca : porotcovia) {
				model.addRow(new Object[] { porotca, porotca, porotca, porotca, porotca, porotca, porotca, porotca,
						porotca });
			}
		}

	}

	/**
	 * metoda na vytvorenie porotcu s pozadovanymi parametrami
	 * 
	 * @param titulPredMenom - titul pred menom porotcu
	 * @param meno           - meno porotcu
	 * @param stredneMeno    - stredne meno porotcu
	 * @param priezvisko     - priezvisko porotcu
	 * @param titulZaMenom   - titul za menom porotcu
	 * @param pohlavie       - pohlavie porotcu
	 * @param rolaPorodcu    - rola porotcu
	 * @throws VporoteMozeBytLenJedenPredseda - osetrenie chyboveho stavu, aby sa v
	 *                                        porote mohol nachadzat len jeden
	 *                                        predseda
	 */
	@Override
	protected void vytvoritPorotcu(String titulPredMenom, String meno, String stredneMeno, String priezvisko,
			String titulZaMenom, Pohlavie pohlavie, RolaPorotcu rolaPorotcu) throws VporoteMozeBytLenJedenPredseda {

		if (obsahujeZoznamPorotcovRoluPredsedu(rolaPorotcu) == true) {
			throw new VporoteMozeBytLenJedenPredseda();
		}

		// vyber prvej skoly v poradi zo zoznamu skol (kedze mam len jednu skolu, vybera
		// sa konkretna skola)
		Skola skola = hraVolbyNastaveniaImpl.getSkoly().get(0);

		// zoradenie zoznamu porotcov vzostupne podla id od najmensieho po najvacsie
		Collections.sort(porotcovia, Comparator.comparing(Porotca::getId));

		// ziskanie najvacsej hodnoty id nachadzajucej sa v zozname a pripocitanie 1, ak
		// je zoznam prazdny id nastavim na 1
		int id = porotcovia.size() == 0 ? 1 : porotcovia.get(porotcovia.size() - 1).getId() + 1;

		// vytvorenie instancie porotcu s pozadovanymi parametrami
		Porotca porotca = new Porotca(skola, id, titulPredMenom, meno, stredneMeno, priezvisko, titulZaMenom, pohlavie,
				rolaPorotcu);

		// zaradenie vytvoreneho porotcu do zoznamu porotcov v mojej hre
		porotcovia.add(porotca);

		// zavolanie konkretnej imlementacie metody inform z interfacu
		// InformovanieOzmeneUdajov
		inform();

	}

	/**
	 * metoda na aktualizaciu porotcu s pozadovanymi parametrami
	 * 
	 * @param porotcaId      - identifikator porotcu
	 * @param titulPredMenom - titul pred menom porotcu
	 * @param meno           - meno porotcu
	 * @param stredneMeno    - stredne meno porotcu
	 * @param priezvisko     - priezvisko porotcu
	 * @param titulZaMenom   - titul za menom porotcu
	 * @param pohlavie       - pohlavie porotcu
	 * @param rolaPorodcu    - rola porotcu
	 * @throws VporoteMozeBytLenJedenPredseda - osetrenie chyboveho stavu, aby sa v
	 *                                        porote mohol nachadzat len jeden
	 *                                        predseda
	 */
	@Override
	protected void upravitPorotcu(int porotcaId, String titulPredMenom, String meno, String stredneMeno,
			String priezvisko, String titulZaMenom, Pohlavie pohlavie, RolaPorotcu rolaPorotcu)
			throws VporoteMozeBytLenJedenPredseda {

		if (obsahujeZoznamPorotcovRoluPredsedu(rolaPorotcu) == true) {
			throw new VporoteMozeBytLenJedenPredseda();
		}

		// vyber prvej skoly v poradi zo zoznamu skol (kedze mam len jednu skolu, vybera
		// sa konkretna skola)
		Skola skola = hraVolbyNastaveniaImpl.getSkoly().get(0);

		// prechadzanie zoznamu porotcov definovanych v hre
		for (Porotca porotca : porotcovia) {

			// ak sa zhoduje id porotcu s id vybraneho porotcu zo zoznamu,
			// vybraneho porotcu aktualizujeme
			if (porotca.getId().equals(porotcaId)) {
				porotca.setSkola(skola);
				porotca.setTitulPredMenom(titulPredMenom);
				porotca.setMeno(meno);
				porotca.setStredneMeno(stredneMeno);
				porotca.setPriezvisko(priezvisko);
				porotca.setTitulZaMenom(titulZaMenom);
				porotca.setPohlavie(pohlavie);
				porotca.setRolaPorodcu(rolaPorotcu);

				// zavolanie konkretnej imlementacie metody inform z interfacu
				// InformovanieOzmeneUdajov
				inform();

				break;

			}
		}

	}

	/**
	 * metoda na vymazanie porotcu
	 * 
	 * @param id - identifikator porotcu
	 */
	@Override
	protected void vymazatPorotcu(Integer id) {

		// prechadzanie zoznamu porotcov
		for (Porotca porotca : porotcovia) {

			// ak sa zhoduje id porotcu s id vybraneho porotcu zo zoznamu,
			// vybraneho porotcu odstranime
			if (porotca.getId().equals(id)) {

				// odstranenie porotcu zo zoznamu
				porotcovia.remove(porotca);

				// volanie implementacie metody inform z interfacu InformovanieOzmeneUdajov,
				// ktora sluzi na
				// refresh udajov v tabulke
				inform();
				break;
			}

		}

	}

	/**
	 * metoda na overenie ci zoznam porotcov obsahuje predsedu
	 * 
	 * @param rolaPorotcu - rola porotcu
	 * @return true
	 */
	private boolean obsahujeZoznamPorotcovRoluPredsedu(RolaPorotcu rolaPorotcu) {
		for (Porotca porotca : porotcovia) {
			if (RolaPorotcu.PREDSEDA.equals(porotca.getRolaPorotcu()) && RolaPorotcu.PREDSEDA.equals(rolaPorotcu)) {
				return true;
			}
		}
		return false;

	}

}
