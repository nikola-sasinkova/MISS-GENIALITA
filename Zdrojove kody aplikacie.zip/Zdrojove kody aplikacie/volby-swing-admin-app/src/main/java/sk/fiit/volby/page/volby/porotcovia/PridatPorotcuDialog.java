package sk.fiit.volby.page.volby.porotcovia;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.ConsoleHandler;
import java.util.logging.Formatter;
import java.util.logging.Handler;
import java.util.logging.LogRecord;
import java.util.logging.Logger;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;

import sk.fiit.volby.domain.common.Pohlavie;
import sk.fiit.volby.domain.volby.ucastnici.volby.Porotca;
import sk.fiit.volby.domain.volby.ucastnici.volby.RolaPorotcu;
import sk.fiit.volby.service.exception.VporoteMozeBytLenJedenPredseda;
import sk.fiit.volby.start.RunApp;

/**
 * obrazovka sluzi na vytvorenie alebo aktualizaciu udajov porotcu
 * 
 * @author nikola
 */
public class PridatPorotcuDialog extends JDialog {

	private static final long serialVersionUID = -5931309089862762142L;

	/**
	 * combobox s moznostami vyberu roly porotcu
	 */
	private JComboBox<RolaPorotcu> comboBoxRolaPorotcu;

	/**
	 * policko na zadanie titulu pred menom porotcu
	 */
	private JTextField textFieldTitulPredMenomPorodcu;

	/**
	 * policko na zadanie mena porotcu
	 */
	private JTextField textFieldMenoPorodcu;

	/**
	 * policko na zadanie stredneho mena porotcu
	 */
	private JTextField textFieldStredneMenoPorodcu;

	/**
	 * policko na zadanie priezviska porotcu
	 */
	private JTextField textFieldPriezviskoPorodcu;

	/**
	 * policko na zadanie titulu za menom porotcu
	 */
	private JTextField textFieldTitulZaMenomPorodcu;

	/**
	 * popisok na zobrazenie chybovej hlasky
	 */
	private JLabel lblError;

	/**
	 * logger na zalogovanie chybovej hlasky
	 */
	private static Logger logger = Logger.getLogger("PridatPorotcuDialog");

	/**
	 * konstruktor pre vytvorenie obrazovky vytvorenia/aktualizacie porotcu
	 * 
	 * @param porodca - vybrany porotca z tabulky s prehladom porotcov
	 */
	public PridatPorotcuDialog(Porotca porodca) {

		inicializaciaObrazovky(porodca);

	}

	/**
	 * inicializacia obrazovky
	 * 
	 * @param porodca - porotca, ktory je predmetom aktualizacie udajov
	 */
	public void inicializaciaObrazovky(Porotca porodca) {

		final Handler handler = new ConsoleHandler();

		setAlwaysOnTop(true);
		setTitle(RunApp.getProperties().getProperty("pridat.aktualizovat.porodcu.dialog.title"));
		setType(Type.POPUP);
		setSize(470, 263);
		getContentPane().setLayout(null);

		Image imgAdminLogo = new ImageIcon(this.getClass().getResource("/logo.png")).getImage();
		setIconImage(imgAdminLogo);

		JLabel lblTitulPredMenomPorodcu = new JLabel("Titul pred menom");
		lblTitulPredMenomPorodcu.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblTitulPredMenomPorodcu.setBounds(25, 51, 98, 14);
		getContentPane().add(lblTitulPredMenomPorodcu);

		textFieldTitulPredMenomPorodcu = new JTextField();
		textFieldTitulPredMenomPorodcu.setBounds(147, 51, 256, 20);
		textFieldTitulPredMenomPorodcu.setText(porodca.getTitulPredMenom());
		getContentPane().add(textFieldTitulPredMenomPorodcu);

		JLabel lblMenoPorodcu = new JLabel("Meno");
		lblMenoPorodcu.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblMenoPorodcu.setBounds(25, 80, 62, 14);
		getContentPane().add(lblMenoPorodcu);

		textFieldMenoPorodcu = new JTextField();
		textFieldMenoPorodcu.setBounds(147, 79, 256, 20);
		textFieldMenoPorodcu.setText(porodca.getMeno());
		getContentPane().add(textFieldMenoPorodcu);

		JLabel lblPriezviskoPorodcu = new JLabel("Priezvisko");
		lblPriezviskoPorodcu.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblPriezviskoPorodcu.setBounds(25, 138, 88, 14);
		getContentPane().add(lblPriezviskoPorodcu);

		textFieldPriezviskoPorodcu = new JTextField();
		textFieldPriezviskoPorodcu.setBounds(147, 133, 256, 20);
		textFieldPriezviskoPorodcu.setText(porodca.getPriezvisko());
		getContentPane().add(textFieldPriezviskoPorodcu);

		JLabel lblStredneMenoPorodcu = new JLabel("Strené meno");
		lblStredneMenoPorodcu.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblStredneMenoPorodcu.setBounds(25, 109, 88, 14);
		getContentPane().add(lblStredneMenoPorodcu);

		textFieldStredneMenoPorodcu = new JTextField();
		textFieldStredneMenoPorodcu.setBounds(147, 107, 256, 20);
		textFieldStredneMenoPorodcu.setText(porodca.getStredneMeno());
		getContentPane().add(textFieldStredneMenoPorodcu);

		JLabel lblTitulZaMenomPorodcu = new JLabel("Titul za menom");
		lblTitulZaMenomPorodcu.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblTitulZaMenomPorodcu.setBounds(25, 167, 88, 14);
		getContentPane().add(lblTitulZaMenomPorodcu);

		textFieldTitulZaMenomPorodcu = new JTextField();
		textFieldTitulZaMenomPorodcu.setBounds(147, 159, 256, 20);
		textFieldTitulZaMenomPorodcu.setText(porodca.getTitulZaMenom());
		getContentPane().add(textFieldTitulZaMenomPorodcu);

		// tlacitko na ulozenie/aktualizaciu porotcu
		JButton btnUlozit = new JButton("Uložiť");
		btnUlozit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				lblError.setVisible(false);

				if (suUdajeFormularaValidne()) {
					// ziskanie prislusnej hodnoty z policka
					String titulPredMenom = textFieldTitulPredMenomPorodcu.getText();
					String meno = textFieldMenoPorodcu.getText();
					String stredneMeno = textFieldStredneMenoPorodcu.getText();
					String priezvisko = textFieldPriezviskoPorodcu.getText();
					String titulZaMenom = textFieldTitulZaMenomPorodcu.getText();
					Pohlavie pohlavie = Pohlavie.MUZ;
					RolaPorotcu rolaPorotcu = (RolaPorotcu) comboBoxRolaPorotcu.getSelectedItem();

					// odchytenie chyby, aby sa v zozname porotcov nachadzal iba jeden predseda
					try {

						if (porodca.getId() == null) {
							// ak nema porotca priradene logicky identifikator, vytvorime objekt porotcu
							PridatPorotcuDialog.this.vytvoritPorotcu(titulPredMenom, meno, stredneMeno, priezvisko,
									titulZaMenom, pohlavie, rolaPorotcu);
						} else {
							// ak ma porotca priradene logicky identifikator, aktualizujeme hodnoty objekt
							// porotcu
							PridatPorotcuDialog.this.upravitPorotcu(porodca.getId(), titulPredMenom, meno, stredneMeno,
									priezvisko, titulZaMenom, pohlavie, rolaPorotcu);
						}

						PridatPorotcuDialog.this.dispose();

					} catch (VporoteMozeBytLenJedenPredseda e1) {
						// mozeme vypisat chybu do konzoly a vypiseme infomaciu pre pouzivatela, ze
						// zadava dalsieho predsedu do zoznamu porotcov
						// e1.printStackTrace();
						lblError.setText("Predseda uz v zozname existuje");
						lblError.setVisible(true);

						handler.setFormatter(new Formatter() {
							public String format(LogRecord record) {
								return record.getLevel() + "  :  " + record.getSourceClassName() + " -:- "
										+ record.getSourceMethodName() + " -:- " + record.getMessage() + "\n";
							}
						});
						logger.addHandler(handler);
						logger.info("V porote moze byt len jeden predseda");

					}

				}
			}
		});
		btnUlozit.setBounds(215, 189, 89, 23);
		getContentPane().add(btnUlozit);

		// tlacitko na zrusenie okna
		JButton btnZrusit = new JButton("Zrusit");
		btnZrusit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PridatPorotcuDialog.this.dispose();
			}
		});
		btnZrusit.setBounds(314, 189, 89, 23);
		getContentPane().add(btnZrusit);

		JLabel lblRolaPorotcu = new JLabel("Rola porodcu");
		lblRolaPorotcu.setBounds(25, 24, 88, 14);
		getContentPane().add(lblRolaPorotcu);

		comboBoxRolaPorotcu = new JComboBox<RolaPorotcu>();
		comboBoxRolaPorotcu.setBounds(147, 19, 256, 22);
		getContentPane().add(comboBoxRolaPorotcu);

		lblError = new JLabel("");
		lblError.setFont(new Font("Tahoma", Font.PLAIN, 9));
		lblError.setVisible(false);
		lblError.setForeground(new Color(255, 0, 0));
		lblError.setBounds(25, 198, 164, 14);
		getContentPane().add(lblError);

		for (RolaPorotcu rolaPorodcu : RolaPorotcu.values()) {
			comboBoxRolaPorotcu.addItem(rolaPorodcu);
			if (rolaPorodcu.equals(porodca.getRolaPorotcu())) {
				comboBoxRolaPorotcu.setSelectedItem(rolaPorodcu);
			}
		}

	}

	/**
	 * metoda, ktora sluzi na validaciu udajov zadanych v policksch (meno a
	 * priezvisko bude povinne)
	 * 
	 * @return
	 */
	private boolean suUdajeFormularaValidne() {

		boolean valid = true;
		return valid;

	}

	/**
	 * metoda, ktora je volana na kliknutie tlacitka ulozit ak nie je vyplnene id
	 * porotcu - vznika novy zaznam porotcu v zozname porotcov, implementacia tejto
	 * metody sa nachadza pri vytvoreni instancie tejto obrazovky
	 * 
	 * @param titulPredMenom - titul pred menom porotcu
	 * @param meno           - meno porotcu
	 * @param stredneMeno    - stredne meno porotcu
	 * @param priezvisko     - priezvisko porotcu
	 * @param titulZaMenom   - titul za menom porotcu
	 * @param pohlavie       - pohlavie porotcu
	 * @param rolaPorodcu    - rola porotcu
	 * @throws VporoteMozeBytLenJedenPredseda - osetrenie chyboveho stavu, aby sa v
	 *                                        porote mohol nachadzat len jeden
	 *                                        predseda
	 */
	protected void vytvoritPorotcu(String titulPredMenom, String meno, String stredneMeno, String priezvisko,
			String titulZaMenom, Pohlavie pohlavie, RolaPorotcu rolaPorotcu) throws VporoteMozeBytLenJedenPredseda {
		return;
	};

	/**
	 * metoda, ktora je volana na kliknutie tlacitka ulozit ak je vyplnene id
	 * porotcu - aktualizuje sa zaznam porotcu v zozname porotcov, implementacia
	 * tejto metody sa nachadza pri vytvoreni instancie tejto obrazovky
	 * 
	 * @param porotcaId      - identifikator porotcu
	 * @param titulPredMenom - titul pred menom porotcu
	 * @param meno           - meno porotcu
	 * @param stredneMeno    - stredne meno porotcu
	 * @param priezvisko     - priezvisko porotcu
	 * @param titulZaMenom   - titul za menom porotcu
	 * @param pohlavie       - pohlavie porotcu
	 * @param rolaPorodcu    - rola porotcu
	 * @throws VporoteMozeBytLenJedenPredseda - osetrenie chyboveho stavu, aby sa v
	 *                                        porote mohol nachadzat len jeden
	 *                                        predseda
	 */
	protected void upravitPorotcu(Integer porotcaId, String titulPredMenom, String meno, String stredneMeno,
			String priezvisko, String titulZaMenom, Pohlavie pohlavie, RolaPorotcu rolaPorotcu)
			throws VporoteMozeBytLenJedenPredseda {
		return;
	};
}
