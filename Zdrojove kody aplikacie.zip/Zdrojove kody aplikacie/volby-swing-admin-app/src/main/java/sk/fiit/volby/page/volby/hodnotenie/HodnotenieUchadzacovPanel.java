package sk.fiit.volby.page.volby.hodnotenie;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import sk.fiit.volby.domain.volby.ucastnici.volby.Uchadzac;
import sk.fiit.volby.start.hra.nastavenia.HraVolbyNastaveniaImpl;

/**
 * obrazovka na zobrazenie prehladu hodnoteni
 * 
 * @author nikola
 */
public abstract class HodnotenieUchadzacovPanel extends JPanel {

	private static final long serialVersionUID = 5828595145975178136L;

	/**
	 * tabulka na zobrazenie prehladu uchadzacov
	 */
	protected JTable tablePrehladUchadzacov;

	/**
	 * popisok k nazvu sutaze
	 */
	protected JLabel lblNazovSutaze;

	/**
	 * tlacidlo na hodnotenie uchadzaca porotcom
	 */
	protected JButton btnHodnotitUchadzacaPorotca;

	/**
	 * tlacidlo na hodnotenie uchadzaca ziakom
	 */
	protected JButton btnHodnotitUchadzacaZiak;

	/**
	 * konstruktor pre vytvorenie obrazovky prehladu hodnoteni s pozadovanymi
	 * parametrami
	 * 
	 * @param hraVolbyNastaveniaImpl - instancia mojej hry
	 */
	public HodnotenieUchadzacovPanel(HraVolbyNastaveniaImpl hraVolbyNastaveniaImpl) {

		inicializaciaObrazovky(hraVolbyNastaveniaImpl);

	}

	/**
	 * inicializacia obrazovky
	 * 
	 * @param hraVolbyNastaveniaImpl - instancia mojej hry
	 */
	public void inicializaciaObrazovky(HraVolbyNastaveniaImpl hraVolbyNastaveniaImpl) {

		setLayout(null);
		setBounds(0, 0, 539, 311);

		JPanel panelPrehladZiakov = new JPanel();
		panelPrehladZiakov.setBounds(0, 0, 539, 311);
		add(panelPrehladZiakov);
		panelPrehladZiakov.setLayout(null);

		JPanel panelPrehladZiakovCaption = new JPanel();
		panelPrehladZiakovCaption.setBorder(new MatteBorder(0, 0, 1, 0, (Color) new Color(128, 128, 128)));
		panelPrehladZiakovCaption.setBackground(new Color(240, 240, 240));
		panelPrehladZiakovCaption.setBounds(0, 0, 539, 43);
		panelPrehladZiakov.add(panelPrehladZiakovCaption);
		panelPrehladZiakovCaption.setLayout(null);

		JLabel lblNazvoSutazeLabel = new JLabel("Nazov sutaze:");
		lblNazvoSutazeLabel.setBounds(10, 13, 84, 14);
		panelPrehladZiakovCaption.add(lblNazvoSutazeLabel);

		lblNazovSutaze = new JLabel("Nie je nainicializovaná žiadna súťaž");
		lblNazovSutaze.setBounds(104, 13, 383, 14);
		panelPrehladZiakovCaption.add(lblNazovSutaze);

		JScrollPane scrollPanePrehladUchadzacov = new JScrollPane();
		scrollPanePrehladUchadzacov.setBorder(new LineBorder(new Color(0, 0, 0)));
		scrollPanePrehladUchadzacov.setBounds(10, 56, 520, 216);

		// vytvorenie instancie tabulky s prehladom uchadzacov
		tablePrehladUchadzacov = new JTable();
		tablePrehladUchadzacov.setFillsViewportHeight(true);
		tablePrehladUchadzacov.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		// nadefinovanie stlpcov, ktore bude obsahovat tabulka
		tablePrehladUchadzacov.setModel(new DefaultTableModel(new Object[][] {}, new String[] { "Meno a Priezvisko",
				"Identifikator", "Stupen vzdelania", "Pocet bodov (porota)", "Pocet bodov (ziaci)" }) {

			private static final long serialVersionUID = -5459399120597283875L;

			// tabulka bude klikatelna
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}

		});
		tablePrehladUchadzacov.getColumnModel().getColumn(0).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - z uchadzaca si zoberieme
			// meno, ktore budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Uchadzac uchadzac = (Uchadzac) value;
				setText(uchadzac.getFormatovaneMenoOsoby());

				return this;
			}
		});
		tablePrehladUchadzacov.getColumnModel().getColumn(1).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - z uchadzaca si zoberieme
			// identifikator, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Uchadzac uchadzac = (Uchadzac) value;
				setText(uchadzac.getIdentifikatorZiaka());

				return this;
			}
		});
		tablePrehladUchadzacov.getColumnModel().getColumn(2).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - z uchadzaca si zoberieme
			// stupen vzdelania ziaka, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Uchadzac uchadzac = (Uchadzac) value;
				setText(uchadzac.getStupenVzdelaniaZiaka().name());

				return this;
			}
		});
		tablePrehladUchadzacov.getColumnModel().getColumn(3).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = -7126624463842227938L;

			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Uchadzac uchadzac = (Uchadzac) value;
				if (uchadzac.getFinalneHodnotenie() != null) {
					setText(String.valueOf(uchadzac.getFinalneHodnotenie().getFinalnyPocetOdPorotcu()));
				} else {
					setText("0");
				}

				return this;
			}
		});
		tablePrehladUchadzacov.getColumnModel().getColumn(4).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 9069224099168865330L;

			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Uchadzac uchadzac = (Uchadzac) value;
				if (uchadzac.getFinalneHodnotenie() != null) {
					setText(String.valueOf(uchadzac.getFinalneHodnotenie().getFinalnyPocetOdZiaka()));
				} else {
					setText("0");
				}

				return this;
			}
		});

		scrollPanePrehladUchadzacov.setBorder(new MatteBorder(1, 0, 0, 0, (Color) new Color(192, 192, 192)));
		scrollPanePrehladUchadzacov.setViewportView(tablePrehladUchadzacov);
		panelPrehladZiakov.add(scrollPanePrehladUchadzacov);

		// tlacitko na odobratie uchadzacov zo sutaze
		btnHodnotitUchadzacaPorotca = new JButton("Hodnotiť - Porotca");
		btnHodnotitUchadzacaPorotca.setEnabled(false);
		btnHodnotitUchadzacaPorotca.setBounds(230, 283, 149, 23);
		panelPrehladZiakov.add(btnHodnotitUchadzacaPorotca);

		btnHodnotitUchadzacaZiak = new JButton("Hodnotiť - Žiak");
		btnHodnotitUchadzacaZiak.setEnabled(false);
		// po kliknuti sa otvori obrazovka s prehladom hodnoteni vybraneho uchadzaca
		// ziakmi
		btnHodnotitUchadzacaZiak.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (tablePrehladUchadzacov.getSelectionModel().isSelectionEmpty() == false) {
					int row = tablePrehladUchadzacov.getSelectedRow();
					int column = tablePrehladUchadzacov.getSelectedColumn();

					Uchadzac uchadzac = (Uchadzac) tablePrehladUchadzacov.getModel().getValueAt(row, column);

					HodnotenieUchadzacovZiakmiDialog hodnotenieUchadzacovZiakmiDialog = new HodnotenieUchadzacovZiakmiDialog(
							hraVolbyNastaveniaImpl.getZiaci(), uchadzac) {

						private static final long serialVersionUID = -7618710971367402793L;

						@Override
						protected void refreshPrehladUcastnikov() {
							HodnotenieUchadzacovPanel.this.refreshPrehladUcastnikov();
						}

					};
					hodnotenieUchadzacovZiakmiDialog.setLocationRelativeTo(null);
					hodnotenieUchadzacovZiakmiDialog.setAlwaysOnTop(true);
					hodnotenieUchadzacovZiakmiDialog.setModal(true);
					hodnotenieUchadzacovZiakmiDialog.setVisible(true);

				}

			}
		});
		btnHodnotitUchadzacaZiak.setBounds(389, 283, 141, 23);
		panelPrehladZiakov.add(btnHodnotitUchadzacaZiak);
		// po kliknuti sa otvori obrazovka s prehladom hodnoteni vybraneho uchadzaca
		// porotcami
		btnHodnotitUchadzacaPorotca.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (tablePrehladUchadzacov.getSelectionModel().isSelectionEmpty() == false) {
					int row = tablePrehladUchadzacov.getSelectedRow();
					int column = tablePrehladUchadzacov.getSelectedColumn();

					Uchadzac uchadzac = (Uchadzac) tablePrehladUchadzacov.getModel().getValueAt(row, column);

					HodnotenieUchadzacovPorotcamiDialog hodnotenieUchadzacovPorotcamiDialog = new HodnotenieUchadzacovPorotcamiDialog(
							hraVolbyNastaveniaImpl.getPorotcovia(), uchadzac) {

						private static final long serialVersionUID = -7618710971367402793L;

						@Override
						protected void refreshPrehladUcastnikov() {
							HodnotenieUchadzacovPanel.this.refreshPrehladUcastnikov();
						}

					};
					hodnotenieUchadzacovPorotcamiDialog.setLocationRelativeTo(null);
					hodnotenieUchadzacovPorotcamiDialog.setAlwaysOnTop(true);
					hodnotenieUchadzacovPorotcamiDialog.setModal(true);
					hodnotenieUchadzacovPorotcamiDialog.setVisible(true);

				}

			}
		});

	}

	/**
	 * abstraktna metoda, ktora zabezpecuje aktualne zobrazenie finalneho poctu
	 * bodov od porotcu na uchadzacovi v prehlade uchadzacov
	 */
	protected abstract void refreshPrehladUcastnikov();
}
