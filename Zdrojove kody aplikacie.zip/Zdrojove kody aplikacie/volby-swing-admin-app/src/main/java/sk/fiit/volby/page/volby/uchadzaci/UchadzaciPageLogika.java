package sk.fiit.volby.page.volby.uchadzaci;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.table.DefaultTableModel;

import sk.fiit.volby.domain.volby.Sutaz;
import sk.fiit.volby.domain.volby.ucastnici.volby.StupenVzdelaniaZiaka;
import sk.fiit.volby.domain.volby.ucastnici.volby.Uchadzac;
import sk.fiit.volby.domain.volby.ucastnici.volby.UchadzacBakalarskehoStudia;
import sk.fiit.volby.domain.volby.ucastnici.volby.UchadzacInzinierskehoStudia;
import sk.fiit.volby.domain.volby.ucastnici.volby.Ziak;
import sk.fiit.volby.start.hra.InformovanieOzmeneUdajov;
import sk.fiit.volby.start.hra.nastavenia.HraVolbyNastaveniaImpl;

/**
 * trieda, ktora vychadza (sa dedi) z obrazovky s prehladom uchadzacov, a ktora
 * sa pouziva v navrhovom vzore Observer
 * 
 * @author nikola
 */
public class UchadzaciPageLogika extends UchadzaciPage implements InformovanieOzmeneUdajov {

	private static final long serialVersionUID = -9003263471682317794L;

	/**
	 * aktualna instancia beziacej hry
	 */
	private HraVolbyNastaveniaImpl hraVolbyNastaveniaImpl;

	/**
	 * zoznam uchadzacov, ktori sa budu zobrazovat v tabulke s prehladom uchadzacov
	 */
	private List<Uchadzac> uchadzaci;

	/**
	 * zoznam ziakov, ktori sa budu zobrazovat v tabulke s prehladom ziakov
	 */
	private List<Ziak> ziaci;

	/**
	 * konstruktor pre vytvorenie obrazovky prehladu uchadzacov s pozadovanymi
	 * parametrami
	 * 
	 * @param hraVolbyNastaveniaImpl - instancia mojej hry
	 */
	public UchadzaciPageLogika(HraVolbyNastaveniaImpl hraVolbyNastaveniaImpl) {
		super(hraVolbyNastaveniaImpl);
		this.hraVolbyNastaveniaImpl = hraVolbyNastaveniaImpl;
	}

	/**
	 * konkretna implementacia metody z interfacu InformovanieOzmeneUdajov pre
	 * obrazovku prehladu uchadzacov
	 */
	@Override
	public void inform() {
		// ziskanie aktualnych ziakov z instancie mojej hry
		ziaci = hraVolbyNastaveniaImpl.getZiaci();

		// ziskanie aktualnych uchadzacov z instancie mojej hry
		uchadzaci = hraVolbyNastaveniaImpl.getUchadzaci();

		// ziskanie modelu tabulky, ktory zobrazuje prehlad ziakov
		DefaultTableModel modelZiaci = (DefaultTableModel) tablePrehladZiakov.getModel();

		// vynulovanie poctu riadkov v modeli tabulky
		modelZiaci.setRowCount(0);

		// ziskanie modelu tabulky, ktory zobrazuje prehlad uchadzacov
		DefaultTableModel modelUchadzaci = (DefaultTableModel) tablePrehladUchadzacov.getModel();

		// vynulovanie poctu riadkov v modeli tabulky
		modelUchadzaci.setRowCount(0);

		// prechadzanie zoznamu ziakov a plnenie riadkov tabulky
		if (ziaci != null) {
			for (Ziak ziak : ziaci) {
				modelZiaci.addRow(new Object[] { ziak, ziak, ziak, ziak, ziak, ziak, ziak, ziak, ziak, ziak });
			}
		}

		// prechadzanie zoznamu uchadzacov a plnenie riadkov tabulky
		if (uchadzaci != null) {
			for (Uchadzac uchadzac : uchadzaci) {
				modelUchadzaci.addRow(new Object[] { uchadzac, uchadzac, uchadzac, uchadzac, uchadzac, uchadzac,
						uchadzac, uchadzac, uchadzac, uchadzac, uchadzac });
			}
		}

		btnPridatZiaka.setEnabled(hraVolbyNastaveniaImpl.getSutaze().size() > 0);

	}

	/**
	 * metoda, ktora zaradi ziaka medzi uchadzacov
	 * 
	 * @param ziak  - ziak, ktory sa prihlasil do sutaze
	 * @param sutaz - sutaz, do ktorej sa ziak prihlasil
	 */
	@Override
	protected void zaraditZiakaMedziUchadzacov(Ziak ziak, Sutaz sutaz) {

		DefaultTableModel model = (DefaultTableModel) tablePrehladUchadzacov.getModel();

		Collections.sort(uchadzaci, Comparator.comparing(Uchadzac::getId));
		int id = uchadzaci.size() == 0 ? 1 : uchadzaci.get(uchadzaci.size() - 1).getId() + 1;

		if (StupenVzdelaniaZiaka.BAKALARSKE_STUDIUM.equals(ziak.getStupenVzdelaniaZiaka())) {

			Uchadzac uchadzac = new UchadzacBakalarskehoStudia(ziak.getSkola(), id, ziak.getMeno(),
					ziak.getStredneMeno(), ziak.getPriezvisko(), ziak.getTitulPredMenom(), ziak.getTitulZaMenom(),
					ziak.getPohlavie(), ziak.getIdentifikatorZiaka(), false, sutaz, ziak.getStupenVzdelaniaZiaka());
			uchadzaci.add(uchadzac);

			model.addRow(new Object[] { uchadzac, uchadzac, uchadzac, uchadzac, uchadzac, uchadzac, uchadzac, uchadzac,
					uchadzac, uchadzac, uchadzac });

		} else {

			Uchadzac uchadzac = new UchadzacInzinierskehoStudia(ziak.getSkola(), id, ziak.getMeno(),
					ziak.getStredneMeno(), ziak.getPriezvisko(), ziak.getTitulPredMenom(), ziak.getTitulZaMenom(),
					ziak.getPohlavie(), ziak.getIdentifikatorZiaka(), false, sutaz, ziak.getStupenVzdelaniaZiaka());
			uchadzaci.add(uchadzac);

			model.addRow(new Object[] { uchadzac, uchadzac, uchadzac, uchadzac, uchadzac, uchadzac, uchadzac, uchadzac,
					uchadzac, uchadzac, uchadzac });
		}

	}

	/**
	 * metoda na odobratie uchadzaca zo zoznamu uchadzacov
	 * 
	 * @param uchadzacId - identifikator uchadzaca
	 */
	@Override
	protected void odobratUchadzacaZoZoznamuUchadzacov(Integer uchadzacId) {

		for (Uchadzac uchadzac : uchadzaci) {
			if (uchadzac.getId().equals(uchadzacId)) {
				uchadzaci.remove(uchadzac);
				break;
			}
		}

		inform();

	}

}
