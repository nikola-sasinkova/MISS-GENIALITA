package sk.fiit.volby.page.skoly;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import sk.fiit.volby.domain.skola.Skola;
import sk.fiit.volby.start.RunApp;
import sk.fiit.volby.start.hra.InformovanieOzmeneUdajovSkoly;

/**
 * obrazovka na zobrazenie prehladu skol
 * 
 * @author nikola
 */
public class SkolyPage extends JDialog {

	private static final long serialVersionUID = -6853697015187803304L;

	/**
	 * tabulka na zobrazenie prehladu skol
	 */
	protected JTable tablePrehladSkol;

	/**
	 * zoznam, v ktorom sa nachadzaju aktualne objekty, na ktorych sa budu
	 * zobrazovat aktualne informacie o vybranej skole z prehladu skol
	 */
	transient private List<InformovanieOzmeneUdajovSkoly> informovanieOzmeneUdajovSkol = new ArrayList<InformovanieOzmeneUdajovSkoly>();

	/**
	 * prázdny konstruktor pre vytvorenie obrazovky prehladu skol
	 * 
	 */
	public SkolyPage() {

		inicializaciaObrazovky();

	}

	/**
	 * inicializacia obrazovky
	 */
	private void inicializaciaObrazovky() {

		setTitle(RunApp.getProperties().getProperty("prehlad.skol.page.title"));
		setSize(868, 540);
		getContentPane().setLayout(null);

		Image imgAdminLogo = new ImageIcon(this.getClass().getResource("/logo.png")).getImage();
		setIconImage(imgAdminLogo);

		JPanel panelInformacieOskole = new JPanel();
		panelInformacieOskole.setLayout(null);
		panelInformacieOskole.setBorder(new LineBorder(new Color(0, 0, 0)));
		panelInformacieOskole.setBounds(412, 11, 435, 439);
		getContentPane().add(panelInformacieOskole);

		JPanel panelInformacieOskoleCaption = new JPanel();
		panelInformacieOskoleCaption.setLayout(null);
		panelInformacieOskoleCaption.setBackground(Color.BLACK);
		panelInformacieOskoleCaption.setBounds(0, 0, 520, 31);
		panelInformacieOskole.add(panelInformacieOskoleCaption);

		JLabel lblInformacieOskoleCaption = new JLabel("Informácie o škole");
		lblInformacieOskoleCaption.setForeground(Color.WHITE);
		lblInformacieOskoleCaption.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblInformacieOskoleCaption.setBounds(10, 7, 150, 14);
		panelInformacieOskoleCaption.add(lblInformacieOskoleCaption);

		// vytvorenie vlastneho panelu na zobrazenie adresy
		SkolaAdresaPanel skolaAdresaPanel = new SkolaAdresaPanel();
		skolaAdresaPanel.setBounds(10, 46, 394, 179);
		panelInformacieOskole.add(skolaAdresaPanel);
		// vlozenie panelu adresy do zoznamu, ktory plnim za ucelom refreshu udajov na
		// paneli, ktory sa nachadza v tomto zozname
		informovanieOzmeneUdajovSkol.add(skolaAdresaPanel);

		// vytvorenie vlastneho panelu na zobrazenie kontaktu
		SkolaKontaktPanel skolaKontaktPanel = new SkolaKontaktPanel();
		skolaKontaktPanel.setBounds(10, 236, 394, 153);
		panelInformacieOskole.add(skolaKontaktPanel);
		// vlozenie panelu adresy do zoznamu, ktory plnim za ucelom refreshu udajov na
		// paneli, ktory sa nachadza v tomto zozname
		informovanieOzmeneUdajovSkol.add(skolaKontaktPanel);

		JPanel panelPrehladSkol = new JPanel();
		panelPrehladSkol.setBorder(new LineBorder(new Color(0, 0, 0)));
		panelPrehladSkol.setBounds(10, 11, 392, 484);
		getContentPane().add(panelPrehladSkol);
		panelPrehladSkol.setLayout(null);

		JScrollPane scrollPanePrehladSkol = new JScrollPane();
		scrollPanePrehladSkol.setBounds(10, 42, 372, 430);
		panelPrehladSkol.add(scrollPanePrehladSkol);

		// vytvorenie instancie tabulky, v ktorej sa budu zobrazovat skoly
		tablePrehladSkol = new JTable();
		tablePrehladSkol.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				// kontrola, ci je vybrany zaznam v tabulke
				if (tablePrehladSkol.getSelectionModel().isSelectionEmpty() == false) {
					// identifikacia riadku z tabulky, na ktory pouzivatel klikol
					int row = tablePrehladSkol.getSelectedRow();

					// identifikacia stlpcu z tabulky, na ktory pouzivatel klikol
					int column = tablePrehladSkol.getSelectedColumn();

					// ziskanie objektu skola z pozadovanej bunky tabulky nachadzajucej sa na
					// pozicii row,column
					Skola skola = (Skola) tablePrehladSkol.getModel().getValueAt(row, column);

					// zavolanie metody inform implementovanu na vsetkych paneloch implementujucich
					// interfacoch informovanieOzmeneUdajovSkoly
					informovanieOzmeneUdajovSkoly(skola);
				}
			}
		});
		tablePrehladSkol.setFillsViewportHeight(true);
		tablePrehladSkol.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		tablePrehladSkol.setModel(new DefaultTableModel(new Object[][] {}, new String[] { "N\u00E1zov \u0161koly" }) {

			private static final long serialVersionUID = -5459399120597283875L;

			// tabulka je klikatelna
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}

		});

		tablePrehladSkol.getColumnModel().getColumn(0).setPreferredWidth(250);
		tablePrehladSkol.getColumnModel().getColumn(0).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - zo skoly si zoberieme
			// nazov, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Skola skola = (Skola) value;
				setText(skola.getNazov());

				return this;
			}
		});

		scrollPanePrehladSkol.setBorder(new MatteBorder(1, 0, 0, 0, (Color) new Color(192, 192, 192)));
		scrollPanePrehladSkol.setViewportView(tablePrehladSkol);

		JPanel panelPrehladSkolCaption = new JPanel();
		panelPrehladSkolCaption.setBackground(new Color(0, 0, 0));
		panelPrehladSkolCaption.setBounds(0, 0, 392, 31);
		panelPrehladSkol.add(panelPrehladSkolCaption);
		panelPrehladSkolCaption.setLayout(null);

		JLabel lblPrehladSkolCaption = new JLabel("Prehľad škôl");
		lblPrehladSkolCaption.setForeground(new Color(255, 255, 255));
		lblPrehladSkolCaption.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblPrehladSkolCaption.setBounds(10, 7, 100, 14);
		panelPrehladSkolCaption.add(lblPrehladSkolCaption);

		// button, ktory zavrie obrazovku prehladu skol
		JButton btnZrusit = new JButton("Zrušiť");
		btnZrusit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SkolyPage.this.dispose();
			}
		});
		btnZrusit.setBounds(754, 474, 85, 21);
		getContentPane().add(btnZrusit);
	}

	/**
	 * metoda prechadza zoznam vsetkych objektov implementujucich interface
	 * InformovanieOzmeneUdajovSkoly, na ktorych zavolame konretnu implementaciu
	 * metody inform (pouziva sa pre panel kontakt a adresa)
	 * 
	 * @param skola - skola, pre ktoru sa maju udaje o adrese a kontakte zobrazovat
	 */
	public void informovanieOzmeneUdajovSkoly(Skola skola) {

		// zoznam objetov implemetujucich interface InformovanieOzmeneUdajovSkoly (v
		// zozname sa
		// nachadzaju panel kontakt a panel adresa)
		Iterator<InformovanieOzmeneUdajovSkoly> informovanieOzmeneUdajovSkolyIterator = informovanieOzmeneUdajovSkol
				.iterator();

		// prechod zoznamu InformovanieOzmeneUdajovSkoly a volanie kokretnej
		// implementacie metody inform
		// (mam rozne implementacie metody inform pre panel kontakt a panel adresa)
		while (informovanieOzmeneUdajovSkolyIterator.hasNext()) {
			InformovanieOzmeneUdajovSkoly informovanieOzmeneUdajovSkoly = informovanieOzmeneUdajovSkolyIterator.next();
			informovanieOzmeneUdajovSkoly.inform(skola);

		}

	}

}
