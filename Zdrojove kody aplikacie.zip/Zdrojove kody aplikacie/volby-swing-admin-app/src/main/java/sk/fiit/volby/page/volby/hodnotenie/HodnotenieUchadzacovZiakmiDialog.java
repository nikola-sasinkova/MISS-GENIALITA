package sk.fiit.volby.page.volby.hodnotenie;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import sk.fiit.volby.domain.volby.ucastnici.volby.Uchadzac;
import sk.fiit.volby.domain.volby.ucastnici.volby.Ziak;
import sk.fiit.volby.domain.vyhodnotenie.PriebezneHodnotenieUchadzaca;
import sk.fiit.volby.start.RunApp;

/**
 * obrazovka na zobrazenie prehladu hodnoteni ziakmi
 * 
 * @author nikola
 */
public abstract class HodnotenieUchadzacovZiakmiDialog extends JDialog {

	private static final long serialVersionUID = 5828595145975178136L;

	/**
	 * tabulka na zobrazenie prehladu ziakov
	 */
	protected JTable tablePrehladZiakov;

	/**
	 * policko na zobrazenie nazvu prace uchadzaca
	 */
	private JTextField textFieldUchadzacNazovPrace;

	/**
	 * policko na zobrazenie formatovaneho mena uchadzaca
	 */
	private JTextField textFieldFormatovaneMenoUchadzaca;

	/**
	 * policko na zobrazenie a zadavanie poctu bodov
	 */
	private JTextField textFieldPocetBodov;

	/**
	 * konstruktor s pozadovanymi parametrami
	 * 
	 * @param ziaci    - ziaci, ktori budu hodnotit
	 * @param uchadzac - vybrany uchadzac, ktoreho budu ziaci hodnotit
	 */
	public HodnotenieUchadzacovZiakmiDialog(List<Ziak> ziaci, Uchadzac uchadzac) {

		inicializaciaObrazovky(ziaci, uchadzac);

	}

	/**
	 * inicializacia obrazovky
	 * 
	 * @param ziaci    - ziaci, ktori budu hodnotit
	 * @param uchadzac - vybrany uchadzac, ktoreho budu ziaci hodnotit
	 */
	public void inicializaciaObrazovky(List<Ziak> ziaci, Uchadzac uchadzac) {

		getContentPane().setLayout(null);
		setBounds(0, 0, 924, 395);

		setTitle(RunApp.getProperties().getProperty("hodnotenie.uchadzaca.ziakom.page.title"));
		getContentPane().setLayout(null);
		setSize(740, 439);

		Image imgAdminLogo = new ImageIcon(this.getClass().getResource("/logo.png")).getImage();
		setIconImage(imgAdminLogo);

		JPanel panelPrehladZiakov = new JPanel();
		panelPrehladZiakov.setBorder(new LineBorder(new Color(0, 0, 0)));
		panelPrehladZiakov.setBounds(10, 11, 706, 378);
		getContentPane().add(panelPrehladZiakov);
		panelPrehladZiakov.setLayout(null);

		JScrollPane scrollPane = new JScrollPane();
		// panelPrehladZiakov.setBounds(10, 11, 921, 517);
		scrollPane.setBounds(10, 42, 690, 176);
		panelPrehladZiakov.add(scrollPane);

		// vytvorenie instancie tabulky s prehladom ziakov
		tablePrehladZiakov = new JTable();
		scrollPane.setViewportView(tablePrehladZiakov);
		tablePrehladZiakov.setFillsViewportHeight(true);
		tablePrehladZiakov.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		// nadefinovanie stlpcov, ktore bude obsahovat tabulka
		tablePrehladZiakov.setModel(new DefaultTableModel(new Object[][] {}, new String[] { "Titul pred menom", "Meno",
				"Stredne meno", "Priezvisko", "Titul za menom", "Identifikator", "Pocet bodov" }) {

			private static final long serialVersionUID = -5459399120597283875L;

			// tabulka bude klikatelna
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}

		});

		tablePrehladZiakov.getColumnModel().getColumn(0).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - zo ziaka si zoberieme
			// titul pred menom, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Ziak ziak = (Ziak) value;
				setText(ziak.getTitulPredMenom());

				return this;
			}
		});
		tablePrehladZiakov.getColumnModel().getColumn(1).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - zo ziaka si zoberieme
			// meno, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Ziak ziak = (Ziak) value;
				setText(ziak.getMeno());

				return this;
			}
		});
		tablePrehladZiakov.getColumnModel().getColumn(2).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - zo ziaka si zoberieme
			// stredne meno, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Ziak ziak = (Ziak) value;
				setText(ziak.getStredneMeno());

				return this;
			}
		});
		tablePrehladZiakov.getColumnModel().getColumn(3).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - zo ziaka si zoberieme
			// priezvisko, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Ziak ziak = (Ziak) value;
				setText(ziak.getPriezvisko());

				return this;
			}
		});
		tablePrehladZiakov.getColumnModel().getColumn(4).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - zo ziaka si zoberieme
			// titul za menom, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Ziak ziak = (Ziak) value;
				setText(ziak.getTitulZaMenom());

				return this;
			}
		});

		tablePrehladZiakov.getColumnModel().getColumn(5).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - zo ziaka si zoberieme
			// identifikator, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Ziak ziak = (Ziak) value;
				setText(ziak.getIdentifikatorZiaka());

				return this;
			}
		});

		tablePrehladZiakov.getColumnModel().getColumn(6).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - z hodnotenia si zoberieme
			// pocet bodov od ziaka, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Ziak ziak = (Ziak) value;
				PriebezneHodnotenieUchadzaca hodnotenie = getHodnotenieZiaka(ziak, uchadzac);
				setText(String.valueOf(hodnotenie.getPocetBodovOdZiaka()));

				return this;
			}
		});

		// listener pocuvajuci na kliknutie myskou do tabulky ziakov, ked sa klikne do
		// tabulky myskou, ziska sa prislusny ziak z riadku, zo ziaka sa ziska jeho
		// prislusne
		// hodnotenie (informacia zobrazujuca sa v poslednom stlpci) a nasledne sa
		// zobrazi v
		// policku hodnotenia
		tablePrehladZiakov.addMouseListener(new java.awt.event.MouseAdapter() {
			@Override
			public void mouseClicked(java.awt.event.MouseEvent evt) {

				int row = tablePrehladZiakov.rowAtPoint(evt.getPoint());
				int column = tablePrehladZiakov.columnAtPoint(evt.getPoint());
				if (row >= 0 && column >= 0) {
					Ziak ziak = (Ziak) tablePrehladZiakov.getModel().getValueAt(row, column);
					PriebezneHodnotenieUchadzaca hodnotenie = getHodnotenieZiaka(ziak, uchadzac);
					// zobrazenie hodnoty priebezneho hodnotenia do policka - pocet bodov
					textFieldPocetBodov.setText(String.valueOf(hodnotenie.getPocetBodovOdZiaka()));
				}
			}
		});
		refreshPrehladZiakov(ziaci);

		JPanel panelPrehladZiakovCaption = new JPanel();
		panelPrehladZiakovCaption.setBackground(new Color(0, 0, 0));
		panelPrehladZiakovCaption.setBounds(0, 0, 921, 31);
		panelPrehladZiakov.add(panelPrehladZiakovCaption);
		panelPrehladZiakovCaption.setLayout(null);

		JLabel lblPrehladZiakovCaption = new JLabel("Hodnotenie uchadzaca ziakmi");
		lblPrehladZiakovCaption.setForeground(new Color(255, 255, 255));
		lblPrehladZiakovCaption.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblPrehladZiakovCaption.setBounds(10, 7, 224, 14);
		panelPrehladZiakovCaption.add(lblPrehladZiakovCaption);

		// zrusenie okna so zoznamom ziakov
		JButton btnZrusit = new JButton("Zrušiť");
		btnZrusit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				HodnotenieUchadzacovZiakmiDialog.this.dispose();
			}
		});
		btnZrusit.setBounds(591, 344, 105, 23);
		panelPrehladZiakov.add(btnZrusit);

		JLabel lblUchadzacLabel = new JLabel("Uchadzac");
		lblUchadzacLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblUchadzacLabel.setBounds(20, 229, 80, 14);
		panelPrehladZiakov.add(lblUchadzacLabel);

		JLabel lblUchadzacNazovPraceLabel = new JLabel("Názov práce");
		lblUchadzacNazovPraceLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblUchadzacNazovPraceLabel.setBounds(20, 253, 80, 14);
		panelPrehladZiakov.add(lblUchadzacNazovPraceLabel);

		JLabel lblUchadzacPopisPraceLabel = new JLabel("Popis práce");
		lblUchadzacPopisPraceLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblUchadzacPopisPraceLabel.setBounds(20, 277, 80, 14);
		panelPrehladZiakov.add(lblUchadzacPopisPraceLabel);

		textFieldFormatovaneMenoUchadzaca = new JTextField();
		textFieldFormatovaneMenoUchadzaca.setBounds(110, 229, 296, 20);
		textFieldFormatovaneMenoUchadzaca.setText(uchadzac.getFormatovaneMenoOsoby());
		panelPrehladZiakov.add(textFieldFormatovaneMenoUchadzaca);

		textFieldUchadzacNazovPrace = new JTextField();
		textFieldUchadzacNazovPrace.setBounds(110, 253, 296, 20);
		textFieldUchadzacNazovPrace.setText(uchadzac.getVyskumnaPraca().getNazov());
		panelPrehladZiakov.add(textFieldUchadzacNazovPrace);

		JTextArea textArea = new JTextArea();
		textArea.setBounds(110, 277, 296, 54);
		textArea.setWrapStyleWord(true);
		textArea.setLineWrap(true);
		textArea.setText(uchadzac.getVyskumnaPraca().getPopis());
		panelPrehladZiakov.add(textArea);

		JLabel lblPocetBodovLabel = new JLabel("Pocet bodov");
		lblPocetBodovLabel.setForeground(new Color(255, 0, 0));
		lblPocetBodovLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblPocetBodovLabel.setBounds(449, 229, 78, 14);
		panelPrehladZiakov.add(lblPocetBodovLabel);

		textFieldPocetBodov = new JTextField();
		textFieldPocetBodov.setBounds(449, 251, 86, 20);
		panelPrehladZiakov.add(textFieldPocetBodov);

		JButton btnNastavitPocetBodov = new JButton("Nastaviť");
		btnNastavitPocetBodov.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (tablePrehladZiakov.getSelectionModel().isSelectionEmpty() == false) {
					int row = tablePrehladZiakov.getSelectedRow();
					int column = tablePrehladZiakov.getSelectedColumn();

					Ziak ziak = (Ziak) tablePrehladZiakov.getModel().getValueAt(row, column);
					if (textFieldPocetBodov.getText().trim() != "") {

						PriebezneHodnotenieUchadzaca priebezneHodnotenieUchadzaca = getHodnotenieZiaka(ziak, uchadzac);
						priebezneHodnotenieUchadzaca
								.setPocetBodovOdZiaka(Integer.parseInt(textFieldPocetBodov.getText().trim()));
						uchadzac.aktualizovatPriebezneHodnotenieUchadzacaZiaka(priebezneHodnotenieUchadzaca);

						uchadzac.vypocetBodovehoHodnotenia();

						// obnovenie udajov v tabulke s prehladom ziakov
						refreshPrehladZiakov(ziaci);

						// obnovenie udajov v tabulke s prehladom uchadzacov
						refreshPrehladUcastnikov();

					}

				}

			}
		});
		btnNastavitPocetBodov.setBounds(545, 250, 89, 23);
		panelPrehladZiakov.add(btnNastavitPocetBodov);

	}

	/**
	 * zo zoznamu vsetkych priebeznych hodnoteni ziakov, ziskame priebezne
	 * hodnotenie pre pozadovaneho ziaka, ak priebezne hodnotenie u ziaka
	 * neexistuje, vytvorime ho s hodnotou 0
	 * 
	 * @param ziak     - ziak, ktoreho hodnotenie pozadujeme zistit
	 * @param uchadzac - vybrany uchadzac, ktoreho hodnotenie pozadujeme zistit
	 * @return priebezneHodnotenieUchadzaca
	 */
	private PriebezneHodnotenieUchadzaca getHodnotenieZiaka(Ziak ziak, Uchadzac uchadzac) {

		for (PriebezneHodnotenieUchadzaca priebezneHodnotenieUchadzaca : uchadzac.getPriebezneHodnoteniaZiakov()) {
			if (priebezneHodnotenieUchadzaca.getZiak() != null) {
				if (priebezneHodnotenieUchadzaca.getZiak().getId().equals(ziak.getId())) {
					return priebezneHodnotenieUchadzaca;
				}
			}
		}

		PriebezneHodnotenieUchadzaca priebezneHodnotenieUchadzaca = new PriebezneHodnotenieUchadzaca(ziak, uchadzac, 0);
		uchadzac.aktualizovatPriebezneHodnotenieUchadzacaZiaka(priebezneHodnotenieUchadzaca);
		return priebezneHodnotenieUchadzaca;

	}

	/**
	 * zobrazenie a obnovenie udajov v tabulke na aktualne hodnoty - vynulujeme
	 * tabulku tak, ze ma 0 zaznamov a znova nacitame ziakov s hodnotenim
	 * 
	 * @param ziaci - ziaci, ktori budu hodnotit
	 */
	private void refreshPrehladZiakov(List<Ziak> ziaci) {

		DefaultTableModel modelZiakovia = (DefaultTableModel) tablePrehladZiakov.getModel();
		// vycistime celu prehladovu tabulku
		modelZiakovia.setRowCount(0);
		if (ziaci != null) {
			for (Ziak ziak : ziaci) {
				modelZiakovia.addRow(new Object[] { ziak, ziak, ziak, ziak, ziak, ziak, ziak });
			}
		}

	}

	/**
	 * abstraktna metoda, ktora zabezpecuje aktualne zobrazenie finalneho poctu
	 * bodov od porotcu na uchadzacovi v prehlade uchadzacov
	 */
	protected abstract void refreshPrehladUcastnikov();
}
