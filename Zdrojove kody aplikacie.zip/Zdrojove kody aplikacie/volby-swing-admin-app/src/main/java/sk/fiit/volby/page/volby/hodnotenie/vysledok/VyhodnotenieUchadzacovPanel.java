package sk.fiit.volby.page.volby.hodnotenie.vysledok;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutionException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingWorker;
import javax.swing.border.MatteBorder;
import javax.swing.event.MouseInputAdapter;

import sk.fiit.volby.domain.volby.ucastnici.volby.Uchadzac;
import sk.fiit.volby.start.hra.nastavenia.HraVolbyNastaveniaImpl;

/**
 * obrazovka na zobrazenie prehladu vyhodnotenia
 * 
 * @author nikola
 */
public class VyhodnotenieUchadzacovPanel extends JPanel {

	private static final long serialVersionUID = 5828595145975178136L;

	/**
	 * popisok na nazov sutaze
	 */
	protected JLabel lblNazovSutaze;

	/**
	 * popisok na zobrazenie mena vitaza
	 */
	protected JLabel lblMenoUchadzacaNaPrvomMieste;

	/**
	 * popisok na zobrazenie mena uchadzaca na druhom mieste
	 */
	protected JLabel lblMenoUchadzacaNaDruhomMieste;

	/**
	 * popisok na zobrazenie mena uchadzaca na tretom mieste
	 */
	protected JLabel lblMenoUchadzacaNaTretomMieste;

	/**
	 * popisok na zobrazenie textu vysledkova listina
	 */
	private JLabel lblVysledkovaListina;

	/**
	 * tlacidlo na vyhodnotenie sutaze
	 */
	protected JButton btnVyhodnotitUchadzacaHned;

	/**
	 * tlacidlo na vyhodnotenie sutaze (pomocou vlakna)
	 */
	protected JButton btnVyhodnotitUchadzacaTask;

	/**
	 * popisok na zobrazenie textu nazov sutaze
	 */
	private JLabel lblNazvoSutazeLabel;

	/**
	 * konstruktor pre vytvorenie obrazovky prehladu vyhodnotenia s pozadovanymi
	 * parametrami
	 * 
	 * @param hraVolbyNastaveniaImpl - instancia mojej hry
	 */
	public VyhodnotenieUchadzacovPanel(HraVolbyNastaveniaImpl hraVolbyNastaveniaImpl) {

		inicializaciaObrazovky(hraVolbyNastaveniaImpl);

	}

	/**
	 * inicializacia obrazovky
	 * 
	 * @param hraVolbyNastaveniaImpl - instancia mojej hry
	 */
	public void inicializaciaObrazovky(HraVolbyNastaveniaImpl hraVolbyNastaveniaImpl) {

		setLayout(null);
		setBounds(0, 0, 539, 311);

		JPanel panelPrehladZiakovCaption = new JPanel();
		panelPrehladZiakovCaption.setBorder(new MatteBorder(0, 0, 1, 0, (Color) new Color(128, 128, 128)));
		panelPrehladZiakovCaption.setBackground(new Color(240, 240, 240));
		panelPrehladZiakovCaption.setBounds(0, 0, 539, 43);
		add(panelPrehladZiakovCaption);
		panelPrehladZiakovCaption.setLayout(null);

		lblNazovSutaze = new JLabel("Nie je nainicializovaná žiadna súťaž");
		lblNazovSutaze.setBounds(121, 13, 383, 14);
		panelPrehladZiakovCaption.add(lblNazovSutaze);

		lblNazvoSutazeLabel = new JLabel("Nazov sutaze:");
		lblNazvoSutazeLabel.setBounds(27, 13, 84, 14);
		panelPrehladZiakovCaption.add(lblNazvoSutazeLabel);

		Image imgBednaVytazov = new ImageIcon(this.getClass().getResource("/bedna-vytazov.jpg")).getImage();

		// tlacitko, ktore spusti vypocet vyhodnotenia v tom istom vlakne ako bezi
		// aplikacia
		// (kedze to bude bezat v tom istom vlakne, aplikacia nebude dostupna na
		// klikanie, zamrzne, kym vypocet neskonci)
		btnVyhodnotitUchadzacaHned = new JButton("Vyhodnotit (hned)");
		btnVyhodnotitUchadzacaHned.setEnabled(false);
		MouseListener myListener = new MouseListener();
		btnVyhodnotitUchadzacaHned.addMouseListener(myListener);

		btnVyhodnotitUchadzacaHned.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				try {

					Thread.sleep(10000);

					List<Uchadzac> vysledkovaListinaUchadzacov = vyhodnot(hraVolbyNastaveniaImpl.getUchadzaci());
					vypisVysledky(vysledkovaListinaUchadzacov);

				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}

			}
		});
		btnVyhodnotitUchadzacaHned.setBounds(367, 54, 141, 23);
		add(btnVyhodnotitUchadzacaHned);

		JLabel bednaVytazovImage = new JLabel(new ImageIcon(imgBednaVytazov));
		add(bednaVytazovImage);
		bednaVytazovImage.setBounds(20, 54, 326, 233);

		lblMenoUchadzacaNaPrvomMieste = new JLabel("1. miesto");
		lblMenoUchadzacaNaPrvomMieste.setBounds(351, 223, 178, 14);
		add(lblMenoUchadzacaNaPrvomMieste);

		lblMenoUchadzacaNaDruhomMieste = new JLabel("2. miesto");
		lblMenoUchadzacaNaDruhomMieste.setBounds(351, 248, 178, 14);
		add(lblMenoUchadzacaNaDruhomMieste);

		lblMenoUchadzacaNaTretomMieste = new JLabel("3. miesto");
		lblMenoUchadzacaNaTretomMieste.setBounds(351, 273, 178, 14);
		add(lblMenoUchadzacaNaTretomMieste);

		lblVysledkovaListina = new JLabel("Výsledková listina");
		lblVysledkovaListina.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblVysledkovaListina.setBounds(351, 194, 127, 14);
		add(lblVysledkovaListina);

		// tlacitko, ktore spusti vypocet vyhodnotenia v samostatnom vlakne
		// (kedze to bude bezat v samostatnom vlakne, aplikacia bude dostupna na
		// klikanie)
		btnVyhodnotitUchadzacaTask = new JButton("Vyhodnotiť (task)");
		btnVyhodnotitUchadzacaTask.setEnabled(false);
		btnVyhodnotitUchadzacaTask.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// vytvorenie noveho vlakna (Threadu), v ktorom bude bezat vyhodnotenie
				// (kedze to bude bezat v samostatnom vlakne, aplikacia bude dostupna na
				// klikanie)
				SwingWorker<List<Uchadzac>, Void> worker = new SwingWorker<List<Uchadzac>, Void>() {
					// metoda vdaka ktorej sa bude na pozadi spustat algoritmus vyhodnotenia
					@Override
					public List<Uchadzac> doInBackground() throws InterruptedException {
						List<Uchadzac> vysledkovaListinaUchadzacov = vyhodnot(hraVolbyNastaveniaImpl.getUchadzaci());
						Thread.sleep(10000);
						return vysledkovaListinaUchadzacov;
					}

					// ked sa vypocet pomocou algoritmu dokonci, tak sa vysledok vypise do konzoly a
					// aplikacie
					@Override
					public void done() {
						try {

							List<Uchadzac> vysledkovaListinaUchadzacov = get();
							vypisVysledky(vysledkovaListinaUchadzacov);

						} catch (InterruptedException ex) {
							ex.printStackTrace();
						} catch (ExecutionException ex) {
							ex.printStackTrace();
						}
					}
				};
				// spustenie vlakna
				worker.execute();

			}
		});
		btnVyhodnotitUchadzacaTask.setBounds(367, 86, 141, 23);
		add(btnVyhodnotitUchadzacaTask);

	}

	/**
	 * metoda, ktora sluzi na ziskanie uchadzacov umiestnenych na prvych troch
	 * miestach, ziskanie celkoveho poctu bodov pre jednotlivych vyhercov a nasledne
	 * vypisanie na obrazovku
	 * 
	 * @param vysledkovaListinaUchadzacov - vysledkova listina uchadzacov
	 */
	private void vypisVysledky(List<Uchadzac> vysledkovaListinaUchadzacov) {

		Uchadzac uchadzacNaPrvomMieste = vysledkovaListinaUchadzacov.get(0);
		Uchadzac uchadzacNaDruhomMieste = vysledkovaListinaUchadzacov.get(1);
		Uchadzac uchadzacNaTretomMieste = vysledkovaListinaUchadzacov.get(2);

		int celkovyPocetoBodovNaPrvomMieste = uchadzacNaPrvomMieste.getFinalneHodnotenie().getFinalnyPocetBodov();
		int celkovyPocetoBodovNaDruhomMieste = uchadzacNaDruhomMieste.getFinalneHodnotenie().getFinalnyPocetBodov();
		int celkovyPocetoBodovNaTretomMieste = uchadzacNaTretomMieste.getFinalneHodnotenie().getFinalnyPocetBodov();

		lblMenoUchadzacaNaPrvomMieste.setText(
				uchadzacNaPrvomMieste.getFormatovaneMenoOsoby() + " (" + celkovyPocetoBodovNaPrvomMieste + ")");
		lblMenoUchadzacaNaDruhomMieste.setText(
				uchadzacNaDruhomMieste.getFormatovaneMenoOsoby() + " (" + celkovyPocetoBodovNaDruhomMieste + ")");
		lblMenoUchadzacaNaTretomMieste.setText(
				uchadzacNaTretomMieste.getFormatovaneMenoOsoby() + " (" + celkovyPocetoBodovNaTretomMieste + ")");

	}

	/**
	 * metoda, ktora vyhodnoti poradie uchadzacov a urci, kto skoncil na 1., 2., 3.
	 * mieste
	 * 
	 * @param uchadzaci - zoznam uchadzacov, ktori budu vstupovat do vyhodnotenia
	 * @return vysledkovaListinaUchadzacov
	 */
	private List<Uchadzac> vyhodnot(List<Uchadzac> uchadzaci) {

		System.out.println("Spustil sa algoritmus vyhodnocovania.");

		List<Uchadzac> vysledkovaListinaUchadzacov = new ArrayList<Uchadzac>();
		// prechadzame vsetkymi uchadzacmi a kazdemu, ktory ma priradenu vyskumnu pracu
		// prepocitame finalne bodove hodnotenie a daneho uchadzaca zaradime do zoznamu
		// uchadzacov pre vysledkovu listinu
		for (Uchadzac uchadzac : uchadzaci) {
			if (uchadzac.getVyskumnaPraca() != null) {
				uchadzac.vypocetBodovehoHodnotenia();
				vysledkovaListinaUchadzacov.add(uchadzac);
			}
		}
		// vyuzitie lambda vyrazu na zoradenie uchadzacov podla ziskaneho poctu bodov
		Collections.sort(vysledkovaListinaUchadzacov,
				(o1, o2) -> (o1.getFinalneHodnotenie().getFinalnyPocetBodov() > o2.getFinalneHodnotenie()
						.getFinalnyPocetBodov()) ? -1
								: (o1.getFinalneHodnotenie().getFinalnyPocetBodov() < o2.getFinalneHodnotenie()
										.getFinalnyPocetBodov()) ? 1 : 0);

		// vypisanie zoznamu prvych troch miest do konzoly
		for (int i = 0; i < vysledkovaListinaUchadzacov.size(); i++) {

			Uchadzac uchadzac = vysledkovaListinaUchadzacov.get(i);

			if (uchadzac.getVyskumnaPraca() != null) {
				System.out.println((i + 1) + " - " + uchadzac.getFormatovaneMenoOsoby() + ": "
						+ uchadzac.getFinalneHodnotenie().getFinalnyPocetBodov());
			}

		}

		return vysledkovaListinaUchadzacov;

	}

	/**
	 * vnorena trieda na vytvorenie vlastneho mouse listenera (listener, ktory sa
	 * vyuziva na odchytenie udalosti pre kliknutie mysou na prehladovu tabulku)
	 */
	private class MouseListener extends MouseInputAdapter {
		public void mouseClicked(MouseEvent e) {
		}
	}
}
