package sk.fiit.volby.page.volby.rocniky;

import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import javax.swing.table.DefaultTableModel;

import sk.fiit.volby.domain.skola.Skola;
import sk.fiit.volby.domain.volby.Rocnik;
import sk.fiit.volby.start.hra.InformovanieOzmeneUdajov;
import sk.fiit.volby.start.hra.nastavenia.HraVolbyNastaveniaImpl;

/**
 * trieda, ktora vychadza (sa dedi) z obrazovky s prehladom rocnikov, a ktora sa
 * pouziva v navrhovom vzore Observer
 * 
 * @author nikola
 */
public class RocnikyPageLogika extends RocnikyPage implements InformovanieOzmeneUdajov {

	private static final long serialVersionUID = 1353612747469379268L;

	/**
	 * aktualna instancia beziacej hry
	 */
	private HraVolbyNastaveniaImpl hraVolbyNastaveniaImpl;

	/**
	 * zoznam rocnikov, ktori sa budu zobrazovat v tabulke s prehladom rocnikov
	 */
	private List<Rocnik> rocniky;

	/**
	 * konstruktor pre vytvorenie obrazovky prehladu rocnikov s pozadovanymi
	 * parametrami
	 * 
	 * @param hraVolbyNastaveniaImpl - instancia mojej hry
	 */
	public RocnikyPageLogika(HraVolbyNastaveniaImpl hraVolbyNastaveniaImpl) {
		super();
		this.hraVolbyNastaveniaImpl = hraVolbyNastaveniaImpl;
	}

	/**
	 * konkretna implementacia metody z interfacu InformovanieOzmeneUdajov pre
	 * obrazovku prehladu rocnikov
	 */
	@Override
	public void inform() {
		// ziskanie aktualnych rocnikov z instancie mojej hry
		rocniky = hraVolbyNastaveniaImpl.getRocniky();

		// ziskanie modelu tabulky, ktora zobrazuje prehlad rocnikov
		DefaultTableModel model = (DefaultTableModel) tablePrehladRocnikov.getModel();

		// vynulovanie poctu riadkov v modeli tabulky
		model.setRowCount(0);

		if (rocniky != null) {
			// prechadzanie zoznamu rocnikov a plnenie riadkov tabulky
			for (Rocnik rocnik : rocniky) {
				model.addRow(new Object[] { rocnik, rocnik });
			}
		}
	}

	/**
	 * metoda na vytvorenie rocnika s pozadovanymi parametrami
	 * 
	 * @param nazov - nazov rocnika
	 */
	@Override
	protected void vytvoritRocnik(String nazov) {

		// vyber prvej skoly v poradi zo zoznamu skol (kedze mam len jednu skolu, vybera
		// sa konkretna skola)
		Skola skola = hraVolbyNastaveniaImpl.getSkoly().get(0);

		// zoradenie zoznamu rocnikov vzostupne podla id od najmensieho po najvacsie
		Collections.sort(rocniky, Comparator.comparing(Rocnik::getId));

		// ziskanie najvacsej hodnoty id nachadzajucej sa v zozname a pripocitanie 1, ak
		// je zoznam prazdny id nastavim na 1
		int id = rocniky.size() == 0 ? 1 : rocniky.get(rocniky.size() - 1).getId() + 1;

		// vytvorenie instancie rocnik s pozadovanymi parametrami
		Rocnik rocnik = new Rocnik(skola, id, nazov, new Date(), new Date());

		// zaradenie vytvoreneho rocnika do zoznamu rocnikov v mojej hre
		rocniky.add(rocnik);

		// zavolanie konkretnej imlementacie metody inform z interfacu
		// InformovanieOzmeneUdajov
		inform();

	}

	/**
	 * metoda na aktualizaciu rocnika s pozadovanymi parametrami
	 * 
	 * @param rocnikId - identifikator rocnika
	 * @param nazov    - nazov rocnika
	 */
	@Override
	protected void upravitRocnik(int rocnikId, String nazov) {
		// vyber prvej skoly v poradi zo zoznamu skol (kedze mam len jednu skolu, vybera
		// sa konkretna skola)
		Skola skola = hraVolbyNastaveniaImpl.getSkoly().get(0);

		// prechadzanie zoznamu rocnikov definovanych v hre
		for (Rocnik rocnik : rocniky) {

			// ak sa zhoduje id rocnika s id vybraneho rocnika zo zoznamu,
			// vybrany rocnik aktualizujeme
			if (rocnik.getId().equals(rocnikId)) {
				rocnik.setSkola(skola);
				rocnik.setNazov(nazov);

				// zavolanie konkretnej imlementacie metody inform z interfacu
				// InformovanieOzmeneUdajov
				inform();
				break;
			}
		}

	}

	/**
	 * metoda na vymazanie rocnika
	 * 
	 * @param id - identifikator rocnika
	 */
	@Override
	protected void vymazatRocnik(Integer id) {

		for (Rocnik rocnik : rocniky) {
			if (rocnik.getId().equals(id)) {
				rocniky.remove(rocnik);
				inform();
				break;
			}
		}

	}

}
