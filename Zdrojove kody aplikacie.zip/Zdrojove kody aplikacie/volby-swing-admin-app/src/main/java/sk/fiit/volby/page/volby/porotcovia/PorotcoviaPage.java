package sk.fiit.volby.page.volby.porotcovia;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import sk.fiit.volby.domain.common.Pohlavie;
import sk.fiit.volby.domain.volby.ucastnici.volby.Porotca;
import sk.fiit.volby.domain.volby.ucastnici.volby.RolaPorotcu;
import sk.fiit.volby.service.exception.VporoteMozeBytLenJedenPredseda;
import sk.fiit.volby.start.RunApp;

/**
 * obrazovka na zobrazenie prehladu porotcov
 * 
 * @author nikola
 */
public abstract class PorotcoviaPage extends JDialog {

	private static final long serialVersionUID = -2540021982433143238L;

	/**
	 * tabulka na zobrazenie prehladu porotcov
	 */
	protected JTable tablePrehladPorodcov;

	/**
	 * prazdny konstruktor pre vytvorenie obrazovky prehladu porotcov
	 */
	public PorotcoviaPage() {

		inicializaciaObrazovky();

	}

	/**
	 * inicializacia obrazovky
	 */
	private void inicializaciaObrazovky() {

		setTitle(RunApp.getProperties().getProperty("prehlad.porotcovia.page.title"));
		setSize(955, 580);
		getContentPane().setLayout(null);

		Image imgAdminLogo = new ImageIcon(this.getClass().getResource("/logo.png")).getImage();
		setIconImage(imgAdminLogo);

		JPanel panelPrehladPorodcov = new JPanel();
		panelPrehladPorodcov.setBorder(new LineBorder(new Color(0, 0, 0)));
		panelPrehladPorodcov.setBounds(10, 11, 921, 517);
		getContentPane().add(panelPrehladPorodcov);
		panelPrehladPorodcov.setLayout(null);

		// tlacitko, ktore sluzi na pridanie noveho porotcu
		JButton btnPridatPorodcu = new JButton("Pridať");
		btnPridatPorodcu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				Porotca novyPorotca = new Porotca();
				// vytvorenie instancie obrazovky pre zadanie noveho porotcu
				PridatPorotcuDialog pridatPorotcuDialog = new PridatPorotcuDialog(novyPorotca) {

					private static final long serialVersionUID = 4433947594966094338L;

					// volanie metody vytvorenia noveho porotcu
					@Override
					protected void vytvoritPorotcu(String titulPredMenom, String meno, String stredneMeno,
							String priezvisko, String titulZaMenom, Pohlavie pohlavie, RolaPorotcu rolaPorotcu)
							throws VporoteMozeBytLenJedenPredseda {
						PorotcoviaPage.this.vytvoritPorotcu(titulPredMenom, meno, stredneMeno, priezvisko, titulZaMenom,
								pohlavie, rolaPorotcu);
					}

				};
				pridatPorotcuDialog.setLocationRelativeTo(null);

				// obrazovka bude vzdy zobrazena v popredi
				pridatPorotcuDialog.setAlwaysOnTop(true);

				// obrazovka bude modalna
				pridatPorotcuDialog.setModal(true);
				pridatPorotcuDialog.setVisible(true);

			}
		});
		btnPridatPorodcu.setBounds(10, 482, 90, 23);
		panelPrehladPorodcov.add(btnPridatPorodcu);

		JScrollPane scrollPanePrehladPorodcov = new JScrollPane();
		// panelPrehladPorodcov.setBounds(10, 11, 921, 517);
		scrollPanePrehladPorodcov.setBounds(10, 42, 901, 430);
		panelPrehladPorodcov.add(scrollPanePrehladPorodcov);

		// vytvorenie instancie tabulky s prehladom porotcov
		tablePrehladPorodcov = new JTable();
		tablePrehladPorodcov.setFillsViewportHeight(true);
		tablePrehladPorodcov.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		// nadefinovanie stlpcov, ktore bude obsahovat tabulka
		tablePrehladPorodcov.setModel(new DefaultTableModel(new Object[][] {}, new String[] { "Titul pred menom",
				"Meno", "Stredné meno", "Priezvisko", "Titul za menom", "Pohlavie", "Rola" }) {

			private static final long serialVersionUID = -5459399120597283875L;

			// tabulka bude klikatelna
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}

		});

		tablePrehladPorodcov.getColumnModel().getColumn(0).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - z porotcu si zoberieme
			// titul pred menom, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Porotca porodcaDto = (Porotca) value;
				setText(porodcaDto.getTitulPredMenom());

				return this;
			}
		});
		tablePrehladPorodcov.getColumnModel().getColumn(1).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - z porotcu si zoberieme
			// meno, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Porotca porodcaDto = (Porotca) value;
				setText(porodcaDto.getMeno());

				return this;
			}
		});
		tablePrehladPorodcov.getColumnModel().getColumn(2).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - z porotcu si zoberieme
			// stredne meno, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Porotca porodcaDto = (Porotca) value;
				setText(porodcaDto.getStredneMeno());

				return this;
			}
		});
		tablePrehladPorodcov.getColumnModel().getColumn(3).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - z porotcu si zoberieme
			// priezvisko, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Porotca porodcaDto = (Porotca) value;
				setText(porodcaDto.getPriezvisko());

				return this;
			}
		});
		tablePrehladPorodcov.getColumnModel().getColumn(4).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - z porotcu si zoberieme
			// titul za menom, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Porotca porodcaDto = (Porotca) value;
				setText(porodcaDto.getTitulZaMenom());

				return this;
			}
		});
		tablePrehladPorodcov.getColumnModel().getColumn(5).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - z porotcu si zoberieme
			// rolu porotcu, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Porotca porodcaDto = (Porotca) value;
				setText(porodcaDto.getPohlavie().name());

				return this;
			}
		});
		tablePrehladPorodcov.getColumnModel().getColumn(6).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 1621757415491370882L;

			// customizacia pozadovanej hodnoty v bunke tabulky - z porotcu si zoberieme
			// skolu, do ktorej je porotca zaradeny a ktoru budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Porotca porodcaDto = (Porotca) value;
				setText(porodcaDto.getRolaPorotcu().name());

				return this;
			}
		});

		scrollPanePrehladPorodcov.setBorder(new MatteBorder(1, 0, 0, 0, (Color) new Color(192, 192, 192)));
		scrollPanePrehladPorodcov.setViewportView(tablePrehladPorodcov);

		JPanel panelPrehladPorodcovCaption = new JPanel();
		panelPrehladPorodcovCaption.setBackground(new Color(0, 0, 0));
		panelPrehladPorodcovCaption.setBounds(0, 0, 921, 31);
		panelPrehladPorodcov.add(panelPrehladPorodcovCaption);
		panelPrehladPorodcovCaption.setLayout(null);

		JLabel lblPrehladPorodcovCaption = new JLabel("Prehľad porotcov");
		lblPrehladPorodcovCaption.setForeground(new Color(255, 255, 255));
		lblPrehladPorodcovCaption.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblPrehladPorodcovCaption.setBounds(10, 7, 127, 14);
		panelPrehladPorodcovCaption.add(lblPrehladPorodcovCaption);

		// tlacitko na zobrazenie obrazovky pre aktualizaciu porotcu
		JButton btnUpravitPorodcu = new JButton("Upraviť");
		btnUpravitPorodcu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				// kontrola, ci je vybrany zaznam v tabulke
				if (tablePrehladPorodcov.getSelectionModel().isSelectionEmpty() == false) {
					// identifikacia riadku z tabulky, na ktory pouzivatel klikol
					int row = tablePrehladPorodcov.getSelectedRow();

					// identifikacia stlpcu z tabulky, na ktory pouzivatel klikol
					int column = tablePrehladPorodcov.getSelectedColumn();

					// ziskanie objektu porotca z pozadovanej bunky tabulky nachadzajucej sa na
					// pozicii row,column
					Porotca porodca = (Porotca) tablePrehladPorodcov.getModel().getValueAt(row, column);

					// vytvorenie instancie obrazovky pre aktualizaciu porotcu
					PridatPorotcuDialog pridatPorodcuDialog = new PridatPorotcuDialog(porodca) {

						private static final long serialVersionUID = -9142384259878262885L;

						// volanie metody pre upravenie porotcu
						@Override
						protected void upravitPorotcu(Integer porotcaId, String titulPredMenom, String meno,
								String stredneMeno, String priezvisko, String titulZaMenom, Pohlavie pohlavie,
								RolaPorotcu rolaPorotcu) throws VporoteMozeBytLenJedenPredseda {
							PorotcoviaPage.this.upravitPorotcu(porotcaId, titulPredMenom, meno, stredneMeno, priezvisko,
									titulZaMenom, pohlavie, rolaPorotcu);
						}

					};
					pridatPorodcuDialog.setLocationRelativeTo(null);
					pridatPorodcuDialog.setAlwaysOnTop(true);
					pridatPorodcuDialog.setModal(true);
					pridatPorodcuDialog.setVisible(true);
				}
			}
		});

		btnUpravitPorodcu.setBounds(110, 482, 90, 23);
		panelPrehladPorodcov.add(btnUpravitPorodcu);

		// button na vymazanie porotcu zo zoznamu porotcov
		JButton btnVymazatPorodcu = new JButton("Vymazať");
		btnVymazatPorodcu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				// kontrola, ci je vybrany zaznam v tabulke
				if (tablePrehladPorodcov.getSelectionModel().isSelectionEmpty() == false) {

					// identifikacia riadku z tabulky, na ktory pouzivatel klikol
					int row = tablePrehladPorodcov.getSelectedRow();

					// identifikacia stlpcu z tabulky, na ktory pouzivatel klikol
					int column = tablePrehladPorodcov.getSelectedColumn();

					// ziskanie objektu porotca z pozadovanej bunky tabulky nachadzajucej sa na
					// pozicii row,column
					Porotca vybranyPorodcaZTabulky = (Porotca) tablePrehladPorodcov.getModel().getValueAt(row, column);

					// ak sa zhoduje id porotcu s id vybranym porotcom zo zoznamu,
					// vybraneho porotcu odstranime
					PorotcoviaPage.this.vymazatPorotcu(vybranyPorodcaZTabulky.getId());

				}

			}
		});
		btnVymazatPorodcu.setBounds(210, 482, 90, 23);
		panelPrehladPorodcov.add(btnVymazatPorodcu);

		// zrusenie okna so zoznamom porotcov
		JButton btnZrusit = new JButton("Zrušiť");
		btnZrusit.setBounds(310, 483, 85, 21);
		panelPrehladPorodcov.add(btnZrusit);
		btnZrusit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PorotcoviaPage.this.dispose();
			}
		});
	}

	/**
	 * metoda na vytvorenie porotcu s pozadovanymi parametrami
	 * 
	 * @param titulPredMenom - titul pred menom porotcu
	 * @param meno           - meno porotcu
	 * @param stredneMeno    - stredne meno porotcu
	 * @param priezvisko     - priezvisko porotcu
	 * @param titulZaMenom   - titul za menom porotcu
	 * @param pohlavie       - pohlavie porotcu
	 * @param rolaPorodcu    - rola porotcu
	 * @throws VporoteMozeBytLenJedenPredseda - osetrenie chyboveho stavu, aby sa v
	 *                                        porote mohol nachadzat len jeden
	 *                                        predseda
	 */
	protected abstract void vytvoritPorotcu(String titulPredMenom, String meno, String stredneMeno, String priezvisko,
			String titulZaMenom, Pohlavie pohlavie, RolaPorotcu rolaPorotcu) throws VporoteMozeBytLenJedenPredseda;

	/**
	 * metoda na aktualizaciu porotcu s pozadovanymi parametrami
	 * 
	 * @param porotcaId      - identifikator porotcu
	 * @param titulPredMenom - titul pred menom porotcu
	 * @param meno           - meno porotcu
	 * @param stredneMeno    - stredne meno porotcu
	 * @param priezvisko     - priezvisko porotcu
	 * @param titulZaMenom   - titul za menom porotcu
	 * @param pohlavie       - pohlavie porotcu
	 * @param rolaPorodcu    - rola porotcu
	 * @throws VporoteMozeBytLenJedenPredseda - osetrenie chyboveho stavu, aby sa v
	 *                                        porote mohol nachadzat len jeden
	 *                                        predseda
	 */
	protected abstract void upravitPorotcu(int porotcaId, String titulPredMenom, String meno, String stredneMeno,
			String priezvisko, String titulZaMenom, Pohlavie pohlavie, RolaPorotcu rolaPorotcu)
			throws VporoteMozeBytLenJedenPredseda;

	/**
	 * metoda na vymazanie porotcu
	 * 
	 * @param id - identifikator porotcu
	 */
	protected abstract void vymazatPorotcu(Integer id);

}
