package sk.fiit.volby.page.volby.sutaze;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import sk.fiit.volby.domain.volby.Rocnik;
import sk.fiit.volby.domain.volby.Sutaz;
import sk.fiit.volby.start.RunApp;
import sk.fiit.volby.start.hra.nastavenia.HraVolbyNastaveniaImpl;

/**
 * obrazovka na zobrazenie prehladu sutazi
 * 
 * @author nikola
 */
public abstract class SutazePage extends JDialog {

	private static final long serialVersionUID = -2540021982433143238L;

	/**
	 * tabulka na zobrazenie prehladu sutazi
	 */
	protected JTable tablePrehladSutazi;

	/**
	 * konstruktor pre vytvorenie obrazovky prehladu sutazi s pozadovanymi
	 * parametrami
	 * 
	 * @param hraVolbyNastaveniaImpl - instancia mojej hry
	 */
	public SutazePage(final HraVolbyNastaveniaImpl hraVolbyNastaveniaImpl) {

		inicializaciaObrazovky(hraVolbyNastaveniaImpl);

	}

	/**
	 * inicializacia obrazovky
	 * 
	 * @param hraVolbyNastaveniaImpl - instancia mojej hry
	 */
	public void inicializaciaObrazovky(final HraVolbyNastaveniaImpl hraVolbyNastaveniaImpl) {

		setTitle(RunApp.getProperties().getProperty("prehlad.sutazi.page.title"));
		setSize(729, 380);
		getContentPane().setLayout(null);

		Image imgAdminLogo = new ImageIcon(this.getClass().getResource("/logo.png")).getImage();
		setIconImage(imgAdminLogo);

		JPanel panelPrehladSutazi = new JPanel();
		panelPrehladSutazi.setBorder(new LineBorder(new Color(0, 0, 0)));
		panelPrehladSutazi.setBounds(10, 11, 682, 315);
		getContentPane().add(panelPrehladSutazi);
		panelPrehladSutazi.setLayout(null);

		// tlacitko, ktore sluzi na pridanie novej sutaze
		JButton btnPridatSutaz = new JButton("Pridať");
		btnPridatSutaz.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				Sutaz novaSutaz = new Sutaz();
				// vytvorenie instancie obrazovky pre zadanie novej sutaze
				PridatSutazDialog pridatSutazDialog = new PridatSutazDialog(novaSutaz, hraVolbyNastaveniaImpl) {

					private static final long serialVersionUID = 6378768777027130638L;

					// volanie metody vytvorenia novej sutaze
					@Override
					protected void vytvoritSutaz(String nazov, String popis, Rocnik rocnik,
							Date datumUkoncenieHlasovania, Date datumSpristupnenieHlasovania, Date datumZverejnenia) {

						SutazePage.this.vytvoritSutaz(nazov, popis, rocnik, datumUkoncenieHlasovania,
								datumSpristupnenieHlasovania, datumZverejnenia);
					}

				};
				pridatSutazDialog.setLocationRelativeTo(null);

				// obrazovka bude vzdy zobrazena v popredi
				pridatSutazDialog.setAlwaysOnTop(true);

				// obrazovka bude modalna
				pridatSutazDialog.setModal(true);
				pridatSutazDialog.setVisible(true);

			}
		});
		btnPridatSutaz.setBounds(10, 280, 90, 23);
		panelPrehladSutazi.add(btnPridatSutaz);

		JScrollPane scrollPanePrehladSutazi = new JScrollPane();
		scrollPanePrehladSutazi.setBounds(10, 42, 644, 227);
		panelPrehladSutazi.add(scrollPanePrehladSutazi);

		DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");

		// vytvorenie instancie tabulky s prehladom sutazi
		tablePrehladSutazi = new JTable();
		tablePrehladSutazi.setFillsViewportHeight(true);
		tablePrehladSutazi.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		// nadefinovanie stlpcov, ktore bude obsahovat tabulka
		tablePrehladSutazi.setModel(new DefaultTableModel(new Object[][] {}, new String[] { "Názov", "Skola", "Popis",
				"Rocnik", "Datum ukoncenia", "Datum spustenia", "Datum zverejnenia" }) {

			private static final long serialVersionUID = 3963657379654254513L;

			// tabulka bude klikatelna
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}

		});
		tablePrehladSutazi.getColumnModel().getColumn(0).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 7048153237241156905L;

			// customizacia pozadovanej hodnoty v bunke tabulky - zo sutaze si zoberieme
			// nazov sutaze, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Sutaz sutaz = (Sutaz) value;
				setText(sutaz.getNazov());

				return this;
			}
		});
		tablePrehladSutazi.getColumnModel().getColumn(1).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 4391469472418313364L;

			// customizacia pozadovanej hodnoty v bunke tabulky - zo sutaze si zoberieme
			// nazov skoly, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Sutaz sutaz = (Sutaz) value;
				setText(sutaz.getSkola().getNazov());

				return this;
			}
		});
		tablePrehladSutazi.getColumnModel().getColumn(2).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = -2612452085151179688L;

			// customizacia pozadovanej hodnoty v bunke tabulky - zo sutaze si zoberieme
			// popis, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Sutaz sutaz = (Sutaz) value;
				setText(sutaz.getPopis());

				return this;
			}
		});
		tablePrehladSutazi.getColumnModel().getColumn(3).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 4188007973699982204L;

			// customizacia pozadovanej hodnoty v bunke tabulky - zo sutaze si zoberieme
			// nazov rocnika, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Sutaz sutaz = (Sutaz) value;
				setText(sutaz.getRocnik().getNazov());

				return this;
			}
		});
		tablePrehladSutazi.getColumnModel().getColumn(4).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 7253040149830305903L;

			// customizacia pozadovanej hodnoty v bunke tabulky - zo sutaze si zoberieme
			// datum ukoncenia prihlasovania, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Sutaz sutaz = (Sutaz) value;
				String strDate = dateFormat.format(sutaz.getDatumUkonceniaPrihlasovania());
				setText(strDate);

				return this;
			}
		});
		tablePrehladSutazi.getColumnModel().getColumn(5).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = -1247466273781089146L;

			// customizacia pozadovanej hodnoty v bunke tabulky - zo sutaze si zoberieme
			// datum spustenia hlasovania, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Sutaz sutaz = (Sutaz) value;
				String strDate = dateFormat.format(sutaz.getDatumSpusteniaHlasovania());
				setText(strDate);

				return this;
			}
		});
		tablePrehladSutazi.getColumnModel().getColumn(6).setCellRenderer(new DefaultTableCellRenderer() {

			private static final long serialVersionUID = 68627535669616509L;

			// customizacia pozadovanej hodnoty v bunke tabulky - zo sutaze si zoberieme
			// datum zverejnenia, ktory budeme zobrazovat v stlpci
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {

				super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

				Sutaz sutaz = (Sutaz) value;
				String strDate = dateFormat.format(sutaz.getDatumZverejnenia());
				setText(strDate);

				return this;
			}
		});

		scrollPanePrehladSutazi.setBorder(new MatteBorder(1, 0, 0, 0, (Color) new Color(192, 192, 192)));
		scrollPanePrehladSutazi.setViewportView(tablePrehladSutazi);

		JPanel panelPrehladSutaziCaption = new JPanel();
		panelPrehladSutaziCaption.setBackground(new Color(0, 0, 0));
		panelPrehladSutaziCaption.setBounds(0, 0, 682, 31);
		panelPrehladSutazi.add(panelPrehladSutaziCaption);
		panelPrehladSutaziCaption.setLayout(null);

		JLabel lblPrehladSutaziCaption = new JLabel("Prehľad súťaží");
		lblPrehladSutaziCaption.setForeground(new Color(255, 255, 255));
		lblPrehladSutaziCaption.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblPrehladSutaziCaption.setBounds(10, 7, 127, 14);
		panelPrehladSutaziCaption.add(lblPrehladSutaziCaption);

		// tlacitko na zobrazenie obrazovky pre aktualizaciu sutaze
		JButton btnUpravitSutaz = new JButton("Upraviť");
		btnUpravitSutaz.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				// kontrola, ci je vybrany zaznam v tabulke
				if (tablePrehladSutazi.getSelectionModel().isSelectionEmpty() == false) {
					// identifikacia riadku z tabulky, na ktory pouzivatel klikol
					int row = tablePrehladSutazi.getSelectedRow();

					// identifikacia stlpcu z tabulky, na ktory pouzivatel klikol
					int column = tablePrehladSutazi.getSelectedColumn();

					// ziskanie objektu sutaz z pozadovanej bunky tabulky nachadzajucej sa na
					// pozicii row,column
					Sutaz sutaz = (Sutaz) tablePrehladSutazi.getModel().getValueAt(row, column);

					// vytvorenie instancie obrazovky pre aktualizaciu sutaze
					PridatSutazDialog pridatSutazDialog = new PridatSutazDialog(sutaz, hraVolbyNastaveniaImpl) {

						private static final long serialVersionUID = 1258584379991536300L;

						// volanie metody pre upravenie sutaze
						@Override
						protected void upravitSutaz(Integer sutazId, String nazov, String popis, Rocnik rocnik,
								Date datumUkoncenieHlasovania, Date datumSpristupnenieHlasovania,
								Date datumZverejnenia) {
							SutazePage.this.upravitSutaz(sutazId, nazov, popis, rocnik, datumUkoncenieHlasovania,
									datumSpristupnenieHlasovania, datumZverejnenia);

						}

					};
					pridatSutazDialog.setLocationRelativeTo(null);
					pridatSutazDialog.setAlwaysOnTop(true);
					pridatSutazDialog.setModal(true);
					pridatSutazDialog.setVisible(true);
				}
			}
		});

		btnUpravitSutaz.setBounds(110, 280, 90, 23);
		panelPrehladSutazi.add(btnUpravitSutaz);

		// button na vymazanie sutaze zo zoznamu sutazi
		JButton btnVymazatSutaz = new JButton("Vymazať");
		btnVymazatSutaz.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				// kontrola, ci je vybrany zaznam v tabulke
				if (tablePrehladSutazi.getSelectionModel().isSelectionEmpty() == false) {

					// identifikacia riadku z tabulky, na ktory pouzivatel klikol
					int row = tablePrehladSutazi.getSelectedRow();

					// identifikacia stlpcu z tabulky, na ktory pouzivatel klikol
					int column = tablePrehladSutazi.getSelectedColumn();

					// ziskanie objektu sutaz z pozadovanej bunky tabulky nachadzajucej sa na
					// pozicii row,column
					Sutaz sutaz = (Sutaz) tablePrehladSutazi.getModel().getValueAt(row, column);

					SutazePage.this.vymazatSutaz(sutaz.getId());

				}

			}

		});
		btnVymazatSutaz.setBounds(210, 280, 90, 23);
		panelPrehladSutazi.add(btnVymazatSutaz);

		// zrusenie okna so zoznamom porotcov
		JButton btnZrusit = new JButton("Zrušiť");
		btnZrusit.setBounds(310, 281, 85, 21);
		panelPrehladSutazi.add(btnZrusit);
		btnZrusit.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				SutazePage.this.dispose();
			}

		});
	}

	/**
	 * metoda na vytvorenie sutaze s pozadovanymi parametrami
	 * 
	 * @param nazov                       - nazov sutaze
	 * @param rocnik                      - rocnik, pre ktory bude sutaz vytvorena
	 * @param popis                       - popis sutaze
	 * @param datumUkonceniaPrihlasovania - datum ukoncenia prihlasovania sutaze
	 * @param datumSpusteniaHlasovania    - datum spustenia hlasovania sutaze
	 * @param datumZverejnenia            - datum zverejnenia sutaze
	 */
	protected abstract void vytvoritSutaz(String nazov, String popis, Rocnik rocnik, Date datumUkoncenieHlasovania,
			Date datumSpristupnenieHlasovania, Date datumZverejnenia);

	/**
	 * metoda na upravenie sutaze s pozadovanymi parametrami
	 * 
	 * @param sutazId                     - identifikator sutaze
	 * @param nazov                       - nazov sutaze
	 * @param rocnik                      - rocnik, pre ktory bude sutaz vytvorena
	 * @param popis                       - popis sutaze
	 * @param datumUkonceniaPrihlasovania - datum ukoncenia prihlasovania sutaze
	 * @param datumSpusteniaHlasovania    - datum spustenia hlasovania sutaze
	 * @param datumZverejnenia            - datum zverejnenia sutaze
	 */
	protected abstract void upravitSutaz(int sutazId, String nazov, String popis, Rocnik rocnik,
			Date datumUkoncenieHlasovania, Date datumSpusteniaHlasovania, Date datumZverejnenia);

	/**
	 * metoda na vymazanie sutaze
	 * 
	 * @param id - identifikator sutaze
	 */
	protected abstract void vymazatSutaz(Integer id);

}
