package sk.fiit.volby.page.volby.ziaci;

import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;

import sk.fiit.volby.domain.common.Pohlavie;
import sk.fiit.volby.domain.volby.ucastnici.volby.StupenVzdelaniaZiaka;
import sk.fiit.volby.domain.volby.ucastnici.volby.Ziak;
import sk.fiit.volby.start.RunApp;

/**
 * obrazovka sluzi na vytvorenie alebo aktualizaciu udajov ziaka
 * 
 * @author nikola
 */
public class PridatZiakaDialog extends JDialog {

	private static final long serialVersionUID = -5931309089862762142L;

	/**
	 * policko na zadanie titulu pred menom ziaka
	 */
	private JTextField textFieldTitulPredMenomZiaka;

	/**
	 * policko na zadanie mena ziaka
	 */
	private JTextField textFieldMenoZiaka;

	/**
	 * policko na zadanie stredneho mena ziaka
	 */
	private JTextField textFieldStredneMenoZiaka;

	/**
	 * policko na zadanie priezviska ziaka
	 */
	private JTextField textFieldPriezviskoZiaka;

	/**
	 * policko na zadanie titulu za menom ziaka
	 */
	private JTextField textFieldTitulZaMenomZiaka;

	/**
	 * policko na zadanie identifikatora ziaka
	 */
	private JTextField textFieldIdentifikatorZiaka;

	/**
	 * combobox na zadanie stupna vzdelania ziaka
	 */
	private JComboBox<StupenVzdelaniaZiaka> comboBoxStupenVzdelaniaZiaka;

	/**
	 * konstruktor pre vytvorenie obrazovky vytvorenia/aktualizacie ziaka
	 * 
	 * @param ziak - vybrany ziak z tabulky s prehladom ziakov
	 */
	public PridatZiakaDialog(Ziak ziak) {

		inicializaciaObrazovky(ziak);

	}

	/**
	 * inicializacia obrazovky
	 * 
	 * @param ziak - ziak, ktory je predmetom aktualizacie udajov
	 */
	public void inicializaciaObrazovky(Ziak ziak) {

		setAlwaysOnTop(true);
		setTitle(RunApp.getProperties().getProperty("pridat.aktualizovat.ziaka.dialog.title"));
		setType(Type.POPUP);
		setSize(470, 297);
		getContentPane().setLayout(null);

		Image imgAdminLogo = new ImageIcon(this.getClass().getResource("/logo.png")).getImage();
		setIconImage(imgAdminLogo);

		JLabel lblTitulPredMenomZiaka = new JLabel("Titul pred menom");
		lblTitulPredMenomZiaka.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblTitulPredMenomZiaka.setBounds(24, 22, 98, 14);
		getContentPane().add(lblTitulPredMenomZiaka);

		textFieldTitulPredMenomZiaka = new JTextField();
		textFieldTitulPredMenomZiaka.setBounds(146, 22, 256, 20);
		textFieldTitulPredMenomZiaka.setText(ziak.getTitulPredMenom());
		getContentPane().add(textFieldTitulPredMenomZiaka);

		JLabel lblMenoZiaka = new JLabel("Meno");
		lblMenoZiaka.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblMenoZiaka.setBounds(24, 51, 62, 14);
		getContentPane().add(lblMenoZiaka);

		textFieldMenoZiaka = new JTextField();
		textFieldMenoZiaka.setBounds(146, 50, 256, 20);
		textFieldMenoZiaka.setText(ziak.getMeno());
		getContentPane().add(textFieldMenoZiaka);

		JLabel lblPriezviskoZiaka = new JLabel("Priezvisko");
		lblPriezviskoZiaka.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblPriezviskoZiaka.setBounds(24, 109, 88, 14);
		getContentPane().add(lblPriezviskoZiaka);

		textFieldPriezviskoZiaka = new JTextField();
		textFieldPriezviskoZiaka.setBounds(146, 104, 256, 20);
		textFieldPriezviskoZiaka.setText(ziak.getPriezvisko());
		getContentPane().add(textFieldPriezviskoZiaka);

		JLabel lblStredneMenoZiaka = new JLabel("Strené meno");
		lblStredneMenoZiaka.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblStredneMenoZiaka.setBounds(24, 80, 88, 14);
		getContentPane().add(lblStredneMenoZiaka);

		textFieldStredneMenoZiaka = new JTextField();
		textFieldStredneMenoZiaka.setBounds(146, 78, 256, 20);
		textFieldStredneMenoZiaka.setText(ziak.getStredneMeno());
		getContentPane().add(textFieldStredneMenoZiaka);

		JLabel lblTitulZaMenomZiaka = new JLabel("Titul za menom");
		lblTitulZaMenomZiaka.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblTitulZaMenomZiaka.setBounds(24, 138, 88, 14);
		getContentPane().add(lblTitulZaMenomZiaka);

		textFieldTitulZaMenomZiaka = new JTextField();
		textFieldTitulZaMenomZiaka.setBounds(146, 130, 256, 20);
		textFieldTitulZaMenomZiaka.setText(ziak.getTitulZaMenom());
		getContentPane().add(textFieldTitulZaMenomZiaka);

		JLabel lblIdentifikatorZiaka = new JLabel("Identifikátor");
		lblIdentifikatorZiaka.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblIdentifikatorZiaka.setBounds(24, 163, 88, 14);
		getContentPane().add(lblIdentifikatorZiaka);

		textFieldIdentifikatorZiaka = new JTextField();
		textFieldIdentifikatorZiaka.setBounds(146, 161, 256, 20);
		textFieldIdentifikatorZiaka.setText(ziak.getIdentifikatorZiaka());
		getContentPane().add(textFieldIdentifikatorZiaka);

		// tlacitko na ulozenie/aktualizaciu ziaka
		JButton btnUlozit = new JButton("Uložiť");
		btnUlozit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (suUdajeFormularaValidne()) {
					// ziskanie prislusnej hodnoty z policka
					String titulPredMenom = textFieldTitulPredMenomZiaka.getText();
					String meno = textFieldMenoZiaka.getText();
					String stredneMeno = textFieldStredneMenoZiaka.getText();
					String priezvisko = textFieldPriezviskoZiaka.getText();
					String titulZaMenom = textFieldTitulZaMenomZiaka.getText();
					Pohlavie pohlavie = Pohlavie.MUZ;
					String identifikator = textFieldIdentifikatorZiaka.getText();
					StupenVzdelaniaZiaka stupenVzdelaniaZiaka = (StupenVzdelaniaZiaka) comboBoxStupenVzdelaniaZiaka
							.getSelectedItem();

					if (ziak.getId() == null) {
						PridatZiakaDialog.this.vytvoritZiaka(meno, stredneMeno, priezvisko, titulPredMenom,
								titulZaMenom, pohlavie, identifikator, stupenVzdelaniaZiaka);
					} else {
						PridatZiakaDialog.this.upravitZiaka(ziak.getId(), meno, stredneMeno, priezvisko, titulPredMenom,
								titulZaMenom, pohlavie, identifikator, stupenVzdelaniaZiaka);
					}

					PridatZiakaDialog.this.dispose();

				}
			}
		});
		btnUlozit.setBounds(217, 226, 89, 23);
		getContentPane().add(btnUlozit);

		// tlacitko na zrusenie okna
		JButton btnZrusit = new JButton("Zrusit");
		btnZrusit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PridatZiakaDialog.this.dispose();
			}
		});
		btnZrusit.setBounds(319, 226, 89, 23);
		getContentPane().add(btnZrusit);

		comboBoxStupenVzdelaniaZiaka = new JComboBox<StupenVzdelaniaZiaka>();
		comboBoxStupenVzdelaniaZiaka.setBounds(146, 190, 256, 20);
		getContentPane().add(comboBoxStupenVzdelaniaZiaka);

		for (StupenVzdelaniaZiaka stupenVzdelaniaZiaka : StupenVzdelaniaZiaka.values()) {
			comboBoxStupenVzdelaniaZiaka.addItem(stupenVzdelaniaZiaka);
			if (stupenVzdelaniaZiaka.equals(ziak.getStupenVzdelaniaZiaka())) {
				comboBoxStupenVzdelaniaZiaka.setSelectedItem(stupenVzdelaniaZiaka);
			}
		}

		JLabel lblStupenVzdelaniaZiaka = new JLabel("Stupen vzdelania");
		lblStupenVzdelaniaZiaka.setBounds(24, 190, 98, 14);
		getContentPane().add(lblStupenVzdelaniaZiaka);

	}

	/**
	 * metoda, ktora sluzi na validaciu udajov zadanych v polickach (meno a
	 * priezvisko bude povinne)
	 * 
	 * @return valid
	 */
	private boolean suUdajeFormularaValidne() {

		boolean valid = true;
		return valid;

	}

	/**
	 * abstraktna metoda, ktora je volana na kliknutie tlacitka ulozit ak nie je
	 * vyplnene id ziaka - vznika novy zaznam ziaka v zozname ziakov, implementacia
	 * tejto metody sa nachadza pri vytvoreni instancie tejto obrazovky
	 * 
	 * @param titulPredMenom       - titul pred menom ziaka
	 * @param meno                 - meno ziaka
	 * @param stredneMeno          - stredne meno ziaka
	 * @param priezvisko           - priezvisko ziaka
	 * @param titulZaMenom         - titul za menom ziaka
	 * @param pohlavie             - pohlavie ziaka
	 * @param identifikatorZiaka   - identifikator ziaka
	 * @param stupenVzdelaniaZiaka - stupen vzdelania ziaka
	 */
	protected void vytvoritZiaka(String meno, String stredneMeno, String priezvisko, String titulPredMenom,
			String titulZaMenom, Pohlavie pohlavie, String identifikatorZiaka,
			StupenVzdelaniaZiaka stupenVzdelaniaZiaka) {
		return;
	};

	/**
	 * abstraktna metoda, ktora je volana na kliknutie tlacitka ulozit ak je
	 * vyplnene id ziaka - aktualizuje sa zaznam ziaka v zozname ziakov,
	 * implementacia tejto metody sa nachadza pri vytvoreni instancie tejto
	 * obrazovky
	 * 
	 * @param ziakId               - identifikator ziaka
	 * @param titulPredMenom       - titul pred menom ziaka
	 * @param meno                 - meno ziaka
	 * @param stredneMeno          - stredne meno ziaka
	 * @param priezvisko           - priezvisko ziaka
	 * @param titulZaMenom         - titul za menom ziaka
	 * @param pohlavie             - pohlavie ziaka
	 * @param identifikatorZiaka   - identifikator ziaka
	 * @param stupenVzdelaniaZiaka - stupen vzdelania ziaka
	 */
	protected void upravitZiaka(Integer ziakId, String meno, String stredneMeno, String priezvisko,
			String titulPredMenom, String titulZaMenom, Pohlavie pohlavie, String identifikatorZiaka,
			StupenVzdelaniaZiaka stupenVzdelaniaZiaka) {
		return;
	};
}
